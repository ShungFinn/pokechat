import os

# Default Admin User
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "HaBuLing")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "070012")

# Default Public Group
DEFAULT_TEAM_NAME = os.getenv("DEFAULT_TEAM_NAME", "PokeMon!")
