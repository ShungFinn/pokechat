#!/usr/bin/env python3
import os
import subprocess
import sys
import shutil

# 配置
INSTALL_DIR = "/opt/backend"
SERVICE_NAME = "backend.service"
SOURCE_DIR = os.path.dirname(os.path.abspath(__file__))

def run_command(command):
    try:
        subprocess.check_call(command, shell=True)
    except subprocess.CalledProcessError as e:
        print(f"Error running command: {command}")
        sys.exit(1)

def main():
    if os.geteuid() != 0:
        print("请使用 root 权限运行此脚本 (sudo python3 install.py)")
        sys.exit(1)

    print("=== 开始安装后端服务 ===")

    # 1. 安装系统依赖
    print("[1/6] 安装系统依赖 (python3-venv, build-essential, libssl-dev, libffi-dev)...")
    run_command("apt-get update && apt-get install -y python3-venv python3-pip build-essential libssl-dev libffi-dev python3-dev")

    # 2. 准备安装目录
    print(f"[2/6] 创建安装目录: {INSTALL_DIR} ...")
    if os.path.exists(INSTALL_DIR):
        print(f"目录 {INSTALL_DIR} 已存在，正在备份...")
        if os.path.exists(f"{INSTALL_DIR}.bak"):
            shutil.rmtree(f"{INSTALL_DIR}.bak")
        shutil.move(INSTALL_DIR, f"{INSTALL_DIR}.bak")
    
    os.makedirs(INSTALL_DIR)

    # 3. 复制文件
    print("[3/6] 复制文件...")
    # 排除一些不需要的文件
    ignore_patterns = shutil.ignore_patterns("venv", "__pycache__", ".git", "*.pyc", "install.py", "pokemon.db")
    
    # 我们可以直接复制当前目录下的所有内容到 INSTALL_DIR
    # 但是 shutil.copytree 要求目标目录不存在。
    # 所以我们手动复制
    for item in os.listdir(SOURCE_DIR):
        s = os.path.join(SOURCE_DIR, item)
        d = os.path.join(INSTALL_DIR, item)
        if item in ['venv', '__pycache__', '.git', '.idea', 'install.py', 'package.ps1', 'pokemon.db']:
            continue
        
        if os.path.isdir(s):
            shutil.copytree(s, d, ignore=ignore_patterns)
        else:
            shutil.copy2(s, d)

    # 4. 创建虚拟环境并安装依赖
    print("[4/6] 创建虚拟环境并安装依赖...")
    venv_path = os.path.join(INSTALL_DIR, "venv")
    run_command(f"python3 -m venv {venv_path}")
    
    pip_path = os.path.join(venv_path, "bin", "pip")
    req_path = os.path.join(INSTALL_DIR, "requirements.txt")
    run_command(f"{pip_path} install --upgrade pip")
    # 分步安装以确保 bcrypt 成功
    run_command(f"{pip_path} install bcrypt passlib")
    run_command(f"{pip_path} install -r {req_path}")

    # 5. 配置环境变量
    print("[5/6] 配置环境变量...")
    env_path = os.path.join(INSTALL_DIR, ".env")
    env_example_path = os.path.join(INSTALL_DIR, ".env.example")
    
    if not os.path.exists(env_path):
        if os.path.exists(env_example_path):
            shutil.copy(env_example_path, env_path)
            print(f"已从模板创建 .env 文件")
        else:
            print("警告: 未找到 .env.example，正在创建默认 .env")
            with open(env_path, "w") as f:
                f.write("DB_TYPE=sqlite\nHOST=0.0.0.0\nPORT=7000\n")

    # 强制修正 .env 关键配置
    with open(env_path, "r") as f:
        lines = f.readlines()
    
    new_lines = []
    keys_to_fix = {"HOST": "0.0.0.0", "PORT": "7000", "RELOAD": "false"}
    found_keys = set()
    
    for line in lines:
        fixed = False
        for key, value in keys_to_fix.items():
            if line.startswith(f"{key}="):
                new_lines.append(f"{key}={value}\n")
                found_keys.add(key)
                fixed = True
                break
        if not fixed:
            new_lines.append(line)
    
    for key, value in keys_to_fix.items():
        if key not in found_keys:
            new_lines.append(f"{key}={value}\n")
    
    with open(env_path, "w") as f:
        f.writelines(new_lines)
    print(f"已配置 .env: HOST=0.0.0.0, PORT=7000, RELOAD=false")

    # 修复目录权限，确保 root 之外的用户也能（如果需要的话）或者 root 运行更顺畅
    run_command(f"chown -R root:root {INSTALL_DIR}")
    run_command(f"chmod -R 755 {INSTALL_DIR}")
    # 特别是数据库文件可能需要写权限
    # 此时数据库还没创建，我们先给目录写权限
    run_command(f"chmod 777 {INSTALL_DIR}")

    # 6. 配置 Systemd 服务
    print("[6/6] 配置 Systemd 服务...")
    service_source = os.path.join(INSTALL_DIR, SERVICE_NAME)
    service_target = f"/etc/systemd/system/{SERVICE_NAME}"
    
    if os.path.exists(service_source):
        shutil.copy(service_source, service_target)
        run_command("systemctl daemon-reload")
        run_command(f"systemctl enable {SERVICE_NAME}")
        run_command(f"systemctl restart {SERVICE_NAME}")
        print("服务已启动并设置为开机自启。")
    else:
        print(f"错误: 未找到服务文件 {service_source}")

    print("\n=== 安装完成! ===")
    print(f"服务状态检查: systemctl status {SERVICE_NAME}")
    print(f"查看日志: journalctl -u {SERVICE_NAME} -f")
    print(f"代码路径: {INSTALL_DIR}")

if __name__ == "__main__":
    main()
