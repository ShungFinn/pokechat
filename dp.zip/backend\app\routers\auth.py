from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from fastapi.security import OAuth2PasswordRequestForm
from datetime import timedelta
from typing import List
from .. import crud, schemas, security, dependencies, models

router = APIRouter()

@router.post("/register", response_model=schemas.User)
def register(user: schemas.UserCreate, db: Session = Depends(dependencies.get_db)):
    db_user = crud.get_user_by_username(db, username=user.username)
    if db_user:
        raise HTTPException(status_code=400, detail="Username already registered")
    
    # Create user
    new_user = crud.create_user(db=db, user=user)
    
    # Auto-join 'Pokemon Centre' (which is technically just a team owned by admin for now)
    # Since our 'Team' model is currently just a Pokemon Team, not a Chat Group with members,
    # we simulate this by... well, the current backend doesn't support 'Members' in a Team.
    # The 'Team' model in models.py is: id, name, user_id, pokemons.
    # It doesn't have a many-to-many relationship with Users for membership.
    
    # HOWEVER, the requirement is "Everyone is in Pokemon Centre default group".
    # If the frontend treats "Teams" as "Chat Sessions", then for everyone to see "Pokemon Centre",
    # either:
    # 1. We create a copy of "Pokemon Centre" for every new user (bad idea for a shared chat).
    # 2. We change the data model to support shared groups (best, but complex change).
    # 3. We hack it: The frontend 'fetchSessions' currently fetches 'getTeams'.
    #    If we want everyone to see a shared group, 'getTeams' should always return the public groups + user's private teams.
    
    # Let's go with Option 3 for now as it's the least intrusive backend change that fulfills the request.
    # We don't need to do anything here in register. We modify `get_teams` in crud.py or the router.
    
    return new_user

@router.post("/token", response_model=schemas.Token)
def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(dependencies.get_db)):
    user = crud.get_user_by_username(db, username=form_data.username)
    if not user or not security.verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=security.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = security.create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@router.get("/users/me", response_model=schemas.User)
def read_users_me(current_user: schemas.User = Depends(dependencies.get_current_user)):
    return current_user

@router.get("/users/", response_model=List[schemas.User])
def read_users(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(dependencies.get_db),
    current_user: models.User = Depends(dependencies.get_current_admin_user)
):
    users = crud.get_users(db, skip=skip, limit=limit)
    return users

@router.delete("/users/{user_id}")
def delete_user(
    user_id: int,
    db: Session = Depends(dependencies.get_db),
    current_user: models.User = Depends(dependencies.get_current_admin_user)
):
    user = crud.get_user(db, user_id=user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    crud.delete_user(db=db, user_id=user_id)
    return {"ok": True}

@router.post("/users/{user_id}/force_password_change")
def force_password_change(
    user_id: int,
    must_change: bool = True,
    db: Session = Depends(dependencies.get_db),
    current_user: models.User = Depends(dependencies.get_current_admin_user)
):
    user = crud.get_user(db, user_id=user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    crud.set_user_must_change_password(db, user_id, must_change)
    return {"ok": True}

@router.post("/change_password")
def change_password(
    password_update: schemas.UserPasswordUpdate,
    db: Session = Depends(dependencies.get_db),
    current_user: models.User = Depends(dependencies.get_current_user)
):
    if not security.verify_password(password_update.old_password, current_user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect old password")
    
    hashed_password = security.get_password_hash(password_update.new_password)
    crud.update_user_password(db, current_user.id, hashed_password)
    return {"ok": True}
