from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from .routers import auth, teams, chat
from .database import engine, Base
from .init_data import init_db

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Create tables
    Base.metadata.create_all(bind=engine)
    # Initialize data
    init_db()
    yield

app = FastAPI(title="Pokemon Team Builder API", lifespan=lifespan)

# CORS Configuration
origins = [
    "http://localhost",
    "http://localhost:5173", # Vite default
    "http://localhost:3000",
    "http://127.0.0.1:5173",
    "http://127.0.0.1:3000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Temporarily allow all for debugging
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(teams.router)
app.include_router(chat.router)

@app.get("/")
def read_root():
    return {"message": "Welcome to Pokemon Team Builder API"}
