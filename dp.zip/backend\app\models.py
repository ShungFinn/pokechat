from sqlalchemy import Column, Integer, String, ForeignKey, JSON, DateTime, Boolean
from sqlalchemy.orm import relationship
from .database import Base
from datetime import datetime
import uuid

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True)
    hashed_password = Column(String(255))
    role = Column(String(20), default="user")
    is_active = Column(Boolean, default=True)
    must_change_password = Column(Boolean, default=True)
    last_active = Column(DateTime, default=datetime.utcnow)
    
    teams = relationship("Team", back_populates="owner")

class Team(Base):
    __tablename__ = "teams"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(100))
    share_code = Column(String(10), unique=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    # Store the entire list of pokemons as a JSON blob for flexibility
    # This matches the frontend's 'Team' interface structure
    pokemons = Column(JSON) 
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    owner = relationship("User", back_populates="teams")
    settings = relationship("UserTeamSettings", back_populates="team", cascade="all, delete-orphan")

class UserTeamSettings(Base):
    __tablename__ = "user_team_settings"

    user_id = Column(Integer, ForeignKey("users.id"), primary_key=True)
    team_id = Column(String(36), ForeignKey("teams.id", ondelete="CASCADE"), primary_key=True)
    is_muted = Column(Boolean, default=False)

    user = relationship("User")
    team = relationship("Team", back_populates="settings")
