from pydantic import BaseModel
from typing import List, Optional, Any, Dict
from datetime import datetime

# Token Schemas
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None

# User Schemas
class UserBase(BaseModel):
    username: str

class UserCreate(UserBase):
    password: str
    role: Optional[str] = "user"

class User(UserBase):
    id: int
    role: str
    is_active: bool
    must_change_password: bool = False
    
    class Config:
        from_attributes = True

class UserPasswordUpdate(BaseModel):
    old_password: str
    new_password: str

# Team Schemas
# We mirror the frontend structures loosely to allow validation if needed
class TeamPokemon(BaseModel):
    id: str
    pokemonId: int
    name: str
    cnName: str
    types: List[str]
    sprite: str
    level: int
    isShiny: bool
    # Allow other fields as optional or flexible
    moves: List[Dict[str, Any]] = []
    baseStats: Dict[str, int]
    ivs: Dict[str, int]
    evs: Dict[str, int]
    item: Optional[Dict[str, Any]] = None
    ability: Optional[Dict[str, Any]] = None
    nature: Optional[Dict[str, Any]] = None
    nickname: Optional[str] = None

class TeamBase(BaseModel):
    name: str
    pokemons: List[Dict[str, Any]] # Using generic dict to avoid strict validation errors during rapid dev, or use TeamPokemon

class TeamCreate(TeamBase):
    pass

class Team(TeamBase):
    id: str
    share_code: Optional[str] = None
    user_id: int
    created_at: datetime
    updated_at: datetime
    members_count: Optional[int] = 1
    online_count: Optional[int] = 1
    is_muted: Optional[bool] = False

    class Config:
        from_attributes = True
