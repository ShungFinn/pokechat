import requests
import sys

import time

# Configuration
API_URL = "http://127.0.0.1:8000"
USERNAME = f"TestUser_{int(time.time())}" 
PASSWORD = "password123" 


def test_backend():
    print(f"Testing backend at {API_URL}...")
    
    # 1. Login
    try:
        print("Attempting login...")
        response = requests.post(f"{API_URL}/token", data={
            "username": USERNAME,
            "password": PASSWORD
        })
        
        if response.status_code != 200:
            print(f"Login failed: {response.status_code} - {response.text}")
            # Try registering if login fails
            print("Attempting registration...")
            reg_response = requests.post(f"{API_URL}/register", json={
                "username": USERNAME,
                "password": PASSWORD,
                "role": "user"
            })
            if reg_response.status_code not in [200, 201]:
                 # Maybe user exists but password wrong? Or admin created differently?
                 # Let's try to just assume user exists and we might need correct credentials.
                 # If HaBuLing is admin, maybe I can't register him.
                 print(f"Registration failed: {reg_response.status_code} - {reg_response.text}")
                 return
            
            # Retry login
            response = requests.post(f"{API_URL}/token", data={
                "username": USERNAME,
                "password": PASSWORD
            })
            if response.status_code != 200:
                print("Login failed after registration.")
                return

        token = response.json()["access_token"]
        print("Login successful. Token obtained.")
        
        # 2. Get Teams
        print("Fetching teams...")
        headers = {"Authorization": f"Bearer {token}"}
        teams_response = requests.get(f"{API_URL}/teams/", headers=headers)
        
        if teams_response.status_code == 200:
            teams = teams_response.json()
            print(f"Teams fetched: {len(teams)}")
            found_pokemon = False
            for team in teams:
                print(f" - Team: {team['name']} (ID: {team['id']}, Members: {team.get('members_count')})")
                if team['name'] == 'Pokemon Centre':
                    found_pokemon = True
            
            if found_pokemon:
                print("SUCCESS: Pokemon Centre group found in response.")
            else:
                print("FAILURE: Pokemon Centre group NOT found in response.")
        else:
            print(f"Failed to fetch teams: {teams_response.status_code} - {teams_response.text}")

    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    test_backend()
