$root = $PSScriptRoot
$tempDir = Join-Path $root "temp_dp"
$zipFile = Join-Path $root "DP.zip"

# 1. 清理环境
Write-Host "正在清理旧文件..."
if (Test-Path $tempDir) { Remove-Item -Recurse -Force $tempDir }
if (Test-Path $zipFile) { Remove-Item -Force $zipFile }

# 2. 创建临时目录结构
New-Item -ItemType Directory -Path $tempDir | Out-Null
$backendDest = New-Item -ItemType Directory -Path (Join-Path $tempDir "backend")
$frontendDest = New-Item -ItemType Directory -Path (Join-Path $tempDir "frontend")

# --- 处理后端 ---
Write-Host "正在准备后端文件..."
$backendSrc = Join-Path $root "backend"
Copy-Item -Path "$backendSrc\*" -Destination $backendDest -Recurse
# 清理后端不需要的文件
$excludeBackend = @("venv", "__pycache__", ".git", ".idea", "*.pyc", "*.log")
foreach ($item in $excludeBackend) {
    Get-ChildItem -Path $backendDest -Include $item -Recurse -Force | Remove-Item -Recurse -Force
}

# --- 处理前端 ---
Write-Host "正在执行前端构建..."
# 确保使用相对路径 /api 以兼容 Nginx 代理
Set-Content -Path (Join-Path $root ".env.production") -Value "VITE_API_BASE_URL=/api"
cmd /c "npm run build"

Write-Host "正在准备前端文件..."
$distSrc = Join-Path $root "dist"
$webInstallScript = Join-Path $root "install_web.py"
Copy-Item -Path "$distSrc\*" -Destination $frontendDest -Recurse
Copy-Item -Path $webInstallScript -Destination $frontendDest

# --- 最终压缩 ---
Write-Host "正在生成 dp.zip..."
Compress-Archive -Path "$tempDir\*" -DestinationPath $zipFile

# 清理临时目录
Remove-Item -Recurse -Force $tempDir
Remove-Item (Join-Path $root ".env.production") -ErrorAction SilentlyContinue

Write-Host "=== 打包成功! ==="
Write-Host "文件位置: $zipFile"
Write-Host "压缩包内包含:"
Write-Host "  /backend (后端程序及 install.py)"
Write-Host "  /frontend (前端构建产物及 install_web.py)"
