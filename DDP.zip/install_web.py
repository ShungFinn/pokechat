#!/usr/bin/env python3
import os
import subprocess
import sys
import shutil

# 配置
INSTALL_DIR = "/var/www/pokemon-chat"
NGINX_CONFIG_PATH = "/etc/nginx/sites-available/pokemon-chat"
NGINX_ENABLED_PATH = "/etc/nginx/sites-enabled/pokemon-chat"
SOURCE_DIR = os.path.dirname(os.path.abspath(__file__))

def run_command(command):
    try:
        subprocess.check_call(command, shell=True)
    except subprocess.CalledProcessError as e:
        print(f"Error running command: {command}")
        sys.exit(1)

def main():
    if os.geteuid() != 0:
        print("请使用 root 权限运行此脚本 (sudo python3 install_web.py)")
        sys.exit(1)

    print("=== 开始安装前端服务 (Nginx) ===")

    # 1. 安装 Nginx
    print("[1/5] 检查 Nginx...")
    try:
        # 检查 nginx 是否已安装
        subprocess.check_call("which nginx", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("Nginx 已安装，跳过安装步骤。")
    except subprocess.CalledProcessError:
        print("Nginx 未安装，正在安装...")
        try:
            run_command("apt-get update && apt-get install -y nginx")
        except SystemExit:
            print("警告: apt-get 安装失败 (可能是 dpkg 锁被占用)。")
            print("尝试继续部署... 如果 Nginx 未运行，请手动安装: sudo apt install nginx")

    # 2. 部署静态文件
    print(f"[2/5] 部署静态文件到 {INSTALL_DIR} ...")
    if os.path.exists(INSTALL_DIR):
        shutil.rmtree(INSTALL_DIR)
    os.makedirs(INSTALL_DIR)
    
    # 检查 index.html 在哪里
    if os.path.exists(os.path.join(SOURCE_DIR, "index.html")):
        # 结构: .
        #       ├── index.html
        #       ├── assets/
        #       └── install_web.py
        src_dir = SOURCE_DIR
    elif os.path.exists(os.path.join(SOURCE_DIR, "dist", "index.html")):
        # 结构: .
        #       ├── dist/
        #       │   ├── index.html
        #       │   └── assets/
        #       └── install_web.py
        src_dir = os.path.join(SOURCE_DIR, "dist")
    else:
        print("错误: 找不到构建好的静态文件 (index.html)")
        sys.exit(1)

    # 复制文件
    for item in os.listdir(src_dir):
        s = os.path.join(src_dir, item)
        d = os.path.join(INSTALL_DIR, item)
        if s == os.path.abspath(__file__): # 跳过脚本自己
            continue
        if item == "dist" and src_dir == SOURCE_DIR: # 如果当前目录有 dist 文件夹且我们正在复制当前目录，可能要跳过？
            # 这里的逻辑稍微复杂，简化处理：
            # 如果 src_dir 是 dist，直接复制里面内容。
            # 如果 src_dir 是当前目录，复制除了 install_web.py 以外的所有
            pass

        if os.path.isdir(s):
            shutil.copytree(s, d, dirs_exist_ok=True)
        else:
            shutil.copy2(s, d)

    # 修正目录权限，确保 Nginx 用户 (www-data) 可以读取
    run_command(f"chown -R www-data:www-data {INSTALL_DIR}")
    run_command(f"chmod -R 755 {INSTALL_DIR}")

    # 3. 配置 Nginx
    print("[3/5] 配置 Nginx...")
    nginx_config = """
server {
    listen 9000;
    server_name _;
    
    root /var/www/pokemon-chat;
    index index.html;

    # 开启 gzip 压缩
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # 反向代理后端 API
    location /api/ {
        # 将 /api/xxx 重写为 /xxx 转发给后端
        rewrite ^/api/(.*) /$1 break;
        
        # 转发到本地后端端口
        proxy_pass http://127.0.0.1:7000;
        
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        
        # 传递真实 IP
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
"""
    with open(NGINX_CONFIG_PATH, "w") as f:
        f.write(nginx_config)

    # 4. 启用站点
    print("[4/5] 启用站点...")
    if os.path.exists(NGINX_ENABLED_PATH):
        os.remove(NGINX_ENABLED_PATH)
    os.symlink(NGINX_CONFIG_PATH, NGINX_ENABLED_PATH)
    
    # 删除默认配置（如果存在）以免冲突
    default_config = "/etc/nginx/sites-enabled/default"
    if os.path.exists(default_config):
        os.remove(default_config)

    # 5. 重启 Nginx
    print("[5/5] 重启 Nginx...")
    run_command("nginx -t")
    run_command("systemctl restart nginx")

    print("\n=== 安装完成! ===")
    print(f"前端已部署到: {INSTALL_DIR}")
    print("请在浏览器访问服务器 IP 查看效果。")
    print("后端 API 代理路径: /api/ -> http://localhost:7000/")

if __name__ == "__main__":
    main()
