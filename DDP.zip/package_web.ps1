$sourceDir = $PSScriptRoot
$distDir = Join-Path $sourceDir "dist"
$installScript = Join-Path $sourceDir "install_web.py"
$zipFile = Join-Path $sourceDir "frontend_deploy.zip"
$envFile = Join-Path $sourceDir ".env.production"

Write-Host "=== 开始打包前端项目 ==="

# 1. 创建生产环境配置
Write-Host "[1/4] 配置生产环境变量..."
# 写入 .env.production 以设置 API Base URL 为 /api
# 这样 Vite 构建时会把 API 地址替换为 /api，然后 Nginx 再转发
Set-Content -Path $envFile -Value "VITE_API_BASE_URL=/api"

# 2. 构建项目
Write-Host "[2/4] 执行构建 (npm run build)..."
# 使用 cmd /c 确保 npm 命令能正确执行
cmd /c "npm run build"

if ($LASTEXITCODE -ne 0) {
    Write-Error "构建失败，请检查错误日志。"
    Remove-Item $envFile -ErrorAction SilentlyContinue
    exit 1
}

# 3. 准备打包文件
Write-Host "[3/4] 准备打包文件..."
if (Test-Path $zipFile) { Remove-Item -Force $zipFile }

# 我们把 dist 下的所有文件和 install_web.py 打包到一起
# 为了方便解压后直接运行，我们不包含顶层目录，直接把 dist 内容放在根目录（或者放在一个文件夹里）
# 最好是创建一个临时目录来组织结构
$tempDir = Join-Path $sourceDir "frontend_temp_deploy"
if (Test-Path $tempDir) { Remove-Item -Recurse -Force $tempDir }
New-Item -ItemType Directory -Path $tempDir | Out-Null

# 复制 dist 内容到临时目录
Copy-Item -Path "$distDir\*" -Destination $tempDir -Recurse
# 复制安装脚本
Copy-Item -Path $installScript -Destination $tempDir

# 4. 压缩
Write-Host "[4/4] 压缩..."
Compress-Archive -Path "$tempDir\*" -DestinationPath $zipFile

# 清理
Remove-Item -Recurse -Force $tempDir
Remove-Item $envFile -ErrorAction SilentlyContinue

Write-Host "=== 打包完成! ==="
Write-Host "文件位置: $zipFile"
Write-Host "请将 frontend_deploy.zip 上传到 Ubuntu 服务器，解压后运行: sudo python3 install_web.py"
