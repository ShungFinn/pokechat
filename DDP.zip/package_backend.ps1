$sourceDir = Join-Path $PSScriptRoot "backend"
$tempDir = Join-Path $PSScriptRoot "backend_temp_deploy"
$zipFile = Join-Path $PSScriptRoot "backend_deploy.zip"

Write-Host "正在准备打包..."

# 1. 清理旧的临时文件和压缩包
if (Test-Path $tempDir) { Remove-Item -Recurse -Force $tempDir }
if (Test-Path $zipFile) { Remove-Item -Force $zipFile }

# 2. 创建临时目录
New-Item -ItemType Directory -Path $tempDir | Out-Null
$innerDir = Join-Path $tempDir "backend"
New-Item -ItemType Directory -Path $innerDir | Out-Null

# 3. 复制文件到临时目录
Copy-Item -Path "$sourceDir\*" -Destination $innerDir -Recurse

# 4. 删除不需要的文件和文件夹
$excludeItems = @("venv", "__pycache__", ".git", ".idea", "*.pyc", "*.log")

foreach ($item in $excludeItems) {
    Get-ChildItem -Path $innerDir -Include $item -Recurse -Force | Remove-Item -Recurse -Force
}

# 5. 压缩
Write-Host "正在压缩..."
Compress-Archive -Path "$innerDir" -DestinationPath $zipFile

# 6. 清理临时目录
Remove-Item -Recurse -Force $tempDir

Write-Host "打包完成! 文件位置: $zipFile"
Write-Host "请将 backend_deploy.zip 上传到 Ubuntu 服务器，解压后运行: sudo python3 install.py"
