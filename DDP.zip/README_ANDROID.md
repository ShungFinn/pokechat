# Android APK 构建指南

本项目已配置 Capacitor 以支持打包为 Android 应用。
后端 (`backend/`) 不包含在 APK 中，需要在服务器或本地电脑上运行。

## 1. 安装 Android 开发环境

由于你的电脑上尚未安装 Java 和 Android SDK，你需要安装 **Android Studio** 来获取这些工具。

1.  **下载 Android Studio**:
    *   访问官网: [https://developer.android.com/studio](https://developer.android.com/studio)
    *   下载并安装最新版本的 Android Studio。

2.  **首次运行设置**:
    *   安装完成后启动 Android Studio。
    *   按照向导进行设置，确保勾选安装 **Android SDK**、**Android SDK Platform-Tools** 和 **Android Virtual Device**。
    *   等待所有组件下载并安装完成。

3.  **配置环境变量 (可选但推荐)**:
    *   虽然 Android Studio 内部可以使用，但为了在命令行使用 `gradlew`，建议设置 `JAVA_HOME`。
    *   通常位于: `C:\Program Files\Android\Android Studio\jbr` (具体路径可能因版本而异)。

## 2. 配置后端地址

由于 APK 运行在手机或模拟器上，无法直接使用 `localhost` 访问电脑上的后端。

1.  找到你电脑的局域网 IP 地址 (例如 `192.168.1.100`)。
2.  修改 `.env` 文件中的 `VITE_API_BASE_URL`：
    ```env
    VITE_API_BASE_URL=http://192.168.31.218:8000
    ```
    *(注意：如果使用模拟器，可以使用 `http://10.0.2.2:8000`)*

3.  重新构建前端代码：
    ```bash
    npm run build
    # 或者如果遇到类型错误，可以使用:
    npx vite build
    ```

4.  同步更改到 Android 项目：
    ```bash
    npx cap sync
    ```

## 3. 打包 APK

### 方法 A: 使用 Android Studio (推荐)

1.  **打开项目**:
    *   启动 Android Studio。
    *   选择 `Open`，然后选择本项目下的 `android` 文件夹 (路径: `e:\chat\android`)。

2.  **等待同步**:
    *   等待底部的 Gradle Sync 进度条完成（第一次可能比较慢，已配置阿里云镜像加速）。

3.  **构建 APK**:
    *   点击菜单栏的 **Build**。
    *   选择 **Generate App Bundles or APKs** (或者 `Build Bundle(s) / APK(s)` > `Build APK(s)`)。
    *   如果弹出选择框，选择 **APK** 并点击 Next。
    *   选择 **debug** 版本（用于测试），然后点击 **Create** / **Finish**。

4.  **获取 APK**:
    *   构建完成后，右下角会弹出提示 "APK(s) generated successfully"。
    *   点击提示中的 **locate** 链接，或者手动找到文件：
        `android/app/build/outputs/apk/debug/app-debug.apk`
    *   将这个文件发送到你的手机上安装即可。

### 方法 C: 生成签名版 APK (如果误点了 "Generate Signed Bundle/APK")

如果你在菜单里点了 **Generate Signed Bundle / APK**，你会看到一个要求输入 Key Store 的界面。
虽然测试不需要签名，但如果你想继续：

1.  **创建密钥库**:
    *   点击 **Create new...** 按钮。
    *   **Key store path**: 点击文件夹图标，选择一个位置（比如桌面），文件名填 `my-key.jks`。
    *   **Password**: 设置一个密码（比如 `123456`），确认密码也填这个。
    *   **Alias**: 保持默认 `key0` 即可。
    *   **Key Password**: 设置一个密码（比如 `123456`），确认密码也填这个。
    *   **Certificate**: 在 "First and Last Name" 填入你的名字，其他留空即可。
    *   点击 **OK**。

2.  **填写信息**:
    *   回到原来的界面，密码应该会自动填充（如果没有，输入刚才设置的 `123456`）。
    *   点击 **Next**。

3.  **生成**:
    *   选择 **release** 或 **debug**。
    *   点击 **Create** / **Finish**。


在项目根目录下运行：

```bash
cd android
./gradlew assembleDebug
```

生成的 APK 位于 `android/app/build/outputs/apk/debug/app-debug.apk`。

## 7. 常见问题排查 (Troubleshooting)

### Q1: App 打开后显示 "Failed to fetch" 或网络错误
这通常是因为手机无法连接到电脑的后端服务。请按以下步骤检查：

1.  **检查 WiFi 连接**: 确保手机和电脑连接在 **同一个 WiFi** 下。
2.  **检查防火墙**: Windows 防火墙可能会拦截 8000 端口。
    *   **临时关闭防火墙测试**: 搜索 "防火墙和网络保护"，点击当前网络（如专用网络），关闭 "Microsoft Defender 防火墙"。如果关闭后能连上，说明是防火墙问题。
    *   **添加允许规则 (推荐)**:
        1.  搜索 "高级安全 Windows Defender 防火墙"。
        2.  点击左侧 "入站规则" -> 右侧 "新建规则"。
        3.  选择 "端口" -> 下一步。
        4.  选择 "TCP"，特定本地端口填 `8000` -> 下一步。
        5.  选择 "允许连接" -> 下一步 -> 下一步。
        6.  名称填 "Allow Python Backend" -> 完成。
3.  **检查 IP 地址**: 确保 `.env` 文件里的 IP (目前是 `192.168.31.218`) 是电脑当前的 IP。如果电脑 IP 变了，需要修改 `.env` 并重新打包。

### Q2: 命令行构建失败 (gradlew)
如果提示 `JAVA_HOME is not set`，请直接使用 **Android Studio** 进行构建（参考 "方法 A"），因为 Android Studio 自带了 Java 环境，不需要额外配置。

### Q3: 更新代码后 App 没变化
如果你修改了前端代码或 IP 配置，必须执行以下步骤更新 App：
1.  在终端运行: `npm run build`
2.  在终端运行: `npx cap sync`
3.  在 Android Studio 中点击 "Run" (绿色三角形) 或重新生成 APK。
