import os
import zipfile
import shutil

def zip_project(output_filename):
    # 获取当前脚本所在目录作为项目根目录
    project_root = os.path.dirname(os.path.abspath(__file__))
    output_path = os.path.join(project_root, output_filename)
    
    # 需要排除的文件和目录
    exclude_dirs = {
        'node_modules', 'venv', '__pycache__', '.git', '.idea', '.vscode', 
        'dist', 'build', 'android', 'ios', 'coverage'
    }
    exclude_files = {
        output_filename, 'DP.zip', '.DS_Store', 'Thumbs.db', 'package-lock.json', 'yarn.lock'
    }
    exclude_extensions = {'.pyc', '.pyo', '.pyd', '.log', '.zip'}

    print(f"开始打包项目到 {output_filename} ...")
    
    try:
        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(project_root):
                # 修改 dirs 列表以原地排除不需要的目录
                dirs[:] = [d for d in dirs if d not in exclude_dirs]
                
                for file in files:
                    if file in exclude_files:
                        continue
                    if any(file.endswith(ext) for ext in exclude_extensions):
                        continue
                        
                    file_path = os.path.join(root, file)
                    # 计算在压缩包中的相对路径
                    arcname = os.path.relpath(file_path, project_root)
                    
                    print(f"添加: {arcname}")
                    zipf.write(file_path, arcname)
                    
        print(f"\n打包成功! 文件位于: {output_path}")
        print(f"文件大小: {os.path.getsize(output_path) / (1024*1024):.2f} MB")
        
    except Exception as e:
        print(f"打包失败: {e}")

if __name__ == "__main__":
    zip_project("DDP.zip")
