import { useEffect, useState } from 'react';
import { useLayoutStore } from './store/useLayoutStore';
import { useAuthStore } from './store/useAuthStore';
import ChatPanel from './components/ChatPanel';
import ToolPanel from './components/ToolPanel';
import Login from './components/Login';
import AdminPanel from './components/AdminPanel';
import Onboarding from './components/Onboarding';
import ChangePasswordModal from './components/ChangePasswordModal';
import { MessageSquare, LayoutGrid } from 'lucide-react';
import './App.css';
import 'react-grid-layout/css/styles.css';
import 'react-resizable/css/styles.css';

function App() {
  const { isAuthenticated, user, refreshUser } = useAuthStore();
  const { 
    isChatMinimized, 
    isToolPanelCollapsed, 
    setToolPanelCollapsed,
    mobileActiveView,
    setMobileActiveView
  } = useLayoutStore();

  const [isMobile, setIsMobile] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);

  // Responsive logic
  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 800;
      setIsMobile(mobile);
      
      if (mobile) {
        setToolPanelCollapsed(true); // Ensure tool panel doesn't interfere with flex layout initially
      } else {
        setToolPanelCollapsed(false);
      }
    };

    // Initial check
    handleResize();

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [setToolPanelCollapsed]);

  useEffect(() => {
    // Safety check: if authenticated but no user/token, logout
    if (isAuthenticated && (!user || !user.token)) {
      console.warn('Inconsistent auth state detected, logging out...');
      useAuthStore.getState().logout();
    }
  }, [isAuthenticated, user]);

  useEffect(() => {
    if (isAuthenticated) {
        refreshUser();
    }
  }, [isAuthenticated]); // Only refresh when auth state changes (e.g. initial load)

  if (!isAuthenticated) {
    return <Login />;
  }

  // Check for first login (onboarding)
  if (user?.isFirstLogin) {
    return <Onboarding />;
  }

  // Check for forced password change
  if (user?.must_change_password) {
    return <ChangePasswordModal />;
  }

  // Admin Panel View
  if (showAdminPanel && user?.role === 'admin') {
    return <AdminPanel onBack={() => setShowAdminPanel(false)} />;
  }

  // Pass admin toggle to ChatPanel via props or store? 
  // Easier to just pass a prop if ChatPanel was in App, but it is.
  // Wait, ChatPanel needs to know about Admin status.
  // Let's pass a function to ChatPanel to toggle Admin View if user is admin.

  // Mobile View Render
  if (isMobile) {
    return (
      <div className="app-container mobile">
        <div className="mobile-content">
          {mobileActiveView === 'chat' ? (
            <div className="mobile-view chat-view">
              <ChatPanel onOpenAdmin={user?.role === 'admin' ? () => setShowAdminPanel(true) : undefined} />
            </div>
          ) : (
            <div className="mobile-view tool-view">
              <ToolPanel />
            </div>
          )}
        </div>

        {/* Mobile Bottom Navigation */}
        <div className="mobile-nav">
          <button 
            className={`nav-item ${mobileActiveView === 'chat' ? 'active' : ''}`}
            onClick={() => setMobileActiveView('chat')}
          >
            <MessageSquare size={20} />
            <span>Chat</span>
          </button>
          <button 
            className={`nav-item ${mobileActiveView === 'tools' ? 'active' : ''}`}
            onClick={() => setMobileActiveView('tools')}
          >
            <LayoutGrid size={20} />
            <span>Tools</span>
          </button>
        </div>
      </div>
    );
  }

  // Desktop View Render
  return (
    <div className="app-container desktop">
      {/* Left Chat Panel */}
      <div className={`chat-section ${isChatMinimized ? 'minimized' : 'expanded'}`}>
        <ChatPanel onOpenAdmin={user?.role === 'admin' ? () => setShowAdminPanel(true) : undefined} />
      </div>

      {/* Right Tool Panel */}
      <div className={`tool-section ${isToolPanelCollapsed ? 'collapsed' : ''}`}>
         {/* Only render ToolPanel content if not collapsed to save resources/avoid layout issues */}
         {!isToolPanelCollapsed && <ToolPanel />}
      </div>
    </div>
  );
}

export default App;

