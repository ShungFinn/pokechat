import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { api } from '../services/api';

export interface User {
  username: string;
  role: 'admin' | 'user';
  token?: string;
  isFirstLogin?: boolean;
  must_change_password?: boolean;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (username: string, password: string) => Promise<void>;
  register: (username: string, password: string) => Promise<void>;
  logout: () => void;
  refreshUser: () => Promise<void>;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,

      login: async (username, password) => {
        try {
          const data = await api.login(username, password);
          const user = await api.getMe(data.access_token);
          set({ 
            user: { ...user, token: data.access_token }, 
            isAuthenticated: true 
          });
        } catch (error) {
          throw error;
        }
      },

      register: async (username, password) => {
        await api.register(username, password);
      },

      logout: () => set({ user: null, isAuthenticated: false }),

      refreshUser: async () => {
        const { user } = get();
        if (user && user.token) {
            try {
                const updatedUser = await api.getMe(user.token);
                set({ user: { ...updatedUser, token: user.token } });
            } catch (error) {
                console.error("Failed to refresh user", error);
            }
        }
      }
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
    }
  )
);
