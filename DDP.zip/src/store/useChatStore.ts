import { create } from 'zustand';
import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import { api } from '../services/api';
import { useAuthStore } from './useAuthStore';
import { API_BASE_URL } from '../config';

type NotificationPermissionState = 'granted' | 'denied' | 'prompt' | 'unknown';

const playNotificationSound = () => {
  try {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(400, audioContext.currentTime + 0.1);
    
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);

    oscillator.start();
    oscillator.stop(audioContext.currentTime + 0.1);
  } catch (e) {
    console.error("Audio play failed", e);
  }
};

export interface Message {
  id: string;
  senderName: string;
  senderAvatar?: string;
  content: string;
  timestamp: string;
  role: 'system' | 'user' | 'ai' | 'other';
  isCurrentUser?: boolean;
  type?: 'text' | 'image' | 'file' | 'recalled';
  file?: {
    name: string;
    size: string;
    url: string;
    fileType: string;
  };
  rawTimestamp?: number;
}

export interface ChatSession {
  id: string;
  name: string;
  avatar?: string;
  membersCount: number;
  onlineCount: number;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount?: number;
  isMuted?: boolean;
  creatorId?: string; // Track who created the group
  members?: string[]; // Track members for "Ghost Mode" check (though logic might just be "admin sees all")
}

interface ChatState {
  sessions: ChatSession[];
  messages: { [key: string]: Message[] };
  unreadCounts: { [key: string]: number };
  notificationPermission: NotificationPermissionState;
  
  // Actions
  fetchSessions: () => Promise<void>;
  addSession: (session: ChatSession) => void;
  removeSession: (sessionId: string) => void;
  updateSession: (sessionId: string, updates: Partial<ChatSession>) => void;
  addMessage: (sessionId: string, message: Message) => void;
  updateMessage: (sessionId: string, messageId: string, updates: Partial<Message>) => void;
  removeMessage: (sessionId: string, messageId: string) => void;
  setUnreadCount: (sessionId: string, count: number) => void;
  resetUnreadCount: (sessionId: string) => void;
  incrementUnreadCount: (sessionId: string) => void;
  
  // Ghost Mode
  viewingGhostSessionId: string | null;
  setViewingGhostSessionId: (id: string | null) => void;
  
  toggleMute: (sessionId: string) => Promise<void>;
  
  // WebSocket
  socket: WebSocket | null;
  connectSocket: () => void;
  disconnectSocket: () => void;
  sendMessage: (sessionId: string, content: string) => void;

  ensureAndroidNotificationPermission: () => Promise<void>;
}

export const useChatStore = create<ChatState>()((set, get) => ({
  sessions: [],
  messages: {},
  unreadCounts: {},
  notificationPermission: 'unknown',
  viewingGhostSessionId: null,
  socket: null,

  ensureAndroidNotificationPermission: async () => {
    if (!Capacitor.isNativePlatform() || Capacitor.getPlatform() !== 'android') return;

    const current = await LocalNotifications.checkPermissions();
    const currentDisplay = current.display;
    if (currentDisplay === 'granted') {
      set({ notificationPermission: 'granted' });
      return;
    }
    if (currentDisplay === 'denied') {
      set({ notificationPermission: 'denied' });
      return;
    }

    const requested = await LocalNotifications.requestPermissions();
    if (requested.display === 'granted') {
      set({ notificationPermission: 'granted' });
    } else if (requested.display === 'denied') {
      set({ notificationPermission: 'denied' });
    } else {
      set({ notificationPermission: 'prompt' });
    }
  },

  connectSocket: () => {
    const { user } = useAuthStore.getState();
    if (!user?.token || get().socket) return;

    const wsUrl = API_BASE_URL.replace(/^http/, 'ws') + `/ws/${user.token}`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      console.log('WebSocket Connected');
    };

    socket.onmessage = (event) => {
      try {
        const messageData = JSON.parse(event.data);
        const sessionId = messageData.sessionId;
        if (!sessionId) return;

        const currentMessages = get().messages[sessionId] || [];
        const exists = currentMessages.some(m => m.id === messageData.id);

        if (!exists) {
          const isMe = messageData.senderName === user.username;
          const fullMessage: Message = {
            ...messageData,
            isCurrentUser: isMe,
          };
          get().addMessage(sessionId, fullMessage);

          if (!isMe) {
            playNotificationSound();
            get().incrementUnreadCount(sessionId);
            if (Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android' && get().notificationPermission === 'granted') {
              const messageTitle = fullMessage.senderName || 'New message';
              const messageBody = fullMessage.content || '';
              void LocalNotifications.schedule({
                notifications: [
                  {
                    id: Math.floor(Date.now() % 2147483647),
                    title: messageTitle,
                    body: messageBody,
                    schedule: { at: new Date(Date.now() + 250) }
                  }
                ]
              }).catch(() => undefined);
            }
          }
        }
      } catch (e) {
        console.error("WS Message Error", e);
      }
    };

    socket.onclose = () => {
      console.log('WebSocket Disconnected');
      set({ socket: null });
    };

    set({ socket });
  },

  disconnectSocket: () => {
    const { socket } = get();
    if (socket) {
      socket.close();
      set({ socket: null });
    }
  },

  sendMessage: (sessionId, content) => {
    const { socket } = get();
    const user = useAuthStore.getState().user;
    if (!user) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      senderName: user.username,
      senderAvatar: `https://ui-avatars.com/api/?name=${user.username}&background=random&color=fff`,
      content: content,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      role: 'user',
      isCurrentUser: true,
      type: 'text',
      rawTimestamp: Date.now()
    };

    get().addMessage(sessionId, newMessage);

    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        ...newMessage,
        sessionId
      }));
    } else {
      get().connectSocket();
    }
  },

  fetchSessions: async () => {
    try {
      const user = useAuthStore.getState().user;
      const token = user?.token;
      if (!token) return;

      const teams = user.role === 'admin' ? await api.getAllTeams(token) : await api.getTeams(token);
      const sessions: ChatSession[] = teams.map(team => ({
        id: team.id.toString(),
        name: team.name,
        membersCount: team.members_count || 1,
        onlineCount: team.online_count || 1,
        lastMessage: 'Welcome!',
        lastMessageTime: new Date(team.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        unreadCount: 0,
        creatorId: 'system',
        members: [],
        isMuted: team.is_muted || false
      }));

      set({ sessions });
    } catch (error) {
      console.error("Failed to fetch sessions", error);
    }
  },

  addSession: (session) => set((state) => ({
    sessions: [...state.sessions, session],
    messages: { ...state.messages, [session.id]: [] }
  })),

  removeSession: (sessionId) => set((state) => {
    const { [sessionId]: _, ...restMessages } = state.messages;
    const { [sessionId]: __, ...restUnread } = state.unreadCounts;
    return {
      sessions: state.sessions.filter(s => s.id !== sessionId),
      messages: restMessages,
      unreadCounts: restUnread,
      viewingGhostSessionId: state.viewingGhostSessionId === sessionId ? null : state.viewingGhostSessionId
    };
  }),

  updateSession: (sessionId, updates) => set((state) => ({
    sessions: state.sessions.map(s => s.id === sessionId ? { ...s, ...updates } : s)
  })),

  toggleMute: async (sessionId) => {
    const session = get().sessions.find(s => s.id === sessionId);
    if (!session) return;

    const newMutedState = !session.isMuted;

    set((state) => ({
      sessions: state.sessions.map(s => s.id === sessionId ? { ...s, isMuted: newMutedState } : s)
    }));

    try {
      const user = useAuthStore.getState().user;
      if (user?.token) {
        await api.toggleMute(user.token, sessionId, newMutedState);
      }
    } catch (error) {
      set((state) => ({
        sessions: state.sessions.map(s => s.id === sessionId ? { ...s, isMuted: !newMutedState } : s)
      }));
    }
  },

  addMessage: (sessionId, message) => set((state) => ({
    messages: {
      ...state.messages,
      [sessionId]: [...(state.messages[sessionId] || []), message]
    },
    sessions: state.sessions.map(s =>
      s.id === sessionId
        ? { ...s, lastMessage: message.content, lastMessageTime: message.timestamp }
        : s
    )
  })),

  updateMessage: (sessionId, messageId, updates) => set((state) => ({
    messages: {
      ...state.messages,
      [sessionId]: state.messages[sessionId]?.map(msg =>
        msg.id === messageId ? { ...msg, ...updates } : msg
      ) || []
    }
  })),

  removeMessage: (sessionId, messageId) => set((state) => ({
    messages: {
      ...state.messages,
      [sessionId]: state.messages[sessionId]?.filter(msg => msg.id !== messageId) || []
    }
  })),

  setUnreadCount: (sessionId, count) => set((state) => ({
    unreadCounts: { ...state.unreadCounts, [sessionId]: count }
  })),

  resetUnreadCount: (sessionId) => set((state) => ({
    unreadCounts: { ...state.unreadCounts, [sessionId]: 0 }
  })),

  incrementUnreadCount: (sessionId) => set((state) => ({
    unreadCounts: { ...state.unreadCounts, [sessionId]: (state.unreadCounts[sessionId] || 0) + 1 }
  })),

  setViewingGhostSessionId: (id) => set({ viewingGhostSessionId: id }),
}));
