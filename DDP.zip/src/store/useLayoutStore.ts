import { create } from 'zustand';

interface LayoutState {
  isChatMinimized: boolean;
  isToolPanelCollapsed: boolean;
  mobileActiveView: 'chat' | 'tools'; // New state for mobile view switching
  toggleChat: () => void;
  toggleToolPanel: () => void;
  setChatMinimized: (minimized: boolean) => void;
  setToolPanelCollapsed: (collapsed: boolean) => void;
  setMobileActiveView: (view: 'chat' | 'tools') => void;
}

export const useLayoutStore = create<LayoutState>((set) => ({
  isChatMinimized: false,
  isToolPanelCollapsed: false,
  mobileActiveView: 'chat', // Default to chat on mobile
  toggleChat: () => set((state) => ({ isChatMinimized: !state.isChatMinimized })),
  toggleToolPanel: () => set((state) => ({ isToolPanelCollapsed: !state.isToolPanelCollapsed })),
  setChatMinimized: (minimized) => set({ isChatMinimized: minimized }),
  setToolPanelCollapsed: (collapsed) => set({ isToolPanelCollapsed: collapsed }),
  setMobileActiveView: (view) => set({ mobileActiveView: view }),
}));
