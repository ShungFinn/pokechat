// ==========================================
// Backend API Configuration
// ==========================================

// Change this URL to point to your deployed backend
// For local development, it defaults to http://localhost:8000
// Use environment variable VITE_API_BASE_URL if available
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

// API Endpoints
export const ENDPOINTS = {
  REGISTER: `${API_BASE_URL}/register`,
  LOGIN: `${API_BASE_URL}/token`,
  USERS_ME: `${API_BASE_URL}/users/me`,
  USERS: `${API_BASE_URL}/users/`,
  TEAMS: `${API_BASE_URL}/teams`,
  TEAMS_ALL: `${API_BASE_URL}/teams/all`,
};

// ==========================================
// Config End
// ==========================================
