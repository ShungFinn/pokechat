import React from 'react';
import ChangePasswordModal from '../ChangePasswordModal';

const Onboarding: React.FC = () => {
  return <ChangePasswordModal />;
};

export default Onboarding;
