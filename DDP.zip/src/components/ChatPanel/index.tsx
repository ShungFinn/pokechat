import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, Minus, Send, Users, MoreVertical, ChevronLeft, Bell, BellOff, LogOut, Plus, Shield, Paperclip, Image as ImageIcon, FileText, Trash2, RotateCcw, Download, X, File } from 'lucide-react';
import { Capacitor } from '@capacitor/core';
import { useLayoutStore } from '../../store/useLayoutStore';
import { useAuthStore } from '../../store/useAuthStore';
import { useChatStore, ChatSession, Message } from '../../store/useChatStore';
import './styles.css';

interface ChatPanelProps {
  onOpenAdmin?: () => void;
}

class ChatErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; errorMessage: string | null }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, errorMessage: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, errorMessage: error?.message || String(error) };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("ChatPanel Error:", error, errorInfo);
    this.setState({ errorMessage: error?.message || String(error) });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="chat-panel" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column', gap: '1rem', padding: '20px' }}>
          <h3>Something went wrong.</h3>
          <p>We encountered an error while loading the chat.</p>
          {this.state.errorMessage ? (
            <pre style={{ maxWidth: 520, whiteSpace: 'pre-wrap', opacity: 0.8 }}>
              {this.state.errorMessage}
            </pre>
          ) : null}
          <button 
            className="icon-btn back-btn" 
            onClick={() => {
              this.setState({ hasError: false, errorMessage: null });
              window.location.reload(); 
            }}
            style={{ width: 'auto', padding: '0 1rem', height: '36px', borderRadius: '18px', background: '#e0e0e0', color: '#333' }}
          >
            Reload Application
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

const ChatPanelContent: React.FC<ChatPanelProps> = ({ onOpenAdmin }) => {
  const { isChatMinimized, toggleChat } = useLayoutStore();
  const { user, logout } = useAuthStore();
  const isAndroidNative = Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
  const { 
    sessions, 
    messages, 
    unreadCounts, 
    addSession, 
    removeSession, 
    addMessage, 
    updateMessage,
    removeMessage,
    setUnreadCount, 
    updateSession,
    viewingGhostSessionId,
    setViewingGhostSessionId,
    fetchSessions,
    toggleMute,
    connectSocket,
    disconnectSocket,
    sendMessage,
    notificationPermission,
    ensureAndroidNotificationPermission
  } = useChatStore();

  useEffect(() => {
    console.log('ChatStore methods:', { connectSocket, disconnectSocket, sendMessage });
    if (user?.token) {
      if (fetchSessions) fetchSessions();
      if (ensureAndroidNotificationPermission) void ensureAndroidNotificationPermission();
      if (connectSocket) {
        connectSocket();
      } else {
        console.error('connectSocket is undefined');
      }
    }
    return () => {
      if (disconnectSocket) disconnectSocket();
    };
  }, [fetchSessions, user?.token, connectSocket, disconnectSocket]);

  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [inputText, setInputText] = useState('');
  const [isMobile, setIsMobile] = useState(window.innerWidth < 800);
  
  // New States
  const [joinCode, setJoinCode] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isHeaderExpanded, setIsHeaderExpanded] = useState(false);
  const [showQuitConfirm, setShowQuitConfirm] = useState(false);
  
  // File & Attachment States
  const [isAttachmentMenuOpen, setIsAttachmentMenuOpen] = useState(false);
  const [showFilesModal, setShowFilesModal] = useState(false);
  const [contextMenu, setContextMenu] = useState<{ x: number, y: number, messageId: string } | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const uploadTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  // Creation Flow States
  const [showCreateConfirm, setShowCreateConfirm] = useState(false);
  const [pendingJoinCode, setPendingJoinCode] = useState('');
  const [newGroupName, setNewGroupName] = useState('');

  const activeChatIdRef = useRef<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const attachmentMenuRef = useRef<HTMLDivElement>(null);

  // Sync activeChatId with ghost mode from Admin Panel
  useEffect(() => {
    if (viewingGhostSessionId) {
      setActiveChatId(viewingGhostSessionId);
    }
  }, [viewingGhostSessionId]);

  // Close menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
      if (attachmentMenuRef.current && !attachmentMenuRef.current.contains(event.target as Node)) {
        setIsAttachmentMenuOpen(false);
      }
      setContextMenu(null);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    activeChatIdRef.current = activeChatId;
    if (activeChatId) {
      setUnreadCount(activeChatId, 0);

      setInputText('');
      setIsMenuOpen(false); // Close menu on chat switch
      setIsHeaderExpanded(false); // Reset expansion
    }
  }, [activeChatId]);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 800);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleBack = () => {
    setActiveChatId(null);
    setViewingGhostSessionId(null);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, activeChatId]);

  const handleSendMessage = () => {
    if (!inputText.trim() || !activeChatId) return;

    sendMessage(activeChatId, inputText);
    setInputText('');
  };

  const handleFileUploadMock = () => {
    if (!activeChatId) return;
    setIsAttachmentMenuOpen(false);
    alert("File upload is not yet supported by the backend.");
  };

  const cancelUpload = () => {
    if (uploadTimeoutRef.current) {
      clearTimeout(uploadTimeoutRef.current);
      uploadTimeoutRef.current = null;
      setIsUploading(false);
    }
  };

  const handleRecallMessage = (messageId: string) => {
    if (!activeChatId) return;
    updateMessage(activeChatId, messageId, {
      type: 'recalled',
      content: 'Message recalled'
    });
    setContextMenu(null);
  };

  const handleDeleteMessage = (messageId: string) => {
    if (!activeChatId) return;
    removeMessage(activeChatId, messageId);
    setContextMenu(null);
  };

  const handleDownloadFile = (fileUrl: string, fileName: string) => {
    // Real download logic or keep alert for now if no backend url
    // alert(`Downloading ${fileName}...`);
    // For now we just console log as we don't have real files
    console.log(`Downloading ${fileName}...`, fileUrl);
  };

  const handleContextMenu = (e: React.MouseEvent, message: Message) => {
    e.preventDefault();
    // Only show for user's own messages (for recall) or if admin (for delete)
    // Recall limit: 10 mins
    const isOwnMessage = message.senderName === user?.username;
    const isRecallable = isOwnMessage && message.type !== 'recalled' && 
      (Date.now() - (message.rawTimestamp || 0)) < 10 * 60 * 1000;
      
    const isDeletable = user?.role === 'admin' || (isOwnMessage && message.type === 'file');

    if (isRecallable || isDeletable) {
      setContextMenu({ x: e.clientX, y: e.clientY, messageId: message.id });
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  const handleJoinGroup = () => {
    if (!joinCode.trim()) return;

    // Check if group already exists
    const existingGroup = sessions.find(s => s.id === joinCode.toLowerCase() || s.name.toLowerCase() === joinCode.toLowerCase());
    if (existingGroup) {
      // Add user to members if not already
      if (!existingGroup.members?.includes(user?.username || '')) {
         const updatedMembers = [...(existingGroup.members || []), user?.username || ''];
         updateSession(existingGroup.id, {
           members: updatedMembers,
           membersCount: (existingGroup.membersCount || 0) + 1
         });
      }

      setActiveChatId(existingGroup.id);
      setJoinCode('');
      return;
    }

    // Group not found. Check creation limit for non-admins
    if (user?.role !== 'admin') {
      const myCreatedCount = sessions.filter(s => s.creatorId === user?.username).length;
      if (myCreatedCount >= 1) {
        alert("Creation Limit Reached: You can only create 1 group chat.");
        return;
      }
    }

    // Prompt to create
    setPendingJoinCode(joinCode);
    setNewGroupName(joinCode); // Default name is the code
    setShowCreateConfirm(true);
  };

  const confirmCreateGroup = () => {
    if (!newGroupName.trim()) return;

    // Create a safe, unique ID
    const safeIdPart = pendingJoinCode.toLowerCase().replace(/[^a-z0-9]/g, '_');
    const newGroupId = `${safeIdPart}_${Date.now()}`;
    
    const newSession: ChatSession = {
      id: newGroupId,
      name: newGroupName,
      membersCount: 1,
      onlineCount: 1,
      lastMessage: 'Group created',
      lastMessageTime: 'Just now',
      avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(newGroupName)}&background=random&color=fff`,
      creatorId: user?.username || 'system',
      members: [user?.username || 'unknown']
    };

    addSession(newSession);
    addMessage(newGroupId, {
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      senderName: 'System',
      senderAvatar: `https://ui-avatars.com/api/?name=System&background=333&color=fff`,
      content: `Group "${newGroupName}" created by ${user?.username || 'User'}`,
      timestamp: 'Just now',
      role: 'system',
      type: 'text',
      rawTimestamp: Date.now()
    });

    setActiveChatId(newGroupId);
    setJoinCode('');
    setShowCreateConfirm(false);
    setPendingJoinCode('');
    setNewGroupName('');
  };

  const handleMuteToggle = () => {
    if (!activeChatId) return;
    toggleMute(activeChatId);
    setIsMenuOpen(false);
  };

  const handleViewFiles = () => {
    setShowFilesModal(true);
    setIsMenuOpen(false);
  };

  const handleQuitGroup = () => {
    // Prevent quitting the default group
    if (activeSession?.name === 'Pokemon Centre') {
        alert("You cannot leave the Pokemon Centre.");
        return;
    }
    setIsMenuOpen(false);
    setShowQuitConfirm(true);
  };

  const confirmQuit = () => {
    if (!activeChatId) return;
    
    const session = sessions.find(s => s.id === activeChatId);
    if (!session) return;

    // If last member, disband
    if (session.membersCount <= 1) {
      removeSession(activeChatId);
    } else {
       // Leave group: update members and count
       const updatedMembers = session.members?.filter(m => m !== user?.username) || [];
       updateSession(activeChatId, {
         membersCount: Math.max(0, session.membersCount - 1),
         members: updatedMembers
       });
    }

    setActiveChatId(null);
    setViewingGhostSessionId(null);
    setShowQuitConfirm(false);
  };

  if (isChatMinimized && !isMobile) {
    return (
      <div className="chat-panel minimized-content" onClick={toggleChat}>
        <div className="minimized-icon">
          <MessageSquare size={24} />
        </div>
        <span className="vertical-text">Chat</span>
      </div>
    );
  }

  // Chat List View
    if (!activeChatId) {
      // FIX: Show ALL fetched sessions directly.
      // The backend logic (getTeams) handles permission filtering (e.g. user's own groups + public groups).
      // We should trust the store's session list and not filter by 'members' locally,
      // because 'members' property might be incomplete or missing in the session summary from backend.
      const sessionsList = sessions.map(session => {
        const sessionMessages = messages[session.id];
        const lastMsg = sessionMessages?.[sessionMessages.length - 1];
        return {
          ...session,
          lastMessage: lastMsg ? lastMsg.content : session.lastMessage,
          lastMessageTime: lastMsg ? lastMsg.timestamp : session.lastMessageTime
        };
      });

    return (
      <div className="chat-panel">
        <div className="chat-header">
          <div className="header-info">
             <span style={{ fontWeight: 600, fontSize: '1rem', color: '#e0e0e0' }}>Messages</span>
          </div>
          <div className="header-actions">
            {!isMobile && (
              <button className="icon-btn minimize-btn" onClick={toggleChat} title="Minimize">
                <Minus size={18} />
              </button>
            )}
          </div>
        </div>
        <div className="chat-list-container">
          {sessionsList.map(session => (
            <div 
              key={session.id} 
              className="chat-list-item"
              onClick={() => setActiveChatId(session.id)}
            >
              <div className="chat-item-avatar">
                {session.avatar ? (
                  <img src={session.avatar} alt={session.name} />
                ) : (
                  <div className="avatar-placeholder">{session.name[0]}</div>
                )}
              </div>
              <div className="chat-item-info">
                <div className="chat-item-top">
                  <span className="chat-item-name">
                    {session.name}
                    {session.isMuted && <BellOff size={12} className="muted-icon" />}
                  </span>
                  <span className="chat-item-time">{session.lastMessageTime}</span>
                </div>
                <div className="chat-item-bottom">
                  <span className="chat-item-preview">{session.lastMessage}</span>
                  {unreadCounts && unreadCounts[session.id] ? (
                    <span className="chat-item-badge">{unreadCounts[session.id]}</span>
                  ) : null}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {(!sessions || sessions.length === 0) && (
          <div style={{ padding: '20px', textAlign: 'center', color: '#888' }}>
            <p>No conversations yet.</p>
            <p style={{ fontSize: '0.8rem', marginTop: '10px' }}>
              Debug Info: {sessions ? sessions.length : 'null'} sessions loaded.
              <br/>
              User: {user?.username || 'None'}
            </p>
            <button 
              onClick={() => fetchSessions()} 
              style={{ marginTop: '10px', padding: '5px 10px', cursor: 'pointer' }}
            >
              Force Refresh
            </button>
          </div>
        )}
          
        <div className="sidebar-footer">
          {/* Join Group Section */}
          <div className="join-group-section">
            <div className="join-group-title">Join or Create Group</div>
            <div className="join-group-form">
              <input 
                type="text" 
                className="join-group-input"
                placeholder="Enter group code to join or create..."
                maxLength={20}
                value={joinCode}
                onChange={(e) => setJoinCode(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleJoinGroup()}
              />
              <button className="join-group-btn" onClick={handleJoinGroup}>
                <Plus size={16} />
              </button>
            </div>
          </div>

          {/* User Profile Section */}
          <div className="user-profile-section">
            <div className="user-info">
              <div className="user-avatar-small">
                <img src={`https://ui-avatars.com/api/?name=${user?.username}&background=random&color=fff`} alt={user?.username} />
              </div>
              <div className="user-details">
                <span className="user-name">{user?.username}</span>
                <span className="user-role-badge">{user?.role}</span>
              </div>
            </div>
            <div style={{ display: 'flex', gap: '4px' }}>
              {user?.role === 'admin' && onOpenAdmin && (
                <button className="logout-btn" onClick={onOpenAdmin} title="Admin Panel">
                  <Shield size={18} />
                </button>
              )}
              {isAndroidNative ? (
                <button
                  className="logout-btn"
                  onClick={() => void ensureAndroidNotificationPermission()}
                  title={notificationPermission === 'granted' ? 'Notifications enabled' : 'Enable notifications'}
                  disabled={notificationPermission === 'granted'}
                  style={notificationPermission === 'granted' ? { opacity: 0.6, cursor: 'default' } : undefined}
                >
                  <Bell size={18} />
                </button>
              ) : null}
              <button className="logout-btn" onClick={logout} title="Logout">
                <LogOut size={18} />
              </button>
            </div>
          </div>
        </div>
        
        {/* Create Group Modal */}
        {showCreateConfirm && (
          <div className="modal-overlay">
            <div className="modal-content">
              <h3>Create New Group</h3>
              <p>Group code "<strong>{pendingJoinCode}</strong>" does not exist.</p>
              <p>Do you want to create a new group with this code?</p>
              <div className="input-group" style={{ marginTop: '1rem' }}>
                <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>Group Name:</label>
                <input 
                  type="text" 
                  className="join-group-input"
                  style={{ width: '100%', padding: '8px' }}
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  placeholder="Enter group name..."
                />
              </div>
              <div className="modal-actions">
                <button className="modal-btn cancel" onClick={() => { setShowCreateConfirm(false); setPendingJoinCode(''); }}>Cancel</button>
                <button className="modal-btn confirm" onClick={confirmCreateGroup}>Create</button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Active Chat View
  const activeSession = sessions.find(s => s.id === activeChatId);
  // Ensure currentMessages is always an array
  const rawMessages = messages[activeChatId!] as Message[] | undefined;
  // Deep copy or ensure it's a valid array to prevent reference issues
  const currentMessages = Array.isArray(rawMessages) ? rawMessages : [];

  if (!activeSession) {
    return (
      <div className="chat-panel" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column', gap: '1rem' }}>
        <div style={{ color: '#666' }}>Chat session not found</div>
        <button className="icon-btn back-btn" onClick={handleBack} style={{ width: 'auto', padding: '0 1rem', height: '36px', borderRadius: '18px' }}>
          <ChevronLeft size={20} />
          Back to List
        </button>
      </div>
    );
  }

  return (
    <div className="chat-panel">
      {/* Header with Group Info */}
      <div className="chat-header">
        <div className="header-left">
          <button className="icon-btn back-btn" onClick={handleBack}>
            <ChevronLeft size={20} />
          </button>
          <div 
            className={`header-info ${isHeaderExpanded ? 'expanded' : ''}`}
            onClick={() => setIsHeaderExpanded(!isHeaderExpanded)}
            title="Click to expand/collapse"
          >
            <div className="group-name">
              <Users size={16} className="group-icon" />
              <span title={activeSession?.name || 'Group'}>{activeSession?.name || 'Group'}</span>
              {activeSession?.isMuted && <BellOff size={14} className="muted-icon" />}
            </div>
            <div className="group-details">
              {activeSession?.membersCount || 0} members • {activeSession?.onlineCount || 0} online
            </div>
          </div>
        </div>
        <div className="header-actions">
          <div style={{ position: 'relative' }} ref={menuRef}>
            <button 
              className={`icon-btn ${isMenuOpen ? 'active' : ''}`} 
              title="Menu"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
               <MoreVertical size={16} />
            </button>
            
            {isMenuOpen && (
              <div className="dropdown-menu">
                <button className="dropdown-item" onClick={handleMuteToggle}>
                  <BellOff size={16} />
                  <span>{activeSession?.isMuted ? 'Unmute' : 'Mute'} Notifications</span>
                </button>
                <button className="dropdown-item" onClick={handleViewFiles}>
                  <FileText size={16} />
                  <span>Group Files</span>
                </button>
                <button className="dropdown-item danger" onClick={handleQuitGroup}>
                  <LogOut size={16} />
                  <span>Quit Group</span>
                </button>
              </div>
            )}
          </div>
          
          {!isMobile && (
            <button className="icon-btn minimize-btn" onClick={toggleChat} title="Minimize">
              <Minus size={18} />
            </button>
          )}
        </div>
      </div>

      {/* Message List */}
      <div className="message-list">
        {currentMessages.map((msg, index) => {
          const isOwnMessage = msg.senderName === user?.username;
          return (
            <div 
              key={msg.id || index} 
              className={`message-wrapper ${msg.role} ${isOwnMessage ? 'current-user' : ''}`}
              onContextMenu={(e) => handleContextMenu(e, msg)}
            >
              {msg.role !== 'system' && (
                <div className="avatar">
                  {msg.senderAvatar ? (
                    <img src={msg.senderAvatar} alt={msg.senderName || 'User'} />
                  ) : (
                    <div className="avatar-placeholder">{msg.senderName?.[0] || '?'}</div>
                  )}
                </div>
              )}
              <div className="message-content-group">
                {msg.role !== 'system' && (
                  <div className="sender-name">{msg.senderName || 'Unknown'}</div>
                )}
                <div className={`message-bubble ${msg.type === 'recalled' ? 'recalled' : ''}`}>
                  {msg.type === 'image' && msg.file ? (
                    <div className="image-attachment">
                      <img src={msg.file.url} alt="attachment" />
                    </div>
                  ) : msg.type === 'file' && msg.file ? (
                    <div className="file-attachment">
                      <div className="file-icon">
                        <FileText size={24} />
                      </div>
                      <div className="file-info">
                        <div className="file-name">{msg.file.name}</div>
                        <div className="file-size">{msg.file.size}</div>
                      </div>
                      <button className="download-btn" onClick={() => handleDownloadFile(msg.file!.url, msg.file!.name)}>
                        <Download size={16} />
                      </button>
                    </div>
                  ) : (
                    <p>{msg.content}</p>
                  )}
                  <span className="time">
                    {msg.timestamp}
                    {msg.type === 'recalled' && <span className="recall-label"> (Recalled)</span>}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="input-area" style={{ opacity: viewingGhostSessionId ? 0.6 : 1 }}>
        {isUploading && (
          <div className="upload-indicator">
            <span>Uploading...</span>
            <button onClick={cancelUpload} title="Cancel Upload">
              <X size={14} />
            </button>
          </div>
        )}
        <div style={{ position: 'relative' }} ref={attachmentMenuRef}>
          <button 
            className="icon-btn attachment-btn" 
            onClick={() => !viewingGhostSessionId && setIsAttachmentMenuOpen(!isAttachmentMenuOpen)}
            disabled={!!viewingGhostSessionId}
            style={{ cursor: viewingGhostSessionId ? 'not-allowed' : 'pointer' }}
          >
            <Paperclip size={20} />
          </button>
          {isAttachmentMenuOpen && (
            <div className="attachment-menu">
              <button onClick={handleFileUploadMock}>
                <ImageIcon size={16} /> Image
              </button>
              <button onClick={handleFileUploadMock}>
                <File size={16} /> File
              </button>
            </div>
          )}
        </div>
        <input 
          type="text" 
          placeholder={viewingGhostSessionId ? "Viewing in Ghost Mode (Read-only)" : `Message #${activeSession?.name}...`}
          value={inputText}
          onChange={(e) => !viewingGhostSessionId && setInputText(e.target.value)}
          onKeyDown={(e) => !viewingGhostSessionId && handleKeyDown(e)}
          disabled={!!viewingGhostSessionId}
          style={{ cursor: viewingGhostSessionId ? 'not-allowed' : 'text' }}
        />
        <button 
          className="send-btn" 
          onClick={handleSendMessage} 
          disabled={!!viewingGhostSessionId}
          style={{ cursor: viewingGhostSessionId ? 'not-allowed' : 'pointer' }}
        >
          <Send size={18} />
        </button>
      </div>

      {/* Ghost Mode Banner */}
      {viewingGhostSessionId && (
        <div style={{
          position: 'absolute',
          top: '60px',
          left: '0',
          right: '0',
          backgroundColor: 'rgba(255, 193, 7, 0.9)',
          color: '#000',
          padding: '4px 12px',
          fontSize: '0.8rem',
          fontWeight: '600',
          textAlign: 'center',
          zIndex: 10,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '6px'
        }}>
          <Shield size={12} />
          You are viewing this group in Ghost Mode. You cannot send messages.
        </div>
      )}

      {/* Confirmation Modal - Quit */}
      {showQuitConfirm && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h3>Quit Group?</h3>
            <p>Are you sure you want to leave this group?</p>
            {activeSession?.membersCount === 1 && (
              <p className="warning-text">You are the last member. The group will be disbanded and all history deleted.</p>
            )}
            <div className="modal-actions">
              <button className="modal-btn cancel" onClick={() => setShowQuitConfirm(false)}>Cancel</button>
              <button className="modal-btn confirm" onClick={confirmQuit}>Confirm</button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal - Create Group */}
      {showCreateConfirm && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h3>Create New Group</h3>
            <p>Group code <strong>"{pendingJoinCode}"</strong> not found.</p>
            <p>Would you like to create a new group with this name?</p>
            
            <div className="form-group" style={{ marginTop: '1rem', marginBottom: '1rem' }}>
              <label style={{ fontSize: '0.9rem', color: '#aaa', display: 'block', marginBottom: '4px' }}>Group Name</label>
              <input 
                type="text" 
                className="join-group-input"
                style={{ width: '100%', boxSizing: 'border-box' }}
                value={newGroupName}
                onChange={(e) => setNewGroupName(e.target.value)}
                placeholder="Enter group name"
                autoFocus
              />
            </div>

            <div className="modal-actions">
              <button className="modal-btn cancel" onClick={() => setShowCreateConfirm(false)}>Cancel</button>
              <button className="modal-btn confirm" onClick={confirmCreateGroup}>Create Group</button>
            </div>
          </div>
        </div>
      )}
      {/* Context Menu */}
      {contextMenu && (
        <div 
          className="context-menu" 
          style={{ top: contextMenu.y, left: contextMenu.x }}
          onClick={(e) => e.stopPropagation()}
        >
          {messages[activeChatId!]?.find(m => m.id === contextMenu.messageId)?.senderName === user?.username && 
           messages[activeChatId!]?.find(m => m.id === contextMenu.messageId)?.type !== 'recalled' && (
            <button onClick={() => handleRecallMessage(contextMenu.messageId)}>
              <RotateCcw size={16} /> Recall Message
            </button>
          )}
          {(user?.role === 'admin' || messages[activeChatId!]?.find(m => m.id === contextMenu.messageId)?.type === 'file') && (
            <button className="danger" onClick={() => handleDeleteMessage(contextMenu.messageId)}>
              <Trash2 size={16} /> Delete
            </button>
          )}
        </div>
      )}

      {/* Files Modal */}
      {showFilesModal && (
        <div className="modal-overlay">
          <div className="files-modal">
            <div className="modal-header">
              <h3>Group Files & Images</h3>
              <button className="close-btn" onClick={() => setShowFilesModal(false)}>
                <X size={20} />
              </button>
            </div>
            <div className="files-list">
              {currentMessages.filter(m => (m.type === 'file' || m.type === 'image') && m.file).length === 0 ? (
                <div className="empty-files">No files shared yet</div>
              ) : (
                currentMessages.filter(m => (m.type === 'file' || m.type === 'image') && m.file).map(msg => (
                  <div key={msg.id} className="file-item">
                    <div className="file-item-icon">
                      {msg.type === 'image' ? <ImageIcon size={24} /> : <FileText size={24} />}
                    </div>
                    <div className="file-item-info">
                      <div className="file-item-name">{msg.file!.name}</div>
                      <div className="file-item-meta">{msg.senderName} • {msg.timestamp} • {msg.file!.size}</div>
                    </div>
                    <div className="file-item-actions">
                      <button onClick={() => handleDownloadFile(msg.file!.url, msg.file!.name)} title="Download">
                        <Download size={16} />
                      </button>
                      {(user?.role === 'admin' || msg.isCurrentUser) && (
                        <button className="delete-btn" onClick={() => handleDeleteMessage(msg.id)} title="Delete">
                          <Trash2 size={16} />
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const ChatPanel: React.FC<ChatPanelProps> = ({ onOpenAdmin }) => {
  return (
    <ChatErrorBoundary>
      <ChatPanelContent onOpenAdmin={onOpenAdmin} />
    </ChatErrorBoundary>
  );
};

export default ChatPanel;
