import React, { forwardRef } from 'react';
import { GripHorizontal, ChevronDown, ChevronUp } from 'lucide-react';
import clsx from 'clsx';

interface GridItemWrapperProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
  // Props injected by react-grid-layout
  style?: React.CSSProperties;
  className?: string;
  onMouseDown?: React.MouseEventHandler;
  onMouseUp?: React.MouseEventHandler;
  onTouchEnd?: React.TouchEventHandler;
}

const GridItemWrapper = forwardRef<HTMLDivElement, GridItemWrapperProps>(
  ({ style, className, onMouseDown, onMouseUp, onTouchEnd, children, title, isCollapsed, onToggleCollapse, ...props }, ref) => {
    return (
      <div
        ref={ref}
        style={style}
        className={clsx('grid-item-wrapper', className)}
        onMouseDown={onMouseDown}
        onMouseUp={onMouseUp}
        onTouchEnd={onTouchEnd}
        {...props}
      >
        <div className="grid-item-header">
          <div className="drag-handle">
             <GripHorizontal size={16} />
          </div>
          <span className="grid-item-title">{title}</span>
          <div className="header-actions">
            <button 
              className="action-btn" 
              onClick={(e) => {
                e.stopPropagation(); // Prevent drag start
                onToggleCollapse?.();
              }}
              onMouseDown={(e) => e.stopPropagation()} // Important: Stop drag propagation
            >
              {isCollapsed ? <ChevronDown size={16} /> : <ChevronUp size={16} />}
            </button>
          </div>
        </div>
        <div className={clsx("grid-item-content", { collapsed: isCollapsed })}>
          {children}
        </div>
      </div>
    );
  }
);

export default GridItemWrapper;
