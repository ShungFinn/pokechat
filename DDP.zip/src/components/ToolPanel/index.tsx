import React, { useState, useCallback } from 'react';
import { Responsive, WidthProvider, Layout } from 'react-grid-layout';
import DexPanel from './modules/DexPanel/index';
import TeamPanel from './modules/TeamPanel/index';
import LLMPanel from './modules/LLMPanel/index';
import GridItemWrapper from './GridItemWrapper';
import './styles.css';

const ResponsiveGridLayout = WidthProvider(Responsive);

// Definition of extended layout item to support collapsing
interface CustomLayout extends Layout {
  isCollapsed?: boolean;
  originalH?: number; // Store original height to restore after expanding
}

const defaultLayouts: { lg: CustomLayout[]; md: CustomLayout[]; sm: CustomLayout[]; xs: CustomLayout[]; xxs: CustomLayout[] } = {
  lg: [
    { i: 'dex', x: 0, y: 0, w: 6, h: 21, minW: 3, minH: 4 },
    { i: 'team', x: 6, y: 0, w: 6, h: 21, minW: 3, minH: 4 },
    { i: 'llm', x: 0, y: 21, w: 12, h: 10, minW: 4, minH: 3 },
  ],
  md: [
    { i: 'dex', x: 0, y: 0, w: 6, h: 21, minW: 3, minH: 4 },
    { i: 'team', x: 6, y: 0, w: 6, h: 21, minW: 3, minH: 4 },
    { i: 'llm', x: 0, y: 21, w: 12, h: 10, minW: 4, minH: 3 },
  ],
  sm: [
    { i: 'dex', x: 0, y: 0, w: 12, h: 20, minW: 3, minH: 4 },
    { i: 'team', x: 0, y: 20, w: 12, h: 20, minW: 3, minH: 4 },
    { i: 'llm', x: 0, y: 40, w: 12, h: 12, minW: 4, minH: 3 },
  ],
  xs: [
    { i: 'dex', x: 0, y: 0, w: 4, h: 20, minW: 2, minH: 4 },
    { i: 'team', x: 0, y: 20, w: 4, h: 20, minW: 2, minH: 4 },
    { i: 'llm', x: 0, y: 40, w: 4, h: 12, minW: 2, minH: 3 },
  ],
  xxs: [
    { i: 'dex', x: 0, y: 0, w: 2, h: 20, minW: 2, minH: 4 },
    { i: 'team', x: 0, y: 20, w: 2, h: 20, minW: 2, minH: 4 },
    { i: 'llm', x: 0, y: 40, w: 2, h: 12, minW: 2, minH: 3 },
  ]
};

const ToolPanel: React.FC = () => {
  const [layouts, setLayouts] = useState<{ [key: string]: CustomLayout[] }>(defaultLayouts);
  
  // Track current breakpoint to know which layout to update
  const [currentBreakpoint, setCurrentBreakpoint] = useState<string>('lg');

  const handleLayoutChange = (currentLayout: Layout[], allLayouts: { [key: string]: Layout[] }) => {
    // We need to merge our custom properties (isCollapsed, originalH) back into the new layout
    // because RGL strips unknown properties.
    const activeLayout = allLayouts[currentBreakpoint] || currentLayout;
    
    const mergedLayout = activeLayout.map((item: Layout) => {
      const existing = layouts[currentBreakpoint as keyof typeof layouts]?.find(l => l.i === item.i);
      return {
        ...item,
        isCollapsed: existing?.isCollapsed,
        originalH: existing?.originalH
      } as CustomLayout;
    });

    setLayouts({
      ...allLayouts,
      [currentBreakpoint]: mergedLayout
    } as { [key: string]: CustomLayout[] });
  };

  const handleBreakpointChange = (newBreakpoint: string) => {
    setCurrentBreakpoint(newBreakpoint);
  };

  const toggleCollapse = useCallback((itemId: string) => {
    setLayouts(prevLayouts => {
      const currentLayout = prevLayouts[currentBreakpoint as keyof typeof prevLayouts] || [];
      const newLayout = currentLayout.map(item => {
        if (item.i === itemId) {
          const isCollapsed = !item.isCollapsed;
          let newH = item.h;
          let originalH = item.originalH;

          if (isCollapsed) {
            // Collapse: Save current height and set to min
            originalH = item.h;
            newH = 2; // Minimal height for header only (adjust based on rowHeight)
          } else {
            // Expand: Restore original height
            newH = originalH || (item.minH || 4);
          }

          return { ...item, h: newH, isCollapsed, originalH };
        }
        return item;
      });

      return {
        ...prevLayouts,
        [currentBreakpoint]: newLayout
      };
    });
  }, [currentBreakpoint]);

  return (
    <div className="tool-panel-container">
      <ResponsiveGridLayout
        className="layout"
        layouts={layouts}
        breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
        cols={{ lg: 12, md: 12, sm: 12, xs: 4, xxs: 2 }}
        rowHeight={30}
        draggableHandle=".grid-item-header"
        resizeHandles={['s', 'w', 'e', 'n', 'sw', 'se']}
        onLayoutChange={handleLayoutChange}
        onBreakpointChange={handleBreakpointChange}
        margin={[10, 10]}
      >
        <div key="dex">
          <GridItemWrapper 
            title="Pokédex" 
            isCollapsed={layouts[currentBreakpoint as keyof typeof layouts]?.find(l => l.i === 'dex')?.isCollapsed}
            onToggleCollapse={() => toggleCollapse('dex')}
          >
            <DexPanel />
          </GridItemWrapper>
        </div>
        <div key="team">
          <GridItemWrapper 
            title="Team Builder"
            isCollapsed={layouts[currentBreakpoint as keyof typeof layouts]?.find(l => l.i === 'team')?.isCollapsed}
            onToggleCollapse={() => toggleCollapse('team')}
          >
            <TeamPanel />
          </GridItemWrapper>
        </div>
        <div key="llm">
          <GridItemWrapper 
            title="Professor AI"
            isCollapsed={layouts[currentBreakpoint as keyof typeof layouts]?.find(l => l.i === 'llm')?.isCollapsed}
            onToggleCollapse={() => toggleCollapse('llm')}
          >
            <LLMPanel />
          </GridItemWrapper>
        </div>
      </ResponsiveGridLayout>
    </div>
  );
};

export default ToolPanel;
