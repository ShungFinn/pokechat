export interface Stats {
  hp: number;
  attack: number;
  defense: number;
  specialAttack: number;
  specialDefense: number;
  speed: number;
}

export interface TeamPokemon {
  id: string; // Unique ID within the team (UUID)
  pokemonId: number;
  name: string; // English name
  cnName: string; // Chinese name
  types: string[]; // types for analysis
  sprite: string;
  
  // Configuration
  nickname?: string;
  level: number; // Default 50
  gender?: 'male' | 'female' | 'genderless';
  isShiny: boolean;
  item?: {
    name: string;
    cnName?: string;
    url?: string;
  }; 
  ability?: {
    name: string;
    cnName?: string;
    url?: string;
  };
  nature?: {
    name: string;
    cnName?: string;
    modifiers?: {
      increased?: string;
      decreased?: string;
    };
  };
  
  ivs: Stats;
  evs: Stats;
  moves: {
    id: string; // Slot ID
    name: string;
    cnName?: string;
    type?: string;
    power?: number;
    accuracy?: number;
    pp?: number;
  }[];
  
  // Base Stats (for calculation)
  baseStats: Stats;
  stats?: Stats;
}

export interface Team {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  pokemons: TeamPokemon[];
  shareCode?: string;
}

export const NATURES = [
  { name: 'hardy', cnName: '勤奋', increased: null, decreased: null },
  { name: 'lonely', cnName: '怕寂寞', increased: 'attack', decreased: 'defense' },
  { name: 'brave', cnName: '勇敢', increased: 'attack', decreased: 'speed' },
  { name: 'adamant', cnName: '固执', increased: 'attack', decreased: 'specialAttack' },
  { name: 'naughty', cnName: '顽皮', increased: 'attack', decreased: 'specialDefense' },
  { name: 'bold', cnName: '大胆', increased: 'defense', decreased: 'attack' },
  { name: 'docile', cnName: '坦率', increased: null, decreased: null },
  { name: 'relaxed', cnName: '悠闲', increased: 'defense', decreased: 'speed' },
  { name: 'impish', cnName: '淘气', increased: 'defense', decreased: 'specialAttack' },
  { name: 'lax', cnName: '乐天', increased: 'defense', decreased: 'specialDefense' },
  { name: 'timid', cnName: '胆小', increased: 'speed', decreased: 'attack' },
  { name: 'hasty', cnName: '急躁', increased: 'speed', decreased: 'defense' },
  { name: 'serious', cnName: '认真', increased: null, decreased: null },
  { name: 'jolly', cnName: '爽朗', increased: 'speed', decreased: 'specialAttack' },
  { name: 'naive', cnName: '天真', increased: 'speed', decreased: 'specialDefense' },
  { name: 'modest', cnName: '内敛', increased: 'specialAttack', decreased: 'attack' },
  { name: 'mild', cnName: '慢吞吞', increased: 'specialAttack', decreased: 'defense' },
  { name: 'quiet', cnName: '冷静', increased: 'specialAttack', decreased: 'speed' },
  { name: 'bashful', cnName: '害羞', increased: null, decreased: null },
  { name: 'rash', cnName: '马虎', increased: 'specialAttack', decreased: 'specialDefense' },
  { name: 'calm', cnName: '温和', increased: 'specialDefense', decreased: 'attack' },
  { name: 'gentle', cnName: '温顺', increased: 'specialDefense', decreased: 'defense' },
  { name: 'sassy', cnName: '自大', increased: 'specialDefense', decreased: 'speed' },
  { name: 'careful', cnName: '慎重', increased: 'specialDefense', decreased: 'specialAttack' },
  { name: 'quirky', cnName: '浮躁', increased: null, decreased: null },
];
