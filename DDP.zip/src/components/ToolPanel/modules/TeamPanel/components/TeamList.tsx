import React, { useState } from 'react';
import { Plus, Trash2, Users, Download } from 'lucide-react';
import { Team } from '../types';

interface TeamListProps {
  teams: Team[];
  onCreate: () => void;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
  onImport: (shareCode: string) => void;
}

const TeamList: React.FC<TeamListProps> = ({ teams, onCreate, onSelect, onDelete, onImport }) => {
  const [importCode, setImportCode] = useState('');

  const handleImport = () => {
    if (importCode.trim().length > 0) {
      onImport(importCode.trim());
      setImportCode('');
    }
  };

  return (
    <div className="team-list-container">
      <div className="team-list-header">
        <h3>My Teams</h3>
        <div className="import-section" style={{ display: 'flex', gap: '8px' }}>
          <input 
            type="text" 
            placeholder="Share Code (10 chars)" 
            value={importCode}
            onChange={(e) => setImportCode(e.target.value)}
            style={{ 
              padding: '4px 8px', 
              borderRadius: '4px', 
              border: '1px solid #444',
              background: '#2d2d2d',
              color: '#fff',
              fontSize: '0.9rem'
            }}
          />
          <button 
            onClick={handleImport}
            style={{
              padding: '4px 12px',
              borderRadius: '4px',
              background: '#3a3a3a',
              color: '#fff',
              border: 'none',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '4px'
            }}
          >
            <Download size={14} />
            Import
          </button>
        </div>
      </div>
      
      <div className="team-grid">
        {teams.map(team => (
          <div key={team.id} className="team-card" onClick={() => onSelect(team.id)}>
            <div className="team-card-header">
              <span className="team-name">{team.name}</span>
              <button 
                className="delete-team-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  if(confirm('Are you sure you want to delete this team?')) {
                    onDelete(team.id);
                  }
                }}
              >
                <Trash2 size={14} />
              </button>
            </div>
            <div className="team-preview">
              {team.pokemons.length === 0 ? (
                <div className="empty-team-preview">
                  <Users size={24} />
                  <span>Empty Team</span>
                </div>
              ) : (
                <div className="pokemon-icons">
                  {team.pokemons.slice(0, 6).map((p, idx) => (
                    <img 
                      key={idx} 
                      src={p.sprite} 
                      alt={p.name} 
                      className="mini-sprite"
                      title={p.nickname || p.cnName || p.name}
                    />
                  ))}
                </div>
              )}
            </div>
            <div className="team-footer">
              <span>{team.pokemons.length} / 6</span>
            </div>
          </div>
        ))}

        <div className="team-card create-card" onClick={onCreate}>
          <div className="create-content">
            <div className="create-icon-wrapper">
              <Plus size={32} />
            </div>
            <span>New Team</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeamList;
