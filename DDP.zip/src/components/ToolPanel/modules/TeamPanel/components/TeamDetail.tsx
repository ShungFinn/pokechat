import React, { useState } from 'react';
import { ArrowLeft, Plus, Share2 } from 'lucide-react';
import { Team, TeamPokemon } from '../types';
import PokemonConfig from './PokemonConfig';
import TeamAnalysis from './TeamAnalysis';
import '../configStyles.css';
import '../analysisStyles.css';

interface TeamDetailProps {
  team: Team;
  onUpdate: (team: Team) => void;
  onBack: () => void;
}

const TeamDetail: React.FC<TeamDetailProps> = ({ team, onUpdate, onBack }) => {
  const [editingPokemonId, setEditingPokemonId] = useState<string | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [addingSlotIndex, setAddingSlotIndex] = useState<number | null>(null);

  const handleNameChange = (name: string) => {
    onUpdate({ ...team, name });
  };

  const handleUpdatePokemon = (pokemon: TeamPokemon) => {
    let newPokemons = [...team.pokemons];
    
    // Check if updating existing or adding new
    const existingIndex = newPokemons.findIndex(p => p.id === pokemon.id);
    
    if (existingIndex >= 0) {
      newPokemons[existingIndex] = pokemon;
    } else if (addingSlotIndex !== null) {
      newPokemons.push(pokemon);
    }
    
    onUpdate({ ...team, pokemons: newPokemons });
    setEditingPokemonId(null);
    setIsAdding(false);
    setAddingSlotIndex(null);
  };

  const handleRemovePokemon = (id: string) => {
    onUpdate({
      ...team,
      pokemons: team.pokemons.filter(p => p.id !== id)
    });
    setEditingPokemonId(null); // Close modal after delete
  };

  const handleShare = () => {
    if (team.shareCode) {
      navigator.clipboard.writeText(team.shareCode);
      alert(`队伍代码已复制：${team.shareCode}`);
    } else {
      alert('无法获取分享代码（可能未保存或网络问题）');
    }
  };

  const selectedPokemon = team.pokemons.find(p => p.id === editingPokemonId);

  return (
    <div className="team-detail-container">
      <div className="team-detail-header">
        <div className="header-left">
          <button className="back-btn" onClick={onBack}>
            <ArrowLeft size={20} />
          </button>
          <input 
            className="team-name-input"
            value={team.name}
            onChange={(e) => handleNameChange(e.target.value)}
          />
        </div>
        <button className="share-btn" onClick={handleShare} title="分享队伍">
          <Share2 size={20} />
          <span>分享</span>
        </button>
      </div>

      <div className="team-content-vertical">
        <div className="team-slots-section">
          <div className="team-slots-grid">
            {[0, 1, 2, 3, 4, 5].map(index => {
              const pokemon = team.pokemons[index];
              return (
                <div key={index} className="slot-wrapper">
                  {pokemon ? (
                    <div 
                      className="pokemon-slot filled"
                      onClick={() => setEditingPokemonId(pokemon.id)}
                    >
                      <div className="pokemon-card text-only">
                        <div className="pokemon-simple-info">
                          <span className="pokemon-name-large">{pokemon.nickname || pokemon.cnName || pokemon.name}</span>
                          <div className="pokemon-types-badges">
                            {pokemon.types.map((type, i) => (
                              <span key={i} className={`type-badge-large ${type.toLowerCase()}`}>
                                {type}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div 
                      className="pokemon-slot empty"
                      onClick={() => {
                        // Only allow adding if previous slots are filled? 
                        // Or just append.
                        // Let's just set adding mode.
                        setIsAdding(true);
                        setAddingSlotIndex(index);
                      }}
                    >
                      <div className="add-pokemon-btn">
                        <Plus size={32} />
                        <span>添加宝可梦</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>

      <div className="team-analysis-section-fixed">
        <TeamAnalysis team={team} />
      </div>

      {(editingPokemonId || isAdding) && (
        <PokemonConfig 
          initialData={selectedPokemon}
          onSave={handleUpdatePokemon}
          onCancel={() => {
            setEditingPokemonId(null);
            setIsAdding(false);
            setAddingSlotIndex(null);
          }}
          onDelete={editingPokemonId ? () => handleRemovePokemon(editingPokemonId) : undefined}
        />
      )}
    </div>
  );
};

export default TeamDetail;
