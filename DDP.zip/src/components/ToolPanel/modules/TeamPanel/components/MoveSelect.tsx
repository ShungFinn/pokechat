import React, { useState, useMemo } from 'react';
import { Search, X } from 'lucide-react';
import { commonMoves } from '../../../../../utils/commonData';
import { getChineseName } from '../../../../../utils/pokemonData';

interface MoveSelectProps {
  pokemonMoves: string[]; // List of move names/IDs available for this pokemon
  currentMove?: string;
  onSelect: (move: { name: string; cnName: string }) => void;
  onClose: () => void;
}

const MoveSelect: React.FC<MoveSelectProps> = ({ pokemonMoves, currentMove, onSelect, onClose }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const availableMoves = useMemo(() => {
    // Map moves to { id, cnName }
    const mapped = pokemonMoves.map(id => {
      const cnName = commonMoves[id] || getChineseName(id) || id; // Fallback to pokemonCnMap if it happens to match (unlikely for moves) or ID
      return { id, cnName };
    });

    if (!searchTerm) return mapped;

    const lower = searchTerm.toLowerCase();
    return mapped.filter(m => 
      m.id.includes(lower) || m.cnName.includes(lower)
    );
  }, [pokemonMoves, searchTerm]);

  return (
    <div className="move-select-modal">
      <div className="move-select-content">
        <div className="move-select-header">
          <h3>选择招式</h3>
          <button onClick={onClose}><X size={20} /></button>
        </div>
        
        <div className="move-search-bar">
          <Search size={16} />
          <input 
            type="text" 
            placeholder="搜索招式..." 
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            autoFocus
          />
        </div>

        <div className="move-list-grid">
          {availableMoves.map(move => (
            <button 
              key={move.id} 
              className={`move-option ${currentMove === move.id ? 'selected' : ''}`}
              onClick={() => onSelect({ name: move.id, cnName: move.cnName })}
            >
              <span className="move-cn">{move.cnName}</span>
              <span className="move-en">{move.id}</span>
            </button>
          ))}
          {availableMoves.length === 0 && (
            <div className="no-results">未找到相关招式</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MoveSelect;
