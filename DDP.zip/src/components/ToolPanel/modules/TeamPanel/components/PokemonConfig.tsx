import React, { useState, useEffect } from 'react';
import { X, Save, Trash2 } from 'lucide-react';
import { TeamPokemon, Stats, NATURES } from '../types';
import { calculateStats, INITIAL_STATS, MAX_IV, MAX_EV } from '../utils';
import { pokeApi } from '../../../../../services/pokeApi';
import { getChineseName } from '../../../../../utils/pokemonData';
import ItemSelect from './ItemSelect';
import MoveSelect from './MoveSelect';
import PokemonSelector from './PokemonSelector';
import '../hintStyles.css';

interface PokemonConfigProps {
  initialData?: TeamPokemon;
  onSave: (data: TeamPokemon) => void;
  onCancel: () => void;
  onDelete?: () => void; // Added onDelete callback
}

const STAT_LABELS: Record<keyof Stats, string> = {
  hp: 'Hp',
  attack: 'Atk',
  defense: 'Def',
  specialAttack: 'SpA',
  specialDefense: 'SpD',
  speed: 'Spd'
};

const TYPE_CN: Record<string, string> = {
  normal: '一般', fighting: '格斗', flying: '飞行', poison: '毒', ground: '地面', rock: '岩石',
  bug: '虫', ghost: '幽灵', steel: '钢', fire: '火', water: '水', grass: '草',
  electric: '电', psychic: '超能力', ice: '冰', dragon: '龙', dark: '恶', fairy: '妖精'
};

const PokemonConfig: React.FC<PokemonConfigProps> = ({ initialData, onSave, onCancel, onDelete }) => {
  const [data, setData] = useState<Partial<TeamPokemon>>(initialData || {
    level: 50,
    isShiny: false,
    ivs: { hp: 31, attack: 31, defense: 31, specialAttack: 31, specialDefense: 31, speed: 31 },
    evs: { hp: 0, attack: 0, defense: 0, specialAttack: 0, specialDefense: 0, speed: 0 },
    nature: { name: 'serious', cnName: '认真' },
    moves: [],
    gender: 'male'
  });

  const [searchMode, setSearchMode] = useState(!initialData);
  const [stats, setStats] = useState<Stats>(INITIAL_STATS);
  
  // New state for abilities and move selection
  const [availableAbilities, setAvailableAbilities] = useState<{ name: string; cnName: string; url: string }[]>([]);
  const [availableMoves, setAvailableMoves] = useState<string[]>([]);
  const [activeMoveSlot, setActiveMoveSlot] = useState<number | null>(null);

  // Load pokemon specific data (abilities, moves)
  useEffect(() => {
    if (data.pokemonId) {
      loadPokemonData(data.pokemonId);
    }
  }, [data.pokemonId]);

  const loadPokemonData = async (id: number) => {
    try {
      const details = await pokeApi.getPokemon(id);
      
      // Process Abilities
      const abilities = await Promise.all(details.abilities.map(async (a: any) => {
        try {
          const abilityData = await pokeApi.getAbility(a.ability.name);
          const cnName = abilityData.names.find((n: any) => n.language.name === 'zh-Hans')?.name || a.ability.name;
          return { name: a.ability.name, cnName, url: a.ability.url };
        } catch {
          return { name: a.ability.name, cnName: a.ability.name, url: a.ability.url };
        }
      }));
      setAvailableAbilities(abilities);

      // Process Moves (just names/urls for now)
      const moves = details.moves.map((m: any) => m.move.name);
      setAvailableMoves(moves);

    } catch (e) {
      console.error("Failed to load extra pokemon data", e);
    }
  };

  // Recalculate stats when dependencies change
  useEffect(() => {
    if (data.baseStats && data.ivs && data.evs && data.level && data.nature) {
      const calculated = calculateStats(
        data.baseStats,
        data.ivs,
        data.evs,
        data.level,
        data.nature.name
      );
      setStats(calculated);
    }
  }, [data.baseStats, data.ivs, data.evs, data.level, data.nature]);

  const handlePokemonSelect = async (pokemon: any) => {
    try {
      // Fetch full details
      const details = await pokeApi.getPokemon(pokemon.id);
      
      // Map stats
      const baseStats: Stats = {
        hp: details.stats.find((s: any) => s.stat.name === 'hp')?.base_stat || 0,
        attack: details.stats.find((s: any) => s.stat.name === 'attack')?.base_stat || 0,
        defense: details.stats.find((s: any) => s.stat.name === 'defense')?.base_stat || 0,
        specialAttack: details.stats.find((s: any) => s.stat.name === 'special-attack')?.base_stat || 0,
        specialDefense: details.stats.find((s: any) => s.stat.name === 'special-defense')?.base_stat || 0,
        speed: details.stats.find((s: any) => s.stat.name === 'speed')?.base_stat || 0,
      };

      // Get CN Name
      const cnName = getChineseName(details.name) || details.name;

      setData(prev => ({
        ...prev,
        id: prev.id || crypto.randomUUID(),
        pokemonId: details.id,
        name: details.name,
        cnName: cnName,
        sprite: details.sprites.front_default,
        types: details.types.map((t: any) => t.type.name),
        baseStats,
        // Reset moves/ability/item on new pokemon
        moves: [],
        ability: undefined,
        item: undefined
      }));
      setSearchMode(false);
    } catch (error) {
      console.error("Failed to load pokemon details", error);
    }
  };

  const handleStatChange = (type: 'ivs' | 'evs', stat: keyof Stats, value: number) => {
    const max = type === 'ivs' ? MAX_IV : MAX_EV;
    let clamped = Math.max(0, Math.min(max, value));
    
    if (type === 'evs') {
      const currentTotal = Object.entries(data.evs || {})
        .filter(([key]) => key !== stat)
        .reduce((sum, [_, val]) => sum + (val || 0), 0);
      
      if (currentTotal + clamped > 510) {
        clamped = Math.max(0, 510 - currentTotal);
      }
    }

    setData(prev => ({
      ...prev,
      [type]: {
        ...prev[type]!,
        [stat]: clamped
      }
    }));
  };

  const handleSave = () => {
    if (data.pokemonId && data.name) {
      onSave({
        ...data as TeamPokemon,
        stats // Save calculated stats
      });
    }
  };

  if (searchMode) {
    return (
      <div className="pokemon-config-modal">
        <div className="config-modal-card">
          <div className="config-header">
            <h3>选择宝可梦</h3>
            <button onClick={onCancel}><X size={20} /></button>
          </div>
          <div className="config-search-container">
            <PokemonSelector onSelect={handlePokemonSelect} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pokemon-config-modal">
      <div className="config-modal-card">
        <div className="config-header">
          <h3>配置 {getChineseName(data.name || '') || data.cnName || data.name}</h3>
          <div className="header-actions">
            {onDelete && (
              <button className="delete-btn" onClick={() => {
                if (window.confirm('确定要删除这只宝可梦吗？')) {
                  onDelete();
                }
              }} style={{ backgroundColor: '#d32f2f', color: 'white', marginRight: '8px' }}>
                <Trash2 size={16} /> 删除
              </button>
            )}
            <button className="save-btn" onClick={handleSave}>
              <Save size={16} /> 保存
            </button>
            <button className="cancel-btn" onClick={onCancel}>
              <X size={20} />
            </button>
          </div>
        </div>

        <div className="config-content">
        <div className="config-left-col">
          <div className="pokemon-preview-large">
            <img src={data.sprite} alt={data.name} />
            <div className="types-badges">
              {data.types?.map(t => <span key={t} className={`type-badge ${t}`}>{t}</span>)}
            </div>
          </div>
          
          <div className="basic-config">
            <div className="form-group">
              <label>等级</label>
              <input 
                type="number" 
                value={data.level} 
                onChange={e => setData({...data, level: parseInt(e.target.value) || 50})}
                min={1} max={100}
              />
            </div>
            
            <div className="form-group">
              <label>性格</label>
              <select 
                value={data.nature?.name} 
                onChange={e => {
                  const n = NATURES.find(nat => nat.name === e.target.value);
                  if (n) setData({...data, nature: n});
                }}
              >
                {NATURES.map(n => (
                  <option key={n.name} value={n.name}>
                    {n.cnName} ({n.name}) 
                    {n.increased ? ` +${n.increased} -${n.decreased}` : ''}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>携带道具</label>
              <ItemSelect 
                value={data.item} 
                onSelect={(item) => setData({ ...data, item })} 
              />
            </div>

            <div className="form-group">
              <label>特性</label>
              <select 
                value={data.ability?.name || ''} 
                onChange={e => {
                  const selected = availableAbilities.find(a => a.name === e.target.value);
                  if (selected) {
                    setData({...data, ability: { name: selected.name, cnName: selected.cnName }});
                  }
                }}
              >
                <option value="">选择特性...</option>
                {availableAbilities.map(a => (
                  <option key={a.name} value={a.name}>
                    {a.cnName} ({a.name})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="config-right-col">
          <div className="stats-config">
            <h4>能力值</h4>
            <div className="stats-grid-header">
              <span>能力</span>
              <span>种族值</span>
              <span>个体值</span>
              <span>努力值</span>
              <span>总计</span>
            </div>
            {(['hp', 'attack', 'defense', 'specialAttack', 'specialDefense', 'speed'] as const).map(stat => (
              <div key={stat} className="stat-row">
                <span className="stat-label">{STAT_LABELS[stat]}</span>
                <span className="base-stat">{data.baseStats?.[stat]}</span>
                <input 
                  type="number" 
                  className="stat-input"
                  value={data.ivs?.[stat]} 
                  onChange={e => handleStatChange('ivs', stat, parseInt(e.target.value))}
                />
                <input 
                  type="number" 
                  className="stat-input"
                  value={data.evs?.[stat]} 
                  onChange={e => handleStatChange('evs', stat, parseInt(e.target.value))}
                />
                <span className="total-stat">{stats[stat]}</span>
              </div>
            ))}
          </div>

          <div className="moves-config">
            <h4>招式</h4>
            <div className="moves-grid">
              {[0, 1, 2, 3].map(i => {
                const move = data.moves?.[i];
                return (
                  <div 
                    key={i} 
                    className={`move-slot-btn ${!move?.name ? 'empty' : ''}`}
                    onClick={() => setActiveMoveSlot(i)}
                  >
                    {move?.name ? (
                      <>
                        <div className="move-slot-header">
                          <span className="move-name-cn">{move.cnName || getChineseName(move.name) || move.name}</span>
                          {move.type && (
                            <span className={`type-badge-mini ${move.type}`}>
                              {TYPE_CN[move.type] || move.type}
                            </span>
                          )}
                        </div>
                      </>
                    ) : (
                      <span className="placeholder">招式 {i + 1}</span>
                    )}
                  </div>
                );
              })}
            </div>
            
            {activeMoveSlot !== null && (
              <MoveSelect
                pokemonMoves={availableMoves}
                currentMove={data.moves?.[activeMoveSlot]?.name}
                onSelect={async (move) => {
                  const newMoves = [...(data.moves || [])];
                  // Initialize empty slots if needed
                  for (let j = 0; j <= activeMoveSlot; j++) {
                    if (!newMoves[j]) newMoves[j] = { id: `move-${j}`, name: '' };
                  }
                  
                  // Optimistic update
                  newMoves[activeMoveSlot] = { 
                    ...newMoves[activeMoveSlot], 
                    name: move.name, 
                    cnName: move.cnName 
                  };
                  setData({ ...data, moves: newMoves });
                  setActiveMoveSlot(null);

                  // Fetch full move details for Type (needed for Coverage)
                  try {
                    const result = await pokeApi.getMove(move.name);
                    if (result) {
                      const updatedMoves = [...newMoves];
                      updatedMoves[activeMoveSlot] = {
                        ...updatedMoves[activeMoveSlot],
                        type: result.type.name,
                        power: result.power,
                        accuracy: result.accuracy,
                        pp: result.pp
                      };
                      setData(prev => ({ ...prev, moves: updatedMoves }));
                    }
                  } catch (e) {
                    console.error("Failed to fetch move details", e);
                  }
                }}
                onClose={() => setActiveMoveSlot(null)}
              />
            )}
          </div>
        </div>
        </div>
      </div>
    </div>
  );
};

export default PokemonConfig;
