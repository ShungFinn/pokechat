import React, { useState, useMemo } from 'react';
import { ChevronUp, X } from 'lucide-react';
import { Team } from '../types';
import { TYPES, calculateTypeMatchup } from '../utils';
import '../analysisStyles.css';

interface TeamAnalysisProps {
  team: Team;
}

const TeamAnalysis: React.FC<TeamAnalysisProps> = ({ team }) => {
  const [tab, setTab] = useState<'defense' | 'offense'>('defense');
  const [isExpanded, setIsExpanded] = useState(false);

  // Calculate Weaknesses (Defense)
  const defenseAnalysis = useMemo(() => TYPES.map(type => {
    let weakCount = 0;
    let resistCount = 0;
    let immuneCount = 0;

    team.pokemons.forEach(p => {
      const mult = calculateTypeMatchup(type, p.types);
      if (mult > 1) weakCount++;
      if (mult < 1 && mult > 0) resistCount++;
      if (mult === 0) immuneCount++;
    });

    return { type, weakCount, resistCount, immuneCount };
  }), [team.pokemons]);

  // Calculate Coverage (Offense)
  // Which types do we hit Super Effectively?
  const offenseAnalysis = useMemo(() => TYPES.map(defType => {
    let hitBy = 0; // How many moves hit this type SE
    
    team.pokemons.forEach(p => {
      p.moves.forEach(m => {
        if (m.type) {
          const mult = calculateTypeMatchup(m.type, [defType]);
          if (mult > 1) hitBy++;
        }
      });
    });

    return { type: defType, hitBy };
  }), [team.pokemons]);

  // Summary Logic
  const majorWeaknesses = defenseAnalysis
    .filter(d => d.weakCount >= 1)
    .sort((a, b) => b.weakCount - a.weakCount);

  const missingCoverage = offenseAnalysis
    .filter(o => o.hitBy === 0);

  return (
    <>
      {/* Trigger Bar (Always Visible) */}
      <div className="team-analysis-panel">
        <div 
          className="analysis-toggle-header"
          onClick={() => setIsExpanded(true)}
        >
          <div className="analysis-summary">
            <div className="summary-badges">
              <div className="summary-group">
                <span className="summary-label">Weaknesses:</span>
                {majorWeaknesses.length > 0 ? (
                  majorWeaknesses.map(w => (
                    <span key={w.type} className={`type-badge-mini ${w.type}`} title={`${w.weakCount} weak`}>
                      {w.type}
                    </span>
                  ))
                ) : (
                  <span className="summary-good">None</span>
                )}
              </div>
              <div className="summary-group">
                <span className="summary-label">No Coverage:</span>
                {missingCoverage.length > 0 ? (
                  missingCoverage.map(c => (
                    <span key={c.type} className={`type-badge-mini ${c.type}`}>
                      {c.type}
                    </span>
                  ))
                ) : (
                  <span className="summary-good">None</span>
                )}
              </div>
            </div>
          </div>
          <button className="toggle-btn">
            <ChevronUp size={20} />
          </button>
        </div>
      </div>

      {/* Full Screen Modal */}
      {isExpanded && (
        <div className="analysis-modal-overlay" onClick={() => setIsExpanded(false)}>
          <div className="analysis-modal-content" onClick={e => e.stopPropagation()}>
            <div className="analysis-modal-header">
              <span className="analysis-modal-title">Team Analysis</span>
              <button className="analysis-modal-close" onClick={() => setIsExpanded(false)}>
                <X size={24} />
              </button>
            </div>
            
            <div className="analysis-modal-body">
              <div className="analysis-tabs">
                <button 
                  className={`analysis-tab ${tab === 'defense' ? 'active' : ''}`}
                  onClick={() => setTab('defense')}
                >
                  Defensive Coverage
                </button>
                <button 
                  className={`analysis-tab ${tab === 'offense' ? 'active' : ''}`}
                  onClick={() => setTab('offense')}
                >
                  Offensive Coverage
                </button>
              </div>

              {tab === 'defense' ? (
                <div className="analysis-view-container">
                  <div className="analysis-header">
                    <span>Type</span>
                    <span>Weak</span>
                    <span>Resist</span>
                    <span>Immune</span>
                  </div>
                  <div className="analysis-list">
                    {defenseAnalysis.map(({ type, weakCount, resistCount, immuneCount }) => (
                      <div key={type} className="analysis-row">
                        <span className={`type-badge ${type}`}>{type}</span>
                        <span className={`count ${weakCount > 2 ? 'bad' : ''}`}>{weakCount || '-'}</span>
                        <span className="count">{resistCount || '-'}</span>
                        <span className="count">{immuneCount || '-'}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="analysis-view-container">
                  <div className="analysis-header" style={{ gridTemplateColumns: '100px 1fr' }}>
                    <span>Enemy Type</span>
                    <span>Hit By (Super Effective)</span>
                  </div>
                  <div className="analysis-list">
                    {offenseAnalysis.map(({ type, hitBy }) => (
                      <div key={type} className="analysis-row" style={{ gridTemplateColumns: '100px 1fr' }}>
                        <span className={`type-badge ${type}`}>{type}</span>
                        <span className={`count ${hitBy === 0 ? 'bad' : 'good'}`}>
                          {hitBy === 0 ? 'No coverage' : `${hitBy} moves`}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default TeamAnalysis;
