import React, { useState, useMemo, useRef, useEffect } from 'react';
import { commonItems } from '../../../../../utils/commonData';
import '../hintStyles.css';

interface ItemSelectProps {
  value?: { name: string; cnName?: string };
  onSelect: (item: { name: string; cnName: string }) => void;
}

const ItemSelect: React.FC<ItemSelectProps> = ({ value, onSelect }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredItems = useMemo(() => {
    if (!searchTerm) return Object.entries(commonItems).slice(0, 50); // Show popular ones initially

    const lowerSearch = searchTerm.toLowerCase();
    return Object.entries(commonItems).filter(([id, cnName]) => {
      return id.includes(lowerSearch) || cnName.includes(lowerSearch);
    });
  }, [searchTerm]);

  const handleSelect = (id: string, cnName: string) => {
    onSelect({ name: id, cnName });
    setIsOpen(false);
    setSearchTerm('');
  };

  return (
    <div className="item-select-wrapper" ref={wrapperRef}>
      <div className="input-with-hint" onClick={() => setIsOpen(true)}>
        <input
          type="text"
          placeholder="搜索道具..."
          value={isOpen ? searchTerm : (value?.cnName || value?.name || '')}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          readOnly={false} 
        />
        {/* If searching, don't show the hint overlay, show input value */}
      </div>

      {isOpen && (
        <div className="item-dropdown-list">
          {filteredItems.length > 0 ? (
            filteredItems.map(([id, cnName]) => (
              <div 
                key={id} 
                className={`item-option ${value?.name === id ? 'selected' : ''}`}
                onClick={() => handleSelect(id, cnName)}
              >
                <span className="item-cn">{cnName}</span>
                <span className="item-en">{id}</span>
              </div>
            ))
          ) : (
            <div className="no-results">未找到相关道具</div>
          )}
        </div>
      )}
    </div>
  );
};

export default ItemSelect;
