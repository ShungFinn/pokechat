import React, { useState, useEffect } from 'react';
import { Pokemon, pokeApi } from '../../../../../services/pokeApi';
import { getEnglishName, findPokemonByFuzzyCn } from '../../../../../utils/pokemonData';
import DexSearchBar from '../../DexPanel/components/DexSearchBar';
import DexList from '../../DexPanel/components/DexList';
import '../../DexPanel/styles.css';
import '../configStyles.css';

interface PokemonSelectorProps {
  onSelect: (pokemon: Pokemon) => void;
}

const REGIONS = [
  { name: '全国', id: 'national' },
  { name: '关都', id: 'kanto' },
  { name: '城都', id: 'original-johto' },
  { name: '丰缘', id: 'hoenn' },
  { name: '神奥', id: 'original-sinnoh' },
  { name: '合众', id: 'original-unova' },
  { name: '卡洛斯', id: 'kalos-central' },
  { name: '阿罗拉', id: 'original-alola' },
  { name: '伽勒尔', id: 'galar' },
  { name: '帕底亚', id: 'paldea' }
];

const TYPES = [
  { name: '一般', id: 'normal' },
  { name: '格斗', id: 'fighting' },
  { name: '飞行', id: 'flying' },
  { name: '毒', id: 'poison' },
  { name: '地面', id: 'ground' },
  { name: '岩石', id: 'rock' },
  { name: '虫', id: 'bug' },
  { name: '幽灵', id: 'ghost' },
  { name: '钢', id: 'steel' },
  { name: '火', id: 'fire' },
  { name: '水', id: 'water' },
  { name: '草', id: 'grass' },
  { name: '电', id: 'electric' },
  { name: '超能力', id: 'psychic' },
  { name: '冰', id: 'ice' },
  { name: '龙', id: 'dragon' },
  { name: '恶', id: 'dark' },
  { name: '妖精', id: 'fairy' }
];

const PokemonSelector: React.FC<PokemonSelectorProps> = ({ onSelect }) => {
  const [pokemonList, setPokemonList] = useState<Pokemon[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [activeRegion, setActiveRegion] = useState<string>('national');
  const [activeType, setActiveType] = useState<string>('');
  
  // Data State
  const [filteredEntries, setFilteredEntries] = useState<any[]>([]);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);

  // Search State
  const [searchQuery, setSearchQuery] = useState('');

  // Initial Load & Filter Change
  useEffect(() => {
    if (searchQuery) return; // Don't load filters if searching
    loadFilteredEntries();
  }, [activeRegion, activeType, searchQuery]);

  const loadFilteredEntries = async () => {
    setIsLoading(true);
    setError(null);
    setPokemonList([]);
    setOffset(0);
    setHasMore(true);

    try {
      // 1. Fetch Region Pokedex
      const dexData = await pokeApi.getPokedex(activeRegion);
      let entries = dexData.pokemon_entries;

      // 2. Filter by Type if selected
      if (activeType) {
        const typeData = await pokeApi.getType(activeType);
        // typeData.pokemon is array of { pokemon: { name, url }, slot }
        const typePokemonNames = new Set(typeData.pokemon.map((p: any) => p.pokemon.name));
        
        entries = entries.filter((entry: any) => {
          // entry.pokemon_species.name usually matches pokemon name, but not always (forms).
          // For simplicity, we check name.
          return typePokemonNames.has(entry.pokemon_species.name);
        });
      }

      setFilteredEntries(entries);
      
      // Load first batch
      await loadPokemonDetails(entries, 0);
    } catch (err) {
      console.error(err);
      setError('加载数据失败，请重试。');
      setIsLoading(false);
    }
  };

  const loadPokemonDetails = async (allEntries: any[], currentOffset: number) => {
    const limit = 20;
    const slice = allEntries.slice(currentOffset, currentOffset + limit);
    
    if (slice.length === 0) {
      setHasMore(false);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      const promises: Promise<Pokemon | null>[] = slice.map(async (entry: any) => {
        // Extract ID
        const urlParts = entry.pokemon_species.url.split('/');
        const nationalId = urlParts[urlParts.length - 2];
        
        try {
          const [p, species] = await Promise.all([
            pokeApi.getPokemon(nationalId),
            pokeApi.getPokemonSpecies(parseInt(nationalId))
          ]);
          
          const cnName = species.names.find((n: any) => n.language.name === 'zh-Hans')?.name;

          return {
            ...p,
            regionalId: entry.entry_number,
            cnName: cnName
          } as Pokemon;
        } catch (e) {
          console.warn(`Failed to load pokemon ${nationalId}`, e);
          return null;
        }
      });

      const results = await Promise.all(promises);
      const validResults: Pokemon[] = results.filter((r): r is Pokemon => r !== null);

      setPokemonList(prev => [...prev, ...validResults]);
      setOffset(currentOffset + limit);
      
      if (currentOffset + limit >= allEntries.length) {
        setHasMore(false);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    if (searchQuery) return; // No infinite scroll for search results yet
    if (isLoading || !hasMore) return;

    const { scrollTop, clientHeight, scrollHeight } = e.currentTarget;
    if (scrollHeight - scrollTop <= clientHeight + 100) {
      loadPokemonDetails(filteredEntries, offset);
    }
  };

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    if (!query) {
      // Reset to filters
      loadFilteredEntries();
      return;
    }

    setIsLoading(true);
    setError(null);
    setPokemonList([]);
    
    try {
      let searchTerms: string[] = [];
      
      const fuzzyMatches = findPokemonByFuzzyCn(query);
      if (fuzzyMatches.length > 0) {
        searchTerms = fuzzyMatches;
      } else {
        searchTerms = [getEnglishName(query)];
      }

      const limitedTerms = searchTerms.slice(0, 20);
      
      const resultsPromises = limitedTerms.map(term => 
        pokeApi.getPokemon(term).catch(() => null)
      );
      
      const results = await Promise.all(resultsPromises);
      const validResults = results.filter((r): r is Pokemon => r !== null);
      
      if (validResults.length === 0) {
        setError(`未找到 "${query}" 相关的宝可梦。`);
      } else {
        // Fetch species for CN names
        const enrichedResults = await Promise.all(validResults.map(async (p) => {
          try {
            const species = await pokeApi.getPokemonSpecies(p.id);
            const cnName = species.names.find((n: any) => n.language.name === 'zh-Hans')?.name;
            return { ...p, cnName };
          } catch {
            return p;
          }
        }));
        setPokemonList(enrichedResults);
      }
    } catch (err) {
      console.error(err);
      setError(`搜索 "${query}" 时发生错误。`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="pokemon-selector">
      <div className="selector-search-header">
        <DexSearchBar onSearch={handleSearch} isLoading={isLoading} />
        
        {!searchQuery && (
          <div className="filter-controls">
            <select 
              className="filter-select"
              value={activeRegion}
              onChange={(e) => setActiveRegion(e.target.value)}
              disabled={isLoading && pokemonList.length === 0}
            >
              {REGIONS.map(r => (
                <option key={r.id} value={r.id}>{r.name}</option>
              ))}
            </select>

            <select 
              className="filter-select"
              value={activeType}
              onChange={(e) => setActiveType(e.target.value)}
              disabled={isLoading && pokemonList.length === 0}
            >
              <option value="">所有属性</option>
              {TYPES.map(t => (
                <option key={t.id} value={t.id}>{t.name}</option>
              ))}
            </select>
          </div>
        )}
      </div>

      <div className="selector-results" onScroll={handleScroll}>
        <DexList 
          pokemonList={pokemonList} 
          isLoading={isLoading} 
          error={error} 
          onPokemonClick={onSelect} 
        />
        {isLoading && pokemonList.length > 0 && (
          <div className="loading-more">加载更多...</div>
        )}
      </div>
    </div>
  );
};

export default PokemonSelector;
