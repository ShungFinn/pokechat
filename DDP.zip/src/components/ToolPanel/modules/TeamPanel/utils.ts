import { Stats, TeamPokemon, NATURES } from './types';

export const calculateStats = (
  base: Stats, 
  ivs: Stats, 
  evs: Stats, 
  level: number, 
  natureName: string
): Stats => {
  const nature = NATURES.find(n => n.name === natureName);
  
  const calcHp = (base: number, iv: number, ev: number, level: number) => {
    if (base === 1) return 1; // Shedinja
    return Math.floor(((2 * base + iv + Math.floor(ev / 4)) * level) / 100) + level + 10;
  };

  const calcStat = (base: number, iv: number, ev: number, level: number, natureMod: number) => {
    return Math.floor((Math.floor(((2 * base + iv + Math.floor(ev / 4)) * level) / 100) + 5) * natureMod);
  };

  const getModifier = (statName: keyof Stats) => {
    if (!nature) return 1;
    if (nature.increased === statName) return 1.1;
    if (nature.decreased === statName) return 0.9;
    return 1;
  };

  return {
    hp: calcHp(base.hp, ivs.hp, evs.hp, level),
    attack: calcStat(base.attack, ivs.attack, evs.attack, level, getModifier('attack')),
    defense: calcStat(base.defense, ivs.defense, evs.defense, level, getModifier('defense')),
    specialAttack: calcStat(base.specialAttack, ivs.specialAttack, evs.specialAttack, level, getModifier('specialAttack')),
    specialDefense: calcStat(base.specialDefense, ivs.specialDefense, evs.specialDefense, level, getModifier('specialDefense')),
    speed: calcStat(base.speed, ivs.speed, evs.speed, level, getModifier('speed')),
  };
};

export const INITIAL_STATS: Stats = {
  hp: 0, attack: 0, defense: 0, specialAttack: 0, specialDefense: 0, speed: 0
};

export const MAX_IV = 31;
export const MAX_EV = 252;
export const MAX_TOTAL_EV = 510;

export const TYPES = [
  'normal', 'fire', 'water', 'grass', 'electric', 'ice', 'fighting', 'poison', 'ground', 
  'flying', 'psychic', 'bug', 'rock', 'ghost', 'dragon', 'steel', 'dark', 'fairy'
];

export const TYPE_CHART: Record<string, Record<string, number>> = {
  normal: { rock: 0.5, ghost: 0, steel: 0.5 },
  fire: { fire: 0.5, water: 0.5, grass: 2, ice: 2, bug: 2, rock: 0.5, dragon: 0.5, steel: 2 },
  water: { fire: 2, water: 0.5, grass: 0.5, ground: 2, rock: 2, dragon: 0.5 },
  grass: { fire: 0.5, water: 2, grass: 0.5, poison: 0.5, ground: 2, flying: 0.5, bug: 0.5, rock: 2, dragon: 0.5, steel: 0.5 },
  electric: { water: 2, grass: 0.5, electric: 0.5, ground: 0, flying: 2, dragon: 0.5 },
  ice: { fire: 0.5, water: 0.5, grass: 2, ice: 0.5, ground: 2, flying: 2, dragon: 2, steel: 0.5 },
  fighting: { normal: 2, ice: 2, poison: 0.5, flying: 0.5, psychic: 0.5, bug: 0.5, rock: 2, ghost: 0, dark: 2, steel: 2, fairy: 0.5 },
  poison: { grass: 2, poison: 0.5, ground: 0.5, rock: 0.5, ghost: 0.5, steel: 0, fairy: 2 },
  ground: { fire: 2, grass: 0.5, electric: 2, poison: 2, flying: 0, bug: 0.5, rock: 2, steel: 2 },
  flying: { grass: 2, electric: 0.5, fighting: 2, bug: 2, rock: 0.5, steel: 0.5 },
  psychic: { fighting: 2, poison: 2, psychic: 0.5, dark: 0, steel: 0.5 },
  bug: { fire: 0.5, grass: 2, fighting: 0.5, poison: 0.5, flying: 0.5, psychic: 2, ghost: 0.5, dark: 2, steel: 0.5, fairy: 0.5 },
  rock: { fire: 2, ice: 2, fighting: 0.5, ground: 0.5, flying: 2, bug: 2, steel: 0.5 },
  ghost: { normal: 0, psychic: 2, ghost: 2, dark: 0.5 },
  dragon: { dragon: 2, steel: 0.5, fairy: 0 },
  steel: { fire: 0.5, water: 0.5, electric: 0.5, ice: 2, rock: 2, steel: 0.5, fairy: 2 },
  dark: { fighting: 0.5, psychic: 2, ghost: 2, dark: 0.5, fairy: 0.5 },
  fairy: { fire: 0.5, fighting: 2, poison: 0.5, dragon: 2, dark: 2, steel: 0.5 }
};

export const calculateTypeMatchup = (attackType: string, defenseTypes: string[]) => {
  let multiplier = 1;
  defenseTypes.forEach(defType => {
    if (TYPE_CHART[attackType] && TYPE_CHART[attackType][defType] !== undefined) {
      multiplier *= TYPE_CHART[attackType][defType];
    }
  });
  return multiplier;
};

export const getTeamWeaknesses = (pokemons: TeamPokemon[]) => {
  const weaknesses: Record<string, number> = {};
  
  TYPES.forEach(type => {
    weaknesses[type] = 0;
    pokemons.forEach(p => {
      const multiplier = calculateTypeMatchup(type, p.types);
      if (multiplier > 1) weaknesses[type] += 1;
      if (multiplier > 2) weaknesses[type] += 1; // Double weakness counts more? Or just count pokemon?
      // Let's count how many pokemon are weak to this type
    });
  });
  
  return weaknesses;
};

export const getTeamResistances = (pokemons: TeamPokemon[]) => {
  const resistances: Record<string, number> = {};
  
  TYPES.forEach(type => {
    resistances[type] = 0;
    pokemons.forEach(p => {
      const multiplier = calculateTypeMatchup(type, p.types);
      if (multiplier < 1 && multiplier > 0) resistances[type] += 1;
      if (multiplier === 0) resistances[type] += 2; // Immunity counts more
    });
  });
  
  return resistances;
};

export const getTeamCoverage = (pokemons: TeamPokemon[]) => {
  const coverage: Record<string, number> = {};
  
  TYPES.forEach(type => {
    coverage[type] = 0;
    // Check if any pokemon has a move of this type (or coverage against this type)
    // For simplicity, let's check offensive coverage: "How many types do we hit super effectively?"
    // Actually, usually coverage means "Do we have moves that hit X type super effectively?"
  });

  const offensiveCoverage: Record<string, boolean> = {};
  TYPES.forEach(defType => {
    offensiveCoverage[defType] = false;
    pokemons.forEach(p => {
      p.moves.forEach(m => {
        // We need move type. Currently move object might not have type if not fetched.
        // Assuming we have move type.
        if (m.type) {
           const mult = calculateTypeMatchup(m.type, [defType]);
           if (mult > 1) offensiveCoverage[defType] = true;
        }
      });
    });
  });

  return offensiveCoverage;
};
