import React, { useState, useEffect } from 'react';
import TeamList from './components/TeamList';
import TeamDetail from './components/TeamDetail';
import { Team } from './types';
import { api } from '../../../../services/api';
import { useAuthStore } from '../../../../store/useAuthStore';
import './styles.css';

const TeamPanel: React.FC = () => {
  const [currentView, setCurrentView] = useState<'list' | 'detail'>('list');
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);
  const [teams, setTeams] = useState<Team[]>([]);
  const { user } = useAuthStore();
  const token = user?.token;

  useEffect(() => {
    loadTeams();
  }, [token]);

  const loadTeams = async () => {
    if (!token) return;
    try {
      const apiTeams = await api.getTeams(token);
      const mappedTeams: Team[] = apiTeams
        .filter(t => t.name !== 'Pokemon Center' && t.name !== 'Pokemon Centre')
        .map(t => ({
        id: t.id,
        name: t.name,
        createdAt: new Date(t.created_at).getTime(),
        updatedAt: new Date(t.created_at).getTime(),
        pokemons: t.pokemons || [],
        shareCode: t.share_code
      }));
      setTeams(mappedTeams);
    } catch (e: any) {
      console.error("Failed to load teams", e);
      if (e.message && e.message.includes('(401)')) {
          alert("登录已过期，请重新登录以查看您的队伍 (Session Expired, please login again)");
      }
    }
  };

  const handleCreateTeam = async () => {
    if (!token) return;
    try {
      const createdTeam = await api.createTeam(token, { name: 'New Team', pokemons: [] });
      const newTeam: Team = {
        id: createdTeam.id,
        name: createdTeam.name,
        createdAt: new Date(createdTeam.created_at).getTime(),
        updatedAt: new Date(createdTeam.created_at).getTime(),
        pokemons: createdTeam.pokemons || [],
        shareCode: createdTeam.share_code
      };
      setTeams([...teams, newTeam]);
      setSelectedTeamId(newTeam.id);
      setCurrentView('detail');
    } catch (e) {
      console.error("Failed to create team", e);
      alert('Failed to create team');
    }
  };

  const handleDeleteTeam = async (id: string) => {
    if (!token) return;
    if (!confirm('Are you sure you want to delete this team?')) return;
    try {
      await api.deleteTeam(token, id);
      setTeams(teams.filter(t => t.id !== id));
    } catch (e) {
      console.error("Failed to delete team", e);
      alert('Failed to delete team');
    }
  };

  const handleSelectTeam = (id: string) => {
    setSelectedTeamId(id);
    setCurrentView('detail');
  };

  const handleUpdateTeam = async (updatedTeam: Team) => {
    setTeams(teams.map(t => t.id === updatedTeam.id ? updatedTeam : t));
    if (!token) return;
    try {
      await api.updateTeam(token, updatedTeam.id, {
        name: updatedTeam.name,
        pokemons: updatedTeam.pokemons
      });
    } catch (e) {
      console.error("Failed to update team", e);
    }
  };

  const handleImportTeam = async (shareCode: string) => {
    if (!token) return;
    try {
      const importedTeam = await api.importTeam(token, shareCode);
      const newTeam: Team = {
        id: importedTeam.id,
        name: importedTeam.name,
        createdAt: new Date(importedTeam.created_at).getTime(),
        updatedAt: new Date(importedTeam.created_at).getTime(),
        pokemons: importedTeam.pokemons || [],
        shareCode: importedTeam.share_code
      };
      setTeams([...teams, newTeam]);
      alert('Team imported successfully!');
    } catch (e) {
      console.error("Failed to import team", e);
      alert('Failed to import team. Please check the share code.');
    }
  };

  return (
    <div className="team-panel">
      {currentView === 'list' ? (
        <TeamList 
          teams={teams} 
          onCreate={handleCreateTeam} 
          onSelect={handleSelectTeam}
          onDelete={handleDeleteTeam}
          onImport={handleImportTeam}
        />
      ) : (
        teams.find(t => t.id === selectedTeamId) ? (
          <TeamDetail 
            team={teams.find(t => t.id === selectedTeamId)!}
            onUpdate={handleUpdateTeam}
            onBack={() => setCurrentView('list')}
          />
        ) : (
          <div style={{ padding: 24, color: '#fff' }}>
            <p>Loading team or team not found...</p>
            <button 
              onClick={() => setCurrentView('list')}
              style={{
                marginTop: 12,
                padding: '8px 16px',
                background: '#3B82F6',
                color: 'white',
                border: 'none',
                borderRadius: 4,
                cursor: 'pointer'
              }}
            >
              Back to List
            </button>
          </div>
        )
      )}
    </div>
  );
};

export default TeamPanel;
