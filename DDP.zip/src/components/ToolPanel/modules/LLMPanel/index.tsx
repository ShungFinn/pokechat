import React from 'react';
import './styles.css';

const LLMPanel: React.FC = () => {
  return (
    <div className="llm-panel development-mode">
      <div className="development-content">
        <span className="development-icon">🚧</span>
        <p>宝可梦专家大预言模型开发中，没钱请不来大木博士qwq</p>
      </div>
    </div>
  );
};

export default LLMPanel;
