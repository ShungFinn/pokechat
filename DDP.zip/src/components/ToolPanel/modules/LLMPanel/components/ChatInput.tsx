import React from 'react';
import { Sparkles } from 'lucide-react';

const ChatInput: React.FC = () => {
  return (
    <div className="llm-input-area">
      <input 
        type="text" 
        placeholder="Ask AI..." 
        className="llm-input"
      />
      <button className="llm-send-btn">
        <Sparkles size={16} />
      </button>
    </div>
  );
};

export default ChatInput;
