import React from 'react';

const ChatHistory: React.FC = () => {
  return (
    <div className="llm-chat-history">
      <div className="llm-message">
        <span className="llm-role-label user">User:</span>
        <p className="llm-content">What's the best counter for Garchomp?</p>
      </div>
      <div className="llm-message">
        <span className="llm-role-label ai">AI:</span>
        <p className="llm-content">Ice-type moves are 4x effective against Garchomp. Consider Weavile or Mamoswine.</p>
      </div>
    </div>
  );
};

export default ChatHistory;
