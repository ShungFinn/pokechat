import React, { useState } from 'react';
import { Search } from 'lucide-react';

interface DexSearchBarProps {
  onSearch: (query: string) => void;
  isLoading: boolean;
}

const DexSearchBar: React.FC<DexSearchBarProps> = ({ onSearch, isLoading }) => {
  const [query, setQuery] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query.trim());
    }
  };

  return (
    <form className="dex-search-bar" onSubmit={handleSubmit}>
      <input 
        type="text" 
        placeholder="输入编号、名称或中文名..." 
        className="dex-search-input"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        disabled={isLoading}
      />
      <button type="submit" className="dex-search-btn" disabled={isLoading}>
        <Search size={16} />
      </button>
    </form>
  );
};

export default DexSearchBar;
