import React, { useEffect, useState } from 'react';
import { 
  Pokemon, 
  PokemonSpecies, 
  pokeApi, 
  EvolutionChainLink,
  MoveDetails,
  AbilityDetails
} from '../../../../../services/pokeApi';
import { 
  pokemonCnMap, 
  typeCnMap, 
  statCnMap, 
  eggGroupCnMap,
  moveLearnMethodCnMap,
  growthRateExpMap
} from '../../../../../utils/pokemonData';
import { moveCnMap, abilityCnMap } from '../../../../../utils/moveData';
import { ArrowLeft, ChevronRight } from 'lucide-react';
import '../styles.css';

interface DexDetailProps {
  pokemon: Pokemon;
  onBack: () => void;
  onPokemonSelect?: (pokemon: Pokemon) => void;
}

// Helper for Chinese name
const getCnName = (englishName: string): string => {
  if (!englishName) return '';
  // Try map first
  const entry = Object.entries(pokemonCnMap).find(([_, en]) => en.toLowerCase() === englishName.toLowerCase());
  if (entry) return entry[0];
  // Fallback to capitalizing first letter
  return englishName.charAt(0).toUpperCase() + englishName.slice(1);
};

// --- Sub-components ---

const AbilityItem: React.FC<{ url: string; isHidden: boolean }> = ({ url, isHidden }) => {
  const [details, setDetails] = useState<AbilityDetails | null>(null);

  useEffect(() => {
    pokeApi.getData<AbilityDetails>(url).then(setDetails).catch(console.error);
  }, [url]);

  if (!details) return <span>...</span>;

  const cnName = details.names.find(n => n.language.name === 'zh-Hans')?.name || abilityCnMap[details.name] || details.name;
  
  return (
    <div className="ability-item">
      <span>{cnName}</span>
      {isHidden && <span className="hidden-tag">*</span>}
    </div>
  );
};

const HeldItem: React.FC<{ url: string }> = ({ url }) => {
  const [name, setName] = useState<string>('');

  useEffect(() => {
    pokeApi.getData<{ names: { language: { name: string }, name: string }[], name: string }>(url)
      .then(data => {
        const cn = data.names.find(n => n.language.name === 'zh-Hans')?.name || data.name;
        setName(cn);
      })
      .catch(() => setName('?'));
  }, [url]);

  if (!name) return <span>...</span>;
  return <span>{name}</span>;
};

const MoveRow: React.FC<{ move: any }> = ({ move }) => {
  const [details, setDetails] = useState<MoveDetails | null>(null);

  useEffect(() => {
    pokeApi.getData<MoveDetails>(move.move.url).then(setDetails).catch(console.error);
  }, [move.move.url]);

  const detail = move.version_group_details?.[0];
  const learnMethod = detail?.move_learn_method?.name;
  const level = detail?.level_learned_at;

  const methodCn = moveLearnMethodCnMap[learnMethod] || learnMethod;
  const methodDisplay = learnMethod === 'level-up' ? `Lv.${level}` : methodCn;

  const name = details 
    ? (details.names.find(n => n.language.name === 'zh-Hans')?.name || moveCnMap[details.name] || details.name)
    : (moveCnMap[move.move.name] || move.move.name);
    
  const type = details?.type?.name ? (typeCnMap[details.type.name] || details.type.name) : '-';
  const power = details?.power || '-';

  return (
    <tr>
      <td>{methodDisplay}</td>
      <td>{name}</td>
      <td>
        <span className={`type-text type-${details?.type?.name || 'unknown'}`}>
          {type}
        </span>
      </td>
      <td>{power}</td>
    </tr>
  );
};

const EvolutionNode: React.FC<{ 
  link: EvolutionChainLink; 
  onSelect: (p: Pokemon) => void;
}> = ({ link, onSelect }) => {
  const [imgUrl, setImgUrl] = useState<string | null>(null);
  const [cnName, setCnName] = useState<string>('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!link?.species?.name) return;

    const fetchData = async () => {
      try {
        // Fetch species for name
        const species = await pokeApi.getPokemonSpecies(parseInt(link.species.url.split('/').slice(-2, -1)[0]));
        const name = species.names.find(n => n.language.name === 'zh-Hans')?.name || link.species.name;
        setCnName(name);

        // Fetch pokemon for sprite
        const p = await pokeApi.getPokemon(link.species.name);
        setImgUrl(p.sprites?.front_default);
      } catch (e) {
        setCnName(getCnName(link.species.name));
      }
    };
    fetchData();
  }, [link?.species?.name]);

  const handleClick = async () => {
    if (loading) return;
    setLoading(true);
    try {
      const p = await pokeApi.getPokemon(link.species.name);
      // We might want to enrich it with species data too, but DexPanel handles that usually. 
      // However, to be safe, we pass the basic pokemon and let the parent/DexPanel fetch extra if needed.
      // But wait, our onSelect (passed from DexPanel) just sets state. 
      // DexDetail will mount and fetch extra data itself.
      onSelect(p);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  if (!link || !link.species) return null;

  const children = link.evolves_to || [];

  return (
    <div className="evo-node">
      <div className="evo-info" onClick={handleClick} style={{ cursor: 'pointer' }}>
        {imgUrl && <img src={imgUrl} alt={link.species.name} className="evo-img" />}
        <span className="evo-name">{cnName || link.species.name}</span>
      </div>
      
      {children.length > 0 && (
        <div className="evo-children">
          {children.map((child, i) => (
            <div key={i} className="evo-branch">
              <ChevronRight size={16} className="evo-arrow" />
              <EvolutionNode link={child} onSelect={onSelect} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const DexDetail: React.FC<DexDetailProps> = ({ pokemon, onBack, onPokemonSelect }) => {
  const [species, setSpecies] = useState<PokemonSpecies | null>(null);
  const [evolutionChain, setEvolutionChain] = useState<EvolutionChainLink | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  // Pagination for moves
  const [displayedMovesCount, setDisplayedMovesCount] = useState(20);

  useEffect(() => {
    if (!pokemon?.id) return;

    const loadExtraData = async () => {
      setIsLoading(true);
      try {
        const speciesData = await pokeApi.getPokemonSpecies(pokemon.id);
        setSpecies(speciesData);

        if (speciesData.evolution_chain?.url) {
          const evoData = await pokeApi.getEvolutionChain(speciesData.evolution_chain.url);
          setEvolutionChain(evoData.chain);
        }
      } catch (e) {
        console.error('Failed to load detail data', e);
      } finally {
        setIsLoading(false);
      }
    };

    loadExtraData();
    setDisplayedMovesCount(20); // Reset moves pagination
  }, [pokemon?.id]);

  if (!pokemon) return null;

  // Safe data access
  const types = pokemon.types || [];
  const stats = pokemon.stats || [];
  const moves = pokemon.moves || [];
  const heldItems = pokemon.held_items || [];
  
  // Sort moves: Level up first, then others
  const sortedMoves = [...moves].sort((a, b) => {
    const aDetail = a.version_group_details?.[0];
    const bDetail = b.version_group_details?.[0];
    const aLevel = aDetail?.move_learn_method?.name === 'level-up' ? (aDetail.level_learned_at || 0) : 999;
    const bLevel = bDetail?.move_learn_method?.name === 'level-up' ? (bDetail.level_learned_at || 0) : 999;
    return aLevel - bLevel;
  });

  const displayedMoves = sortedMoves.slice(0, displayedMovesCount);

  // Formatting Helpers
  const getGenderRatio = (rate: number) => {
    if (rate === -1) return '无性别';
    const female = (rate / 8) * 100;
    const male = 100 - female;
    return `♂ ${male}% / ♀ ${female}%`;
  };

  const mainImage = pokemon.sprites?.other?.['official-artwork']?.front_default 
    || pokemon.sprites?.front_default 
    || '';

  return (
    <div className="dex-detail">
      <div className="dex-detail-header">
        <button className="dex-back-btn" onClick={onBack}>
          <ArrowLeft size={16} />
          返回
        </button>
        <div className="dex-detail-title">
          #{pokemon.id?.toString().padStart(4, '0')} {pokemon.cnName || getCnName(pokemon.name)}
        </div>
      </div>

      <div className="dex-detail-content">
        {/* Top Section: Split Layout */}
        <div className="detail-top-section">
          
          {/* Left Column: Image & Basic Props */}
          <div className="detail-left-col">
            <div className="detail-info-card">
              <div className="detail-image-container">
                {mainImage && (
                  <img 
                    src={mainImage} 
                    alt={pokemon.name} 
                    className="detail-main-img"
                  />
                )}
              </div>
              <div className="detail-types">
                {types.map(t => (
                  <span key={t.type.name} className={`type-badge type-${t.type.name}`}>
                    {typeCnMap[t.type.name] || t.type.name}
                  </span>
                ))}
              </div>
              <div className="detail-measurements-left">
                <div>身高: {(pokemon.height || 0) / 10} m</div>
                <div>体重: {(pokemon.weight || 0) / 10} kg</div>
              </div>
            </div>
          </div>

          {/* Right Column: Info Table */}
          <div className="detail-right-col">
            <div className="detail-info-card">
              <table className="info-table">
                <tbody>
                <tr>
                  <td className="info-label">特性</td>
                  <td className="info-value">
                    <div className="abilities-list">
                      {pokemon.abilities?.map((a, i) => (
                        <AbilityItem key={i} url={a.ability.url} isHidden={a.is_hidden} />
                      ))}
                    </div>
                  </td>
                </tr>
                <tr>
                  <td className="info-label">100级经验</td>
                  <td className="info-value">
                    {species?.growth_rate ? (
                      growthRateExpMap[species.growth_rate.name] || species.growth_rate.name
                    ) : '-'}
                  </td>
                </tr>
                <tr>
                  <td className="info-label">捕获率</td>
                  <td className="info-value">{species?.capture_rate ?? '-'}</td>
                </tr>
                <tr>
                  <td className="info-label">性别比例</td>
                  <td className="info-value">
                    {species ? getGenderRatio(species.gender_rate ?? -1) : '-'}
                  </td>
                </tr>
                <tr>
                  <td className="info-label">蛋组</td>
                  <td className="info-value">
                    {species?.egg_groups?.map(g => eggGroupCnMap[g.name] || g.name).join(', ') || '-'}
                  </td>
                </tr>
                <tr>
                  <td className="info-label">携带道具</td>
                  <td className="info-value">
                     {heldItems.length > 0 
                       ? (
                         <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                           {heldItems.map((h, i) => (
                              <React.Fragment key={i}>
                                <HeldItem url={h.item.url} />
                                {i < heldItems.length - 1 && <span>, </span>}
                              </React.Fragment>
                           ))}
                         </div>
                       )
                       : '无'}
                  </td>
                </tr>
                <tr>
                  <td className="info-label">取得基础点数</td>
                  <td className="info-value">
                    {stats
                      .filter(s => s.effort > 0)
                      .map(s => `${s.effort} ${statCnMap[s.stat.name] || s.stat.name}`)
                      .join(', ')}
                  </td>
                </tr>
              </tbody>
            </table>
            </div>
          </div>
        </div>

        {/* Evolution Chain */}
        <div className="detail-section">
          <h3>进化树</h3>
          {evolutionChain ? (
            <div className="evo-chain-container">
              <EvolutionNode 
                link={evolutionChain} 
                onSelect={onPokemonSelect || (() => {})} 
              />
            </div>
          ) : (
            <div className="text-muted">{isLoading ? '加载中...' : '无进化'}</div>
          )}
        </div>

        {/* Base Stats */}
        <div className="detail-section">
          <h3>种族值</h3>
          <div className="stat-bars">
            {stats.map(s => (
              <div key={s.stat.name} className="stat-row">
                <span className="stat-label">{statCnMap[s.stat.name] || s.stat.name}</span>
                <div className="stat-bar-container">
                  <div 
                    className="stat-bar-fill" 
                    style={{ width: `${Math.min(100, (s.base_stat / 255) * 100)}%` }}
                  ></div>
                </div>
                <span className="stat-value">{s.base_stat}</span>
              </div>
            ))}
            <div className="stat-row total">
              <span className="stat-label">总和</span>
              <span className="stat-value">
                {stats.reduce((acc, s) => acc + s.base_stat, 0)}
              </span>
            </div>
          </div>
        </div>

        {/* Moves */}
        <div className="detail-section">
          <h3>招式</h3>
          <div className="moves-table-container">
            <table className="moves-table">
              <thead>
                <tr>
                  <th>习得方式</th>
                  <th>名称</th>
                  <th>属性</th>
                  <th>威力</th>
                </tr>
              </thead>
              <tbody>
                {displayedMoves.map((move, i) => (
                  <MoveRow key={`${move.move.name}-${i}`} move={move} />
                ))}
              </tbody>
            </table>
            {displayedMovesCount < moves.length && (
              <button 
                className="load-more-btn"
                onClick={() => setDisplayedMovesCount(moves.length)}
              >
                显示全部招式 ({moves.length - displayedMovesCount})
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};

export default DexDetail;
