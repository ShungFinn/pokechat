import React from 'react';
import { Pokemon } from '../../../../../services/pokeApi';
import { pokemonCnMap } from '../../../../../utils/pokemonData';

interface DexListProps {
  pokemonList: Pokemon[];
  isLoading: boolean;
  error: string | null;
  onPokemonClick: (pokemon: Pokemon) => void;
}

// Helper to find Chinese name by English name (reverse lookup)
const getChineseName = (englishName: string): string => {
  const entry = Object.entries(pokemonCnMap).find(([_, en]) => en.toLowerCase() === englishName.toLowerCase());
  return entry ? entry[0] : englishName; // Return Chinese if found, else English
};

const TYPE_CN_MAP: Record<string, string> = {
  normal: '一般',
  fighting: '格斗',
  flying: '飞行',
  poison: '毒',
  ground: '地面',
  rock: '岩石',
  bug: '虫',
  ghost: '幽灵',
  steel: '钢',
  fire: '火',
  water: '水',
  grass: '草',
  electric: '电',
  psychic: '超能力',
  ice: '冰',
  dragon: '龙',
  dark: '恶',
  fairy: '妖精'
};

const DexList: React.FC<DexListProps> = ({ pokemonList, isLoading, error, onPokemonClick }) => {
  if (isLoading && pokemonList.length === 0) {
    return (
      <div className="dex-list">
        {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
          <div key={i} className="dex-item-placeholder"></div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="dex-list">
        <div className="dex-error">{error}</div>
      </div>
    );
  }

  return (
    <div className="dex-list">
      {pokemonList.map(pokemon => (
        <div 
          key={pokemon.id} 
          className="dex-item" 
          onClick={() => onPokemonClick(pokemon)}
        >
          <div className="dex-item-id">
            <span title="National Dex">#{pokemon.id.toString().padStart(4, '0')}</span>
            {pokemon.regionalId && pokemon.regionalId !== pokemon.id && (
              <span title="Regional Dex" className="dex-id-regional">
                #{pokemon.regionalId.toString().padStart(3, '0')}
              </span>
            )}
          </div>
          <img 
            src={pokemon.sprites.front_default || pokemon.sprites.other['official-artwork'].front_default} 
            alt={pokemon.name} 
            className="dex-item-avatar"
          />
          <div className="dex-item-info">
            <div className="dex-item-name">
              {pokemon.cnName || getChineseName(pokemon.name)}
            </div>
            <div className="dex-item-type">
              {pokemon.types.map(t => TYPE_CN_MAP[t.type.name] || t.type.name).join(' ')}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default DexList;
