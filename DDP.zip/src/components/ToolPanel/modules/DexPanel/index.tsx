import React, { useState, useEffect } from 'react';
import DexSearchBar from './components/DexSearchBar';
import DexList from './components/DexList';
import DexDetail from './components/DexDetail';
import { pokeApi, Pokemon } from '../../../../services/pokeApi';
import { getEnglishName, findPokemonByFuzzyCn } from '../../../../utils/pokemonData';
import { ArrowLeft, Map } from 'lucide-react';
import './styles.css';

// Simple Error Boundary
class DexDetailErrorBoundary extends React.Component<{ children: React.ReactNode, onBack: () => void }, { hasError: boolean, error: any }> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("DexDetail Error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="dex-detail-error" style={{ padding: 20, color: 'white' }}>
          <h3>Something went wrong displaying this Pokémon.</h3>
          <p>{this.state.error?.toString()}</p>
          <button 
            className="dex-back-btn" 
            onClick={this.props.onBack}
            style={{ marginTop: 20 }}
          >
            <ArrowLeft size={16} />
            返回列表
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

interface Region {
  name: string;
  id: string;
}

const REGIONS: Region[] = [
  { name: '全国', id: 'national' },
  { name: '关都', id: 'kanto' },
  { name: '城都', id: 'original-johto' },
  { name: '丰缘', id: 'hoenn' },
  { name: '神奥', id: 'original-sinnoh' },
  { name: '合众', id: 'original-unova' },
  { name: '卡洛斯', id: 'kalos-central' },
  { name: '阿罗拉', id: 'original-alola' },
  { name: '伽勒尔', id: 'galar' },
  { name: '帕底亚', id: 'paldea' } 
];

const DexPanel: React.FC = () => {
  const [pokemonList, setPokemonList] = useState<Pokemon[]>([]);
  const [selectedPokemon, setSelectedPokemon] = useState<Pokemon | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Pokedex Entry Management
  const [regionEntries, setRegionEntries] = useState<any[]>([]);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  
  const [isSearching, setIsSearching] = useState(false);
  const [activeRegionIndex, setActiveRegionIndex] = useState(0); // Default to National (0)
  const [showRegions, setShowRegions] = useState(false);

  // Pre-cache all regions on mount
  useEffect(() => {
    const preload = async () => {
      console.log('Preloading all pokedexes...');
      for (const region of REGIONS) {
        try {
          await pokeApi.getPokedex(region.id);
        } catch (e) {
          console.warn(`Failed to preload ${region.name}`, e);
        }
      }
    };
    preload();
  }, []);

  // Load Region Entries when region changes
  useEffect(() => {
    loadRegionEntries(REGIONS[activeRegionIndex].id);
  }, [activeRegionIndex]);

  const loadRegionEntries = async (regionId: string) => {
    setIsLoading(true);
    setError(null);
    setPokemonList([]);
    setOffset(0);
    setHasMore(true);

    try {
      const data = await pokeApi.getPokedex(regionId);
      setRegionEntries(data.pokemon_entries);
      
      // Load first batch immediately
      await loadPokemonDetails(data.pokemon_entries, 0);
    } catch (err) {
      console.error(err);
      setError('Failed to load Pokedex.');
      setIsLoading(false);
    }
  };

  const loadPokemonDetails = async (allEntries: any[], currentOffset: number) => {
    const limit = 20;
    const slice = allEntries.slice(currentOffset, currentOffset + limit);
    
    if (slice.length === 0) {
      setHasMore(false);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      const promises: Promise<Pokemon | null>[] = slice.map(async (entry: any) => {
        // Extract National ID from species URL
        // url format: .../pokemon-species/{id}/
        const urlParts = entry.pokemon_species.url.split('/');
        const nationalId = urlParts[urlParts.length - 2];
        
        try {
          // Fetch Pokemon and Species in parallel
          const [p, species] = await Promise.all([
            pokeApi.getPokemon(nationalId),
            pokeApi.getPokemonSpecies(parseInt(nationalId))
          ]);
          
          const cnName = species.names.find((n: any) => n.language.name === 'zh-Hans')?.name;

          return {
            ...p,
            regionalId: entry.entry_number,
            cnName: cnName
          } as Pokemon;
        } catch (e) {
          console.warn(`Failed to load pokemon ${nationalId}`, e);
          return null;
        }
      });

      const results = await Promise.all(promises);
      const validResults = results.filter((r): r is Pokemon => r !== null);

      setPokemonList(prev => {
         // Filter duplicates based on ID just in case
         const existingIds = new Set(prev.map(p => p.id));
         const uniqueNew = validResults.filter(p => !existingIds.has(p.id));
         return [...prev, ...uniqueNew];
      });

      setOffset(currentOffset + limit);
      if (currentOffset + limit >= allEntries.length) {
        setHasMore(false);
      }
    } catch (err) {
      console.error(err);
      // Don't set global error here to avoid blocking UI for partial failures
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegionChange = (index: number) => {
    if (index === activeRegionIndex) {
      setShowRegions(false);
      return;
    }
    setActiveRegionIndex(index);
    setShowRegions(false);
    setIsSearching(false);
  };

  const handleSearch = async (query: string) => {
    if (!query) {
      handleBackToDex();
      return;
    }

    setIsSearching(true);
    setIsLoading(true);
    setError(null);
    setPokemonList([]); 
    
    try {
      let searchTerms: string[] = [];
      
      const fuzzyMatches = findPokemonByFuzzyCn(query);
      if (fuzzyMatches.length > 0) {
        searchTerms = fuzzyMatches;
      } else {
        searchTerms = [getEnglishName(query)];
      }

      const limitedTerms = searchTerms.slice(0, 20); 
      
      const resultsPromises = limitedTerms.map(term => 
        pokeApi.getPokemon(term).catch(() => null)
      );
      
      const results = await Promise.all(resultsPromises);
      const validResults = results.filter((r): r is Pokemon => r !== null);
      
      if (validResults.length === 0) {
        setError(`No Pokémon found for "${query}".`);
      } else {
        setPokemonList(validResults);
      }
      
      setHasMore(false);
    } catch (err) {
      console.error(err);
      setError(`Error searching for "${query}".`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleBackToDex = () => {
    setIsSearching(false);
    // Reload current region state
    // We already have regionEntries, just need to reset list and offset
    setPokemonList([]);
    setOffset(0);
    setHasMore(true);
    loadPokemonDetails(regionEntries, 0);
  };

  const handleLoadMore = () => {
    if (!isLoading && hasMore && !isSearching) {
      loadPokemonDetails(regionEntries, offset);
    }
  };

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const { scrollTop, clientHeight, scrollHeight } = e.currentTarget;
    if (scrollHeight - scrollTop <= clientHeight + 50) {
      handleLoadMore();
    }
  };

  return (
    <div className="dex-panel">
      {selectedPokemon ? (
        <DexDetailErrorBoundary onBack={() => setSelectedPokemon(null)}>
          <DexDetail 
            pokemon={selectedPokemon} 
            onBack={() => setSelectedPokemon(null)} 
            onPokemonSelect={setSelectedPokemon}
          />
        </DexDetailErrorBoundary>
      ) : (
        <>
          <div className="dex-header-row">
            {isSearching ? (
              <button className="dex-back-btn" onClick={handleBackToDex}>
                <ArrowLeft size={16} />
                返回
              </button>
            ) : (
              <div className="dex-region-selector">
                <button 
                  className="dex-region-btn" 
                  onClick={() => setShowRegions(!showRegions)}
                >
                  <Map size={16} />
                  {REGIONS[activeRegionIndex].name}图鉴
                </button>
                {showRegions && (
                  <div className="dex-region-menu">
                    {REGIONS.map((r, i) => (
                      <div 
                        key={r.name} 
                        className={`dex-region-item ${i === activeRegionIndex ? 'active' : ''}`}
                        onClick={() => handleRegionChange(i)}
                      >
                        {r.name}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
            <DexSearchBar onSearch={handleSearch} isLoading={isLoading} />
          </div>

          <div className="dex-scroll-container" onScroll={handleScroll}>
            <DexList 
              pokemonList={pokemonList} 
              isLoading={isLoading} 
              error={error} 
              onPokemonClick={setSelectedPokemon}
            />
            {isLoading && pokemonList.length > 0 && (
              <div className="dex-loading-more">加载中...</div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default DexPanel;
