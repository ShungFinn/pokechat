import React, { useState, useEffect } from 'react';
import { useAuthStore } from '../../store/useAuthStore';
import { useChatStore } from '../../store/useChatStore';
import { api, ApiUser } from '../../services/api';
import { UserPlus, Trash2, Users, ArrowLeft, MessageSquare, Eye, Search } from 'lucide-react';
import './styles.css';

interface AdminPanelProps {
  onBack: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ onBack }) => {
  const { user: currentUser } = useAuthStore();
  const { sessions, removeSession, setViewingGhostSessionId } = useChatStore();
  
  const [activeTab, setActiveTab] = useState<'users' | 'groups'>('groups');
  const [newUsername, setNewUsername] = useState('');
  const [newRole, setNewRole] = useState<'admin' | 'user'>('user');
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [users, setUsers] = useState<ApiUser[]>([]);

  const filteredUsers = Array.isArray(users) ? users.filter(u => 
    u && u.username && u.username.toLowerCase().includes((searchTerm || '').toLowerCase())
  ) : [];

  useEffect(() => {
    // Force fetch on mount if users tab is active
    if (activeTab === 'users' && currentUser?.token) {
      console.log('Fetching users...');
      api.getUsers(currentUser.token)
         .then((data) => {
             console.log('Users fetched:', data);
             if (Array.isArray(data)) {
                 setUsers(data);
             } else {
                 console.error("Invalid users data:", data);
                 setUsers([]);
             }
         })
         .catch((err) => {
             console.error("Fetch users error:", err);
             setError('Failed to fetch users: ' + err.message);
         });
    }
  }, [activeTab, currentUser?.token]);

  const addUser = async (u: any) => {
    if (!currentUser?.token) return;
    try {
      await api.createUser(currentUser.token, u);
      // Refresh list
      const updatedUsers = await api.getUsers(currentUser.token);
      setUsers(updatedUsers);
    } catch (err: any) {
      setError(err.message || 'Failed to create user');
      throw err;
    }
  };

  const removeUser = async (username: string) => { // UI passes username, but we need ID
    if (!currentUser?.token) return;
    const user = users.find(u => u.username === username);
    if (!user || !user.id) return;
    
    try {
      await api.deleteUser(currentUser.token, user.id);
      setUsers(users.filter(u => u.username !== username));
    } catch (err: any) {
      setError(err.message || 'Failed to delete user');
    }
  };

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!newUsername.trim()) {
      setError('Username is required');
      return;
    }

    if (users.some(u => u.username.toLowerCase() === newUsername.toLowerCase())) {
      setError('Username already exists');
      return;
    }

    const newUser = {
      username: newUsername,
      role: newRole,
      password: '123456', // Default temporary password
      isFirstLogin: true
    };

    try {
        await addUser(newUser);
        setNewUsername('');
        setNewRole('user');
    } catch (e) {
        // error handled in addUser
    }
  };

  const handleRemoveUser = (username: string) => {
    if (window.confirm(`Are you sure you want to remove user "${username}"?`)) {
      removeUser(username);
    }
  };

  const handleViewGroup = (groupId: string) => {
    setViewingGhostSessionId(groupId);
    onBack(); // Go back to chat panel
  };

  const handleDisbandGroup = async (groupId: string) => {
    if (window.confirm("Are you sure you want to disband this group? This action cannot be undone.")) {
      if (currentUser?.token) {
        try {
          await api.deleteTeam(currentUser.token, groupId);
          removeSession(groupId);
        } catch (e) {
          console.error(e);
          alert('Failed to delete group');
        }
      }
    }
  };

  return (
    <div className="admin-panel">
      <div className="admin-header">
        <div className="admin-header-left">
          <button className="back-btn" onClick={onBack}>
            <ArrowLeft size={20} />
            Back to Chat
          </button>
          <h1 className="admin-title">Admin Dashboard</h1>
        </div>
        <div className="admin-user-info">
          Logged in as: <strong>{currentUser?.username}</strong>
        </div>
      </div>

      <div className="admin-tabs">
        <button 
          className={`tab-btn ${activeTab === 'users' ? 'active' : ''}`}
          onClick={() => setActiveTab('users')}
        >
          <Users size={18} style={{ display: 'inline', marginRight: '8px', verticalAlign: 'text-bottom' }} />
          User Management
        </button>
        <button 
          className={`tab-btn ${activeTab === 'groups' ? 'active' : ''}`}
          onClick={() => setActiveTab('groups')}
        >
          <MessageSquare size={18} style={{ display: 'inline', marginRight: '8px', verticalAlign: 'text-bottom' }} />
          Group Management
        </button>
      </div>

      {activeTab === 'users' ? (
        <>
          <div className="admin-section">
            <div className="section-title">
              <UserPlus size={20} />
              Add New User
            </div>
            <form className="add-user-form" onSubmit={handleAddUser}>
              <div className="form-group">
                <label>Username</label>
                <input 
                  type="text" 
                  className="form-input" 
                  placeholder="Enter username"
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value)}
                />
              </div>
              <div className="form-group">
                <label>Role</label>
                <select 
                  className="form-select"
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value as 'admin' | 'user')}
                >
                  <option value="user">User</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              <button type="submit" className="btn btn-primary">
                <UserPlus size={16} />
                Create User
              </button>
            </form>
            {error && <div style={{ color: '#ff6b6b', marginTop: '10px', fontSize: '0.9rem' }}>{error}</div>}
            <div style={{ marginTop: '10px', fontSize: '0.85rem', color: '#888' }}>
              * Default password for new users is <strong>123456</strong>. They will be prompted to change it on first login.
            </div>
          </div>

          <div className="admin-section">
            <div className="section-header">
              <div className="section-title">
                <Users size={20} />
                User List
              </div>
              <div className="search-box">
                <Search size={16} className="search-icon" />
                <input 
                  type="text" 
                  className="search-input" 
                  placeholder="Search users..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            
            {filteredUsers.length === 0 ? (
              <div className="empty-state">
                {searchTerm ? 'No users found matching your search.' : 'No users found.'}
                <div style={{ marginTop: '10px', fontSize: '0.8rem', color: '#ccc' }}>
                   Debug: Users loaded: {users?.length || 0}. 
                   Raw: {JSON.stringify(users).slice(0, 50)}...
                </div>
              </div>
            ) : (
              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Username</th>
                      <th>Role</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredUsers.map((u, index) => {
                      if (!u || !u.username) return null;
                      return (
                      <tr key={u.username || index}>
                        <td>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <div className="user-avatar-small" style={{ width: '24px', height: '24px' }}>
                               <img src={`https://ui-avatars.com/api/?name=${u.username}&background=random&color=fff`} alt={u.username} />
                            </div>
                            {u.username}
                            {currentUser?.username === u.username && <span style={{ fontSize: '0.7rem', color: '#aaa' }}>(You)</span>}
                          </div>
                        </td>
                        <td>
                          <span className={`role-badge ${u.role}`}>
                            {u.role}
                          </span>
                        </td>
                        <td>
                          {u.isFirstLogin ? (
                            <span className="status-badge pending">Pending Setup</span>
                          ) : (
                            <span className="status-badge">Active</span>
                          )}
                        </td>
                        <td>
                          {currentUser?.username !== u.username && (
                            <button 
                              className="btn btn-danger"
                              onClick={() => handleRemoveUser(u.username)}
                              title="Remove User"
                            >
                              <Trash2 size={14} />
                            </button>
                          )}
                        </td>
                      </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="admin-section">
          <div className="section-title">
            <MessageSquare size={20} />
            Group List
          </div>
          
          {sessions.length === 0 ? (
            <div className="empty-state">No groups found.</div>
          ) : (
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Group Name</th>
                    <th>ID</th>
                    <th>Members</th>
                    <th>Creator</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {sessions.map(session => (
                    <tr key={session.id}>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                           {session.avatar && <img src={session.avatar} alt={session.name} style={{ width: '24px', height: '24px', borderRadius: '50%' }} />}
                           {session.name}
                        </div>
                      </td>
                      <td style={{ fontFamily: 'monospace', fontSize: '0.85rem', color: '#888' }}>{session.id}</td>
                      <td>{session.membersCount}</td>
                      <td>{session.creatorId || 'System'}</td>
                      <td>
                        <div style={{ display: 'flex', gap: '8px' }}>
                          <button 
                            className="btn btn-info" 
                            onClick={() => handleViewGroup(session.id)}
                            title="Ghost View"
                          >
                            <Eye size={14} /> View
                          </button>
                          <button 
                            className="btn btn-danger" 
                            onClick={() => handleDisbandGroup(session.id)}
                            title="Disband Group"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AdminPanel;
