import { API_BASE_URL, ENDPOINTS } from '../config';

export interface ApiUser {
  username: string;
  role: 'admin' | 'user';
  id?: number;
  is_active?: boolean;
  isFirstLogin?: boolean; // Frontend specific or future backend support
}

export interface ApiTeam {
  id: string;
  name: string;
  description?: string;
  members_count: number;
  online_count?: number;
  created_at: string;
  share_code?: string;
  pokemons?: any[];
  is_muted?: boolean;
}

export const api = {
  login: async (username: string, password: string) => {
    const formData = new URLSearchParams();
    formData.append('username', username);
    formData.append('password', password);

    const response = await fetch(`${API_BASE_URL}/token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ detail: 'Login failed' }));
      throw new Error(errorData.detail || 'Login failed');
    }
    return response.json();
  },

  register: async (username: string, password: string) => {
    const response = await fetch(`${API_BASE_URL}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password, role: 'user' }),
    });
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ detail: 'Registration failed' }));
      throw new Error(errorData.detail || 'Registration failed');
    }
    return response.json();
  },

  getMe: async (token: string): Promise<ApiUser> => {
    const response = await fetch(`${API_BASE_URL}/users/me`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('Failed to fetch user details');
    return response.json();
  },

  getTeams: async (token: string): Promise<ApiTeam[]> => {
    const response = await fetch(`${API_BASE_URL}/teams/`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error(`Failed to fetch teams (${response.status})`);
    return response.json();
  },

  getAllTeams: async (token: string): Promise<ApiTeam[]> => {
    const response = await fetch(ENDPOINTS.TEAMS_ALL, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('Failed to fetch all teams');
    return response.json();
  },

  getUsers: async (token: string): Promise<ApiUser[]> => {
    const response = await fetch(ENDPOINTS.USERS, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('Failed to fetch users');
    return response.json();
  },

  deleteUser: async (token: string, userId: number) => {
    const response = await fetch(`${ENDPOINTS.USERS}${userId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('Failed to delete user');
    return response.json();
  },

  createUser: async (token: string, user: any) => {
    const response = await fetch(`${API_BASE_URL}/register`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}` 
      },
      body: JSON.stringify(user),
    });
    if (!response.ok) {
        const errorData = await response.json().catch(() => ({ detail: 'Creation failed' }));
        throw new Error(errorData.detail || 'Creation failed');
    }
    return response.json();
  },

  createTeam: async (token: string, team: { name: string; pokemons: any[] }) => {
    const response = await fetch(`${API_BASE_URL}/teams/`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}` 
      },
      body: JSON.stringify(team),
    });
    if (!response.ok) throw new Error('Failed to create team');
    return response.json();
  },

  updateTeam: async (token: string, teamId: string, team: { name: string; pokemons: any[] }) => {
    const response = await fetch(`${API_BASE_URL}/teams/${teamId}`, {
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}` 
      },
      body: JSON.stringify(team),
    });
    if (!response.ok) throw new Error('Failed to update team');
    return response.json();
  },

  importTeam: async (token: string, shareCode: string) => {
    const response = await fetch(`${API_BASE_URL}/teams/import/${shareCode}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('Failed to import team');
    return response.json();
  },

  deleteTeam: async (token: string, teamId: string) => {
    const response = await fetch(`${API_BASE_URL}/teams/${teamId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('Failed to delete team');
    return response.json();
  },

  changePassword: async (token: string, oldPassword: string, newPassword: string) => {
    const response = await fetch(`${API_BASE_URL}/change_password`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}` 
      },
      body: JSON.stringify({ old_password: oldPassword, new_password: newPassword }),
    });
    if (!response.ok) {
        const errorData = await response.json().catch(() => ({ detail: 'Failed to change password' }));
        throw new Error(errorData.detail || 'Failed to change password');
    }
    return response.json();
  },

  forcePasswordChange: async (token: string, userId: number, mustChange: boolean) => {
    const response = await fetch(`${API_BASE_URL}/users/${userId}/force_password_change?must_change=${mustChange}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('Failed to update password status');
    return response.json();
  },

  toggleMute: async (token: string, teamId: string, isMuted: boolean) => {
    const response = await fetch(`${API_BASE_URL}/teams/${teamId}/mute?is_muted=${isMuted}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('Failed to toggle mute');
    return response.json();
  },
};
