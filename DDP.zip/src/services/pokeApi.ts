
// Type definitions for PokeAPI responses
export interface PokemonType {
  slot: number;
  type: {
    name: string;
    url: string;
  };
}

export interface PokemonStat {
  base_stat: number;
  effort: number;
  stat: {
    name: string;
    url: string;
  };
}

export interface PokemonSprite {
  front_default: string;
  front_shiny: string;
  other: {
    'official-artwork': {
      front_default: string;
    };
  };
}

export interface PokemonItem {
  item: {
    name: string;
    url: string;
  };
  version_details: {
    rarity: number;
    version: {
      name: string;
      url: string;
    };
  }[];
}

export interface PokemonMove {
  move: {
    name: string;
    url: string;
  };
  version_group_details: {
    level_learned_at: number;
    move_learn_method: {
      name: string;
      url: string;
    };
    version_group: {
      name: string;
      url: string;
    };
  }[];
}

export interface PokemonAbility {
  is_hidden: boolean;
  slot: number;
  ability: {
    name: string;
    url: string;
  };
}

export interface Pokemon {
  id: number;
  name: string;
  types: PokemonType[];
  stats: PokemonStat[];
  sprites: PokemonSprite;
  height: number;
  weight: number;
  held_items: PokemonItem[];
  moves: PokemonMove[];
  abilities: PokemonAbility[];
  location_area_encounters: string;
  // Optional: injected for UI
  regionalId?: number;
  cnName?: string;
}

export interface EvolutionChainLink {
  species: {
    name: string;
    url: string;
  };
  evolves_to: EvolutionChainLink[];
  evolution_details: any[]; // Simplified for now
}

export interface EvolutionChain {
  chain: EvolutionChainLink;
  id: number;
}

export interface PokemonSpecies {
  id: number;
  names: {
    language: {
      name: string;
      url: string;
    };
    name: string;
  }[];
  capture_rate?: number;
  gender_rate?: number;
  egg_groups?: {
    name: string;
    url: string;
  }[];
  growth_rate?: {
    name: string;
    url: string;
  };
  flavor_text_entries: {
    flavor_text: string;
    language: {
      name: string;
      url: string;
    };
  }[];
  evolution_chain?: {
    url: string;
  };
}

export interface AbilityDetails {
  name: string;
  names: {
    language: { name: string; url: string };
    name: string;
  }[];
}

export interface MoveDetails {
  name: string;
  names: {
    language: { name: string; url: string };
    name: string;
  }[];
  type?: { name: string; url: string };
  power?: number | null;
}

import { getItem, setItem } from './db';

const BASE_URL = 'https://pokeapi.co/api/v2';

// Helper to replace blocked image domains with mirrors
const fixUrl = (obj: any): any => {
  if (typeof obj === 'string') {
    // Replace raw.githubusercontent.com with raw.gitmirror.com for better access in some regions
    // Note: 'raw.gitmirror.com' sometimes fails or redirects poorly for images.
    // Let's try 'raw.githubusercontent.com' directly again if user has VPN,
    // OR use a more stable mirror like 'ghproxy.com' or 'fastly.jsdelivr.net' if available.
    // Actually, 'raw.githubusercontent.com' is often blocked in CN.
    // 'raw.gitmirror.com' structure is: https://raw.gitmirror.com/User/Repo/Branch/Path
    // But sometimes it needs 'https://raw.gitmirror.com/raw.githubusercontent.com/...' which is wrong.
    
    // Let's use a known working replacement for PokeAPI specifically if possible.
    // PokeAPI sprites are also hosted on 'https://img.pokemondb.net/sprites/...' which is very stable.
    
    // Pattern: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1.png
    // Target:  https://img.pokemondb.net/sprites/home/normal/bulbasaur.png (names needed, hard to map id)
    // Target 2: https://raw.githubusercontent.com/... (original)
    
    // Let's try 'https://ghproxy.com/https://raw.githubusercontent.com/...'
    // or just revert to original if gitmirror is failing.
    
    // User reported: https://hub.gitmirror.com/raw.githubusercontent.com/... failed.
    // My previous replace was: .replace('https://raw.githubusercontent.com', 'https://raw.gitmirror.com')
    // Wait, the error log says: https://hub.gitmirror.com/raw.githubusercontent.com/...
    // That looks like a proxy wrapper.
    
    // Let's try to just return the original URL first, maybe the user has a proxy now?
    // OR use 'https://raw.fgit.ml' or similar.
    
    // Actually, 'https://raw.githubusercontent.com' is the most standard. 
    // If that fails, we can try 'https://fastly.jsdelivr.net/gh/PokeAPI/sprites@master/sprites/pokemon/...'
    
    if (obj.includes('raw.githubusercontent.com/PokeAPI/sprites/master')) {
        return obj.replace(
            'https://raw.githubusercontent.com/PokeAPI/sprites/master',
            'https://fastly.jsdelivr.net/gh/PokeAPI/sprites@master'
        );
    }
    
    return obj;
  }
  if (Array.isArray(obj)) {
    return obj.map(fixUrl);
  }
  if (obj && typeof obj === 'object') {
    const newObj: any = {};
    for (const key in obj) {
      newObj[key] = fixUrl(obj[key]);
    }
    return newObj;
  }
  return obj;
};

// Simple in-memory cache to avoid reading DB too often in one session
const memoryCache: Record<string, any> = {};

const getFromCache = async <T>(key: string): Promise<T | null> => {
  // Check memory first
  if (memoryCache[key]) return memoryCache[key];

  // Check IndexedDB
  const cached = await getItem<T>(key);
  if (cached) {
    memoryCache[key] = cached;
    return cached;
  }
  return null;
};

const saveToCache = (key: string, data: any) => {
  memoryCache[key] = data;
  setItem(key, data);
};

export const pokeApi = {
  // Fetch Pokemon by ID or Name
  getPokemon: async (query: string | number): Promise<Pokemon> => {
    const key = `pokemon_${query.toString().toLowerCase()}`;
    const cached = await getFromCache<Pokemon>(key);
    if (cached) return cached;

    const response = await fetch(`${BASE_URL}/pokemon/${query.toString().toLowerCase()}`);
    if (!response.ok) {
      throw new Error('Pokemon not found');
    }
    let data = await response.json();
    data = fixUrl(data);
    
    // Save minimal data to save space if needed, but for now full object
    saveToCache(key, data);
    return data;
  },

  // Fetch Pokemon Species (for multi-language names)
  getPokemonSpecies: async (id: number | string): Promise<PokemonSpecies> => {
    const key = `species_${id}`;
    const cached = await getFromCache<PokemonSpecies>(key);
    if (cached) return cached;

    const response = await fetch(`${BASE_URL}/pokemon-species/${id}`);
    if (!response.ok) {
      throw new Error('Species not found');
    }
    const data = await response.json();
    saveToCache(key, data);
    return data;
  },

  // Fetch Evolution Chain
  getEvolutionChain: async (url: string): Promise<EvolutionChain> => {
    // Extract ID from URL for caching key
    const parts = url.split('/');
    const id = parts[parts.length - 2];
    const key = `evo_chain_${id}`;
    
    const cached = await getFromCache<EvolutionChain>(key);
    if (cached) return cached;

    const response = await fetch(url);
    if (!response.ok) {
      throw new Error('Evolution chain not found');
    }
    const data = await response.json();
    saveToCache(key, data);
    return data;
  },

  // Fetch Encounters (Locations)
  getEncounters: async (id: number): Promise<any[]> => {
    const key = `encounters_${id}`;
    const cached = await getFromCache<any[]>(key);
    if (cached) return cached;

    const response = await fetch(`${BASE_URL}/pokemon/${id}/encounters`);
    if (!response.ok) {
      // It's possible to have no encounters
      return [];
    }
    const data = await response.json();
    saveToCache(key, data);
    return data;
  },

  // Fetch Type details (including pokemon list)
  getType: async (name: string): Promise<any> => {
    const key = `type_${name}`;
    const cached = await getFromCache<any>(key);
    if (cached) return cached;

    const response = await fetch(`${BASE_URL}/type/${name}`);
    if (!response.ok) {
      throw new Error('Type not found');
    }
    const data = await response.json();
    saveToCache(key, data);
    return data;
  },

  // Fetch Item
  getItem: async (query: string | number): Promise<any> => {
    const key = `item_${query.toString().toLowerCase()}`;
    const cached = await getFromCache<any>(key);
    if (cached) return cached;

    const response = await fetch(`${BASE_URL}/item/${query.toString().toLowerCase()}`);
    if (!response.ok) throw new Error('Item not found');
    const data = await response.json();
    saveToCache(key, data);
    return data;
  },

  // Fetch Move
  getMove: async (query: string | number): Promise<any> => {
    const key = `move_${query.toString().toLowerCase()}`;
    const cached = await getFromCache<any>(key);
    if (cached) return cached;

    const response = await fetch(`${BASE_URL}/move/${query.toString().toLowerCase()}`);
    if (!response.ok) throw new Error('Move not found');
    const data = await response.json();
    saveToCache(key, data);
    return data;
  },

  // Fetch Ability
  getAbility: async (query: string | number): Promise<any> => {
    const key = `ability_${query.toString().toLowerCase()}`;
    const cached = await getFromCache<any>(key);
    if (cached) return cached;

    const response = await fetch(`${BASE_URL}/ability/${query.toString().toLowerCase()}`);
    if (!response.ok) throw new Error('Ability not found');
    const data = await response.json();
    saveToCache(key, data);
    return data;
  },

  // Fetch Nature
  getNature: async (query: string | number): Promise<any> => {
    const key = `nature_${query.toString().toLowerCase()}`;
    const cached = await getFromCache<any>(key);
    if (cached) return cached;

    const response = await fetch(`${BASE_URL}/nature/${query.toString().toLowerCase()}`);
    if (!response.ok) throw new Error('Nature not found');
    const data = await response.json();
    saveToCache(key, data);
    return data;
  },


  // Fetch Pokedex (list of pokemon in a specific dex)
  getPokedex: async (id: string) => {
    const key = `pokedex_${id}`;
    const cached = await getFromCache<any>(key);
    if (cached) return cached;

    const response = await fetch(`${BASE_URL}/pokedex/${id}`);
    if (!response.ok) {
      throw new Error('Pokedex not found');
    }
    const data = await response.json();
    saveToCache(key, data);
    return data;
  },

  // Fetch Generic Data by URL (for moves, abilities, etc.)
  getData: async <T>(url: string): Promise<T> => {
    // Basic caching based on URL
    const key = `url_${url}`;
    const cached = await getFromCache<T>(key);
    if (cached) return cached;

    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Failed to fetch ${url}`);
    }
    let data = await response.json();
    data = fixUrl(data);
    saveToCache(key, data);
    return data;
  },

  // Fetch Pokemon List (lightweight list)
  getPokemonList: async (limit: number = 20, offset: number = 0) => {
    const key = `list_${limit}_${offset}`;
    const cached = await getFromCache<any>(key);
    if (cached) return cached;

    const response = await fetch(`${BASE_URL}/pokemon?limit=${limit}&offset=${offset}`);
    if (!response.ok) {
      throw new Error('Failed to fetch list');
    }
    const data = await response.json();
    saveToCache(key, data);
    return data;
  }
};
