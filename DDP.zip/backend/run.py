import uvicorn
import os
from dotenv import load_dotenv

if __name__ == "__main__":
    load_dotenv()
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", 8000))
    # 默认开启 reload，但在生产环境可以通过环境变量 RELOAD=false 关闭
    reload = os.getenv("RELOAD", "true").lower() == "true"
    
    uvicorn.run("app.main:app", host=host, port=port, reload=reload)
