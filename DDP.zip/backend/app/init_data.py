from sqlalchemy.orm import Session
from . import crud, schemas, config, models
from .database import SessionLocal

def init_db():
    db = SessionLocal()
    try:
        # Create default admin user
        admin_username = config.ADMIN_USERNAME
        admin = crud.get_user_by_username(db, username=admin_username)
        if not admin:
            admin_user = schemas.UserCreate(
                username=admin_username,
                password=config.ADMIN_PASSWORD,
                role="admin"
            )
            admin = crud.create_user(db=db, user=admin_user)
            print(f"Created default admin user: {admin_username}")
        else:
            print(f"Admin user {admin_username} already exists")
            
        # Create default public team/group
        # We assign it to the admin user
        default_team_name = config.DEFAULT_TEAM_NAME
        # Check if it exists for admin
        existing_teams = crud.get_teams(db, user_id=admin.id)
        if not any(t.name == default_team_name for t in existing_teams):
            # We create it manually to force the ID
            db_team = models.Team(
                id="D-E-F-A-U-L-T",
                name=default_team_name,
                pokemons=[],
                user_id=admin.id,
                share_code=crud.generate_share_code()
            )
            db.add(db_team)
            db.commit()
            print(f"Created default group: {default_team_name} with ID D-E-F-A-U-L-T")
        else:
            print(f"Default group {default_team_name} already exists")

    finally:
        db.close()
