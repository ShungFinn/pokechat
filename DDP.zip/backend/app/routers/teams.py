from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from .. import crud, models, schemas, dependencies, config
from ..database import SessionLocal

router = APIRouter(
    prefix="/teams",
    tags=["teams"],
    responses={404: {"description": "Not found"}},
)

from datetime import datetime, timedelta

@router.get("/", response_model=List[schemas.Team])
def read_teams(
    skip: int = 0, 
    limit: int = 100, 
    db: Session = Depends(dependencies.get_db),
    current_user: models.User = Depends(dependencies.get_current_user)
):
    # 1. Get user's private teams
    user_teams = crud.get_teams(db, user_id=current_user.id, skip=skip, limit=limit)
    
    # 2. Get the default public team (owned by admin)
    # We must ensure we get the OFFICIAL one, not just any team with that name
    admin_user = crud.get_user_by_username(db, config.ADMIN_USERNAME)
    public_team = None
    if admin_user:
        public_team = db.query(models.Team).filter(
            models.Team.name == config.DEFAULT_TEAM_NAME,
            models.Team.user_id == admin_user.id
        ).first()
    
    # 3. Fetch user settings for muting
    settings = db.query(models.UserTeamSettings).filter(models.UserTeamSettings.user_id == current_user.id).all()
    muted_team_ids = {s.team_id for s in settings if s.is_muted}

    # Calculate total users for the public group
    total_users_count = db.query(models.User).count()
    
    # Calculate online users (active in last 5 minutes)
    active_threshold = datetime.utcnow() - timedelta(minutes=5)
    online_users_count = db.query(models.User).filter(models.User.last_active >= active_threshold).count()
    
    all_teams = []
    if public_team:
        # Dynamically attach counts to the ORM object
        public_team.members_count = total_users_count
        public_team.online_count = online_users_count
        public_team.is_muted = public_team.id in muted_team_ids
        
        # Avoid duplicate if the user is the admin (owner of default team)
    if public_team and public_team.user_id != current_user.id:
        all_teams.append(public_team)
            
    # Also update counts for any team in user_teams that happens to be the public one (for admin)
    for team in user_teams:
        team.is_muted = team.id in muted_team_ids
        if team.name == config.DEFAULT_TEAM_NAME:
            team.members_count = total_users_count
            team.online_count = online_users_count
        else:
            team.members_count = 1 # Default for private teams
            team.online_count = 1 # Just the owner

    all_teams.extend(user_teams)
    
    return all_teams

@router.get("/all", response_model=List[schemas.Team])
def read_all_teams(
    skip: int = 0, 
    limit: int = 100, 
    db: Session = Depends(dependencies.get_db),
    current_user: models.User = Depends(dependencies.get_current_admin_user)
):
    teams = crud.get_all_teams(db, skip=skip, limit=limit)
    return teams

@router.post("/", response_model=schemas.Team)
def create_team(
    team: schemas.TeamCreate, 
    db: Session = Depends(dependencies.get_db),
    current_user: models.User = Depends(dependencies.get_current_user)
):
    # Prevent creating a team with the reserved name "Pokemon Center" unless admin
    if team.name == config.DEFAULT_TEAM_NAME:
        # Check if user is admin
        if current_user.role != "admin":
             raise HTTPException(status_code=400, detail=f"Cannot create a team with reserved name '{config.DEFAULT_TEAM_NAME}'")

    return crud.create_team(db=db, team=team, user_id=current_user.id)

@router.get("/{team_id}", response_model=schemas.Team)
def read_team(
    team_id: str, 
    db: Session = Depends(dependencies.get_db),
    current_user: models.User = Depends(dependencies.get_current_user)
):
    db_team = crud.get_team(db, team_id=team_id)
    if db_team is None:
        raise HTTPException(status_code=404, detail="Team not found")
    if db_team.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to access this team")
    return db_team

@router.put("/{team_id}", response_model=schemas.Team)
def update_team(
    team_id: str,
    team: schemas.TeamCreate,
    db: Session = Depends(dependencies.get_db),
    current_user: models.User = Depends(dependencies.get_current_user)
):
    db_team = crud.get_team(db, team_id=team_id)
    if db_team is None:
        raise HTTPException(status_code=404, detail="Team not found")
    if db_team.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to update this team")
    
    # Prevent renaming to the reserved name "Pokemon Center" unless admin
    if team.name == config.DEFAULT_TEAM_NAME:
        if current_user.role != "admin":
             raise HTTPException(status_code=400, detail=f"Cannot use reserved name '{config.DEFAULT_TEAM_NAME}'")
             
    return crud.update_team(db=db, team_id=team_id, team=team)

@router.delete("/{team_id}")
def delete_team(
    team_id: str,
    db: Session = Depends(dependencies.get_db),
    current_user: models.User = Depends(dependencies.get_current_user)
):
    db_team = crud.get_team(db, team_id=team_id)
    if db_team is None:
        raise HTTPException(status_code=404, detail="Team not found")
    
    # Check if this is the default public team (owned by admin)
    admin_user = crud.get_user_by_username(db, config.ADMIN_USERNAME)
    if admin_user and db_team.name == config.DEFAULT_TEAM_NAME and db_team.user_id == admin_user.id:
        raise HTTPException(status_code=403, detail="Cannot delete the default public group")

    if db_team.user_id != current_user.id and current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Not authorized to delete this team")
        
    crud.delete_team(db=db, team_id=team_id)
    return {"ok": True}

@router.post("/{team_id}/mute")
def mute_team(
    team_id: str,
    is_muted: bool,
    db: Session = Depends(dependencies.get_db),
    current_user: models.User = Depends(dependencies.get_current_user)
):
    # Verify team exists
    db_team = crud.get_team(db, team_id=team_id)
    if not db_team:
        raise HTTPException(status_code=404, detail="Team not found")
        
    crud.update_user_team_setting(db, user_id=current_user.id, team_id=team_id, is_muted=is_muted)
    return {"ok": True, "is_muted": is_muted}

@router.post("/import/{share_code}", response_model=schemas.Team)
def import_team(
    share_code: str,
    db: Session = Depends(dependencies.get_db),
    current_user: models.User = Depends(dependencies.get_current_user)
):
    # 1. Find the team by share code
    source_team = crud.get_team_by_share_code(db, share_code)
    if not source_team:
        raise HTTPException(status_code=404, detail="Team not found with this share code")
    
    # 2. Create a copy for the current user
    # We create a new team with the same name and pokemons
    new_team_data = schemas.TeamCreate(
        name=f"{source_team.name} (Imported)",
        pokemons=source_team.pokemons
    )
    
    return crud.create_team(db=db, team=new_team_data, user_id=current_user.id)
