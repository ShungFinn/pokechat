from fastapi import APIRouter, WebSocket, WebSocketDisconnect, status
from sqlalchemy.orm import Session
from typing import List, Dict, Any
import json
from jose import JWTError, jwt
from .. import crud, models, schemas, security, database

router = APIRouter()

class ConnectionManager:
    def __init__(self):
        # active_connections: user_id -> List[WebSocket]
        self.active_connections: Dict[int, List[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, user_id: int):
        await websocket.accept()
        if user_id not in self.active_connections:
            self.active_connections[user_id] = []
        self.active_connections[user_id].append(websocket)

    def disconnect(self, websocket: WebSocket, user_id: int):
        if user_id in self.active_connections:
            if websocket in self.active_connections[user_id]:
                self.active_connections[user_id].remove(websocket)
            if not self.active_connections[user_id]:
                del self.active_connections[user_id]

    async def broadcast(self, message: dict):
        json_msg = json.dumps(message)
        # Broadcast to all connected users
        for uid, connections in self.active_connections.items():
            for connection in connections:
                try:
                    await connection.send_text(json_msg)
                except Exception as e:
                    print(f"Error sending to user {uid}: {e}")

manager = ConnectionManager()

@router.websocket("/ws/{token}")
async def websocket_endpoint(websocket: WebSocket, token: str):
    # 1. Validate Token
    db = database.SessionLocal()
    user = None
    try:
        payload = jwt.decode(token, security.SECRET_KEY, algorithms=[security.ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
            return
        user = crud.get_user_by_username(db, username=username)
        if user is None:
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
            return
    except JWTError:
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
        return
    finally:
        db.close()

    # 2. Connect
    await manager.connect(websocket, user.id)
    
    try:
        while True:
            data = await websocket.receive_text()
            try:
                message_data = json.loads(data)
                
                # Ensure sender info is correct/trusted
                # We override senderName to match the authenticated user to prevent spoofing
                # But we keep other fields. 
                # Note: Client sends a full 'Message' object usually.
                
                # Let's verify structure
                if 'content' in message_data and 'sessionId' in message_data:
                     # Attach sender info from the token user
                     message_data['senderName'] = user.username
                     # If the client sent an ID, keep it, or generate one? 
                     # Ideally backend generates ID, but for distributed/offline-first, client ID is okay.
                     
                     await manager.broadcast(message_data)
            except json.JSONDecodeError:
                pass
    except WebSocketDisconnect:
        manager.disconnect(websocket, user.id)
