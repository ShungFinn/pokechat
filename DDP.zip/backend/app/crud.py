from sqlalchemy.orm import Session
from . import models, schemas, security
import string
import secrets
from datetime import datetime

def get_user(db: Session, user_id: int):
    return db.query(models.User).filter(models.User.id == user_id).first()

def get_user_by_username(db: Session, username: str):
    return db.query(models.User).filter(models.User.username == username).first()

def get_users(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.User).offset(skip).limit(limit).all()

def delete_user(db: Session, user_id: int):
    user = get_user(db, user_id)
    if user:
        db.delete(user)
        db.commit()
    return user

def create_user(db: Session, user: schemas.UserCreate):
    hashed_password = security.get_password_hash(user.password)
    db_user = models.User(
        username=user.username, 
        hashed_password=hashed_password,
        role=user.role,
        must_change_password=True
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def update_user_password(db: Session, user_id: int, hashed_password: str):
    user = get_user(db, user_id)
    if user:
        user.hashed_password = hashed_password
        user.must_change_password = False
        db.commit()
        db.refresh(user)
    return user

def set_user_must_change_password(db: Session, user_id: int, must_change: bool):
    user = get_user(db, user_id)
    if user:
        user.must_change_password = must_change
        db.commit()
        db.refresh(user)
    return user

def get_teams(db: Session, user_id: int, skip: int = 0, limit: int = 100):
    return db.query(models.Team).filter(models.Team.user_id == user_id).offset(skip).limit(limit).all()

def get_all_teams(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Team).offset(skip).limit(limit).all()

def generate_share_code():
    alphabet = string.ascii_uppercase + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(10))

def create_team(db: Session, team: schemas.TeamCreate, user_id: int):
    # Generate unique share code
    while True:
        code = generate_share_code()
        if not db.query(models.Team).filter(models.Team.share_code == code).first():
            break

    # JSON field 'pokemons' is passed directly
    db_team = models.Team(
        name=team.name,
        pokemons=team.pokemons,
        user_id=user_id,
        share_code=code
    )
    db.add(db_team)
    db.commit()
    db.refresh(db_team)
    return db_team

def get_team_by_share_code(db: Session, share_code: str):
    return db.query(models.Team).filter(models.Team.share_code == share_code).first()

def get_team(db: Session, team_id: str):
    return db.query(models.Team).filter(models.Team.id == team_id).first()

def update_team(db: Session, team_id: str, team: schemas.TeamCreate):
    db_team = get_team(db, team_id)
    if db_team:
        db_team.name = team.name
        db_team.pokemons = team.pokemons
        db_team.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(db_team)
    return db_team

def delete_team(db: Session, team_id: str):
    db_team = get_team(db, team_id)
    if db_team:
        db.delete(db_team)
        db.commit()
    return db_team

def get_user_team_setting(db: Session, user_id: int, team_id: str):
    return db.query(models.UserTeamSettings).filter(
        models.UserTeamSettings.user_id == user_id,
        models.UserTeamSettings.team_id == team_id
    ).first()

def update_user_team_setting(db: Session, user_id: int, team_id: str, is_muted: bool):
    setting = get_user_team_setting(db, user_id, team_id)
    if not setting:
        setting = models.UserTeamSettings(user_id=user_id, team_id=team_id, is_muted=is_muted)
        db.add(setting)
    else:
        setting.is_muted = is_muted
    db.commit()
    db.refresh(setting)
    return setting
