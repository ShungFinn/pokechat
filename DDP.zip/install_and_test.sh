#!/bin/bash

# 设置颜色
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# 必须以 root 运行
if [ "$EUID" -ne 0 ]; then 
  echo -e "${RED}请使用 sudo 运行此脚本: sudo ./install_and_test.sh${NC}"
  exit 1
fi

echo -e "${GREEN}=== 开始一键安装与测试 Pokemon Chat ===${NC}"

# 获取当前脚本所在目录
PROJECT_ROOT=$(pwd)
echo "项目根目录: $PROJECT_ROOT"

# 1. 赋予所有脚本执行权限
echo -e "${GREEN}[1/5] 设置脚本权限...${NC}"
chmod +x "$PROJECT_ROOT/backend/install.py"
chmod +x "$PROJECT_ROOT/install_web.py"
chmod +x "$PROJECT_ROOT/backend/run.py"

# 2. 安装后端
echo -e "${GREEN}[2/5] 安装后端 (端口 7000)...${NC}"
python3 "$PROJECT_ROOT/backend/install.py"
if [ $? -eq 0 ]; then
    echo "后端安装脚本执行成功。"
else
    echo -e "${RED}后端安装脚本执行失败！${NC}"
    exit 1
fi

# 3. 安装前端
echo -e "${GREEN}[3/5] 安装前端 (端口 9000)...${NC}"
# 注意：前端安装脚本会编译 React 项目并配置 Nginx
python3 "$PROJECT_ROOT/install_web.py"
if [ $? -eq 0 ]; then
    echo "前端安装脚本执行成功。"
else
    echo -e "${RED}前端安装脚本执行失败！${NC}"
    exit 1
fi

# 4. 等待服务启动
echo -e "${GREEN}[4/5] 等待服务启动 (10秒)...${NC}"
sleep 10

# 5. 测试服务状态
echo -e "${GREEN}[5/5] 测试服务状态...${NC}"

# 测试后端 (7000)
BACKEND_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:7000/)
if [ "$BACKEND_STATUS" == "200" ] || [ "$BACKEND_STATUS" == "404" ]; then # 404 is acceptable for root path depending on implementation
    echo -e "${GREEN}后端 (Port 7000): 运行正常 (HTTP $BACKEND_STATUS)${NC}"
else
    echo -e "${RED}后端 (Port 7000): 访问失败 (HTTP $BACKEND_STATUS)${NC}"
    echo "尝试查看日志: sudo journalctl -u backend.service -n 10"
fi

# 测试前端 (9000)
FRONTEND_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:9000/)
if [ "$FRONTEND_STATUS" == "200" ]; then
    echo -e "${GREEN}前端 (Port 9000): 运行正常 (HTTP $FRONTEND_STATUS)${NC}"
else
    echo -e "${RED}前端 (Port 9000): 访问失败 (HTTP $FRONTEND_STATUS)${NC}"
    echo "尝试查看 Nginx 状态: sudo systemctl status nginx"
fi

# 最终端口检查
echo "当前端口监听情况:"
netstat -tuln | grep -E '7000|9000'

echo -e "${GREEN}=== 部署测试流程结束 ===${NC}"
echo "如果一切正常，您可以通过 http://<服务器IP>:9000 访问系统。"
