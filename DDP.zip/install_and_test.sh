#!/bin/bash

# 设置颜色
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# 必须以 root 运行
if [ "$EUID" -ne 0 ]; then 
  echo -e "${RED}请使用 sudo 运行此脚本: sudo ./install_and_test.sh${NC}"
  exit 1
fi

echo -e "${GREEN}=== Pokemon Chat 智能部署/启动脚本 ===${NC}"

# 获取当前脚本所在目录
PROJECT_ROOT=$(pwd)
echo "项目根目录: $PROJECT_ROOT"

# 函数：等待 apt 锁释放
wait_for_apt_lock() {
    while fuser /var/lib/dpkg/lock >/dev/null 2>&1 || fuser /var/lib/apt/lists/lock >/dev/null 2>&1 || fuser /var/lib/dpkg/lock-frontend >/dev/null 2>&1; do
        echo "等待 apt/dpkg 锁释放..."
        sleep 5
    done
}

# 检查系统依赖是否满足
check_system_deps() {
    if ! command -v python3 &> /dev/null; then return 1; fi
    if ! command -v pip3 &> /dev/null; then return 1; fi
    if ! dpkg -s python3-venv &> /dev/null; then return 1; fi
    if ! command -v nginx &> /dev/null; then return 1; fi
    return 0
}

# 检查后端是否已安装
check_backend_installed() {
    if [ ! -d "/opt/backend/venv" ]; then return 1; fi
    if [ ! -f "/etc/systemd/system/backend.service" ]; then return 1; fi
    return 0
}

# 检查前端是否已安装
check_frontend_installed() {
    if [ ! -f "/etc/nginx/sites-enabled/pokemon-chat" ]; then return 1; fi
    if [ ! -d "/var/www/pokemon-chat" ]; then return 1; fi
    return 0
}

# 主逻辑
FORCE_INSTALL=false
if [ "$1" == "--force" ]; then
    FORCE_INSTALL=true
fi

# 1. 赋予脚本权限
chmod +x "$PROJECT_ROOT/backend/install.py"
chmod +x "$PROJECT_ROOT/install_web.py"
chmod +x "$PROJECT_ROOT/backend/run.py"

# 2. 智能判断：安装还是仅启动
NEED_INSTALL=false

if [ "$FORCE_INSTALL" = true ]; then
    echo -e "${YELLOW}检测到 --force 参数，强制重新安装...${NC}"
    NEED_INSTALL=true
else
    echo -e "${GREEN}[1/5] 检查环境状态...${NC}"
    
    if check_system_deps; then
        echo "  - 系统依赖: [OK]"
    else
        echo "  - 系统依赖: [缺失]"
        NEED_INSTALL=true
    fi

    if check_backend_installed; then
        echo "  - 后端服务: [OK]"
    else
        echo "  - 后端服务: [缺失]"
        NEED_INSTALL=true
    fi

    if check_frontend_installed; then
        echo "  - 前端服务: [OK]"
    else
        echo "  - 前端服务: [缺失]"
        NEED_INSTALL=true
    fi
fi

if [ "$NEED_INSTALL" = true ]; then
    echo -e "${YELLOW}环境不满足或要求强制安装，开始执行完整安装流程...${NC}"
    
    # 检查并安装 Python3
    if ! command -v python3 &> /dev/null; then
        echo "安装 Python3..."
        wait_for_apt_lock
        apt-get update && apt-get install -y python3
    fi

    echo -e "${GREEN}[2/5] 安装/更新 后端...${NC}"
    wait_for_apt_lock
    python3 "$PROJECT_ROOT/backend/install.py"
    if [ $? -ne 0 ]; then echo -e "${RED}后端安装失败${NC}"; exit 1; fi

    echo -e "${GREEN}[3/5] 安装/更新 前端...${NC}"
    wait_for_apt_lock
    python3 "$PROJECT_ROOT/install_web.py"
    if [ $? -ne 0 ]; then echo -e "${RED}前端安装失败${NC}"; exit 1; fi

else
    echo -e "${GREEN}环境检查通过！跳过安装步骤，直接重启服务并应用最新代码...${NC}"
    
    # 即使不完全重装，我们通常也需要更新代码文件 (rsync/cp)
    # 但由于之前的 install.py 逻辑包含了 cp 和 restart，
    # 我们可以选择调用 install.py (它已经优化过，会自动跳过 venv)
    # 或者如果我们确信代码没变，只重启。
    # 用户通常希望“应用最新代码”，所以调用 install.py 是最安全的，
    # 因为我们已经优化了 install.py，它在 venv 存在时非常快。
    
    echo -e "${GREEN}[2/5] 快速更新后端代码并重启...${NC}"
    # 这里我们仍然调用 install.py，因为它是应用代码变更的唯一途径
    # 但因为它现在是幂等的且会复用 venv，所以速度很快
    python3 "$PROJECT_ROOT/backend/install.py"
    
    echo -e "${GREEN}[3/5] 快速更新前端代码并重启...${NC}"
    python3 "$PROJECT_ROOT/install_web.py"
fi

# 4. 等待启动
echo -e "${GREEN}[4/5] 等待服务就绪 (5秒)...${NC}"
sleep 5

# 5. 测试服务状态
echo -e "${GREEN}[5/5] 最终状态检查...${NC}"

# 后端检查
if curl -s http://localhost:7000/ > /dev/null || [ $(curl -s -o /dev/null -w "%{http_code}" http://localhost:7000/) == "404" ]; then
    echo -e "${GREEN}后端 (Port 7000): 正常运行${NC}"
else
    echo -e "${RED}后端 (Port 7000): 异常${NC} (请检查: sudo systemctl status backend.service)"
fi

# 前端检查
if curl -s http://localhost:9000/ > /dev/null; then
    echo -e "${GREEN}前端 (Port 9000): 正常运行${NC}"
else
    echo -e "${RED}前端 (Port 9000): 异常${NC} (请检查: sudo systemctl status nginx)"
fi

echo -e "${GREEN}=== 操作完成 ===${NC}"
echo "访问地址: http://<服务器IP>:9000"
